SELECT
    {{dimension_select}}
    COALESCE(d.category, 'uncategorized') AS disposition_category,
    c.disposition_code,
    COUNT(*)::bigint AS disposition_count
FROM ccass.conversations c
LEFT JOIN ccass.dispositions d ON d.code = c.disposition_code AND d.organization_id = c.organization_id
WHERE c.organization_id = {org_id}
  AND c.disposition_code IS NOT NULL
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
GROUP BY COALESCE(d.category, 'uncategorized'), c.disposition_code {{group_by_sql}}
{{limit_sql}}
