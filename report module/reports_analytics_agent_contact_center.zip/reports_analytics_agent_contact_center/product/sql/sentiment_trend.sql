SELECT
    {{dimension_select}}
    ROUND(AVG(st.customer_score)::numeric, 2) AS sentiment_trend
FROM ccass.conversation_sentiment_turns st
WHERE st.organization_id = {org_id}
  AND st.customer_score IS NOT NULL
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
