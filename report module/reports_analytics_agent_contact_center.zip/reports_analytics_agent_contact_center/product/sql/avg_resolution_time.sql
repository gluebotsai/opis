WITH base_conversation AS (
{{base_conversation}}
)
SELECT
    {{dimension_select}}
    ROUND(AVG(resolution_duration_seconds)::numeric, 1) AS avg_resolution_time
FROM base_conversation
WHERE {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
  AND resolved_at IS NOT NULL
{{group_by_sql}}
{{limit_sql}}
