WITH presence_segments AS (
    SELECT
        p.agent_id,
        p.reason_code,
        p.started_at,
        EXTRACT(EPOCH FROM (
            COALESCE(
                LEAD(p.started_at) OVER (PARTITION BY p.agent_id, p.organization_id ORDER BY p.started_at),
                NOW()
            ) - p.started_at
        )) AS duration_seconds
    FROM ccass.agent_presence_history p
    WHERE p.organization_id = {org_id}
      AND p.reason_code IS NOT NULL
      AND {{scope_sql}}
      AND {{time_sql}}
      AND {{filters_sql}}
)
SELECT
    {{dimension_select}}
    reason_code,
    ROUND(SUM(duration_seconds)::numeric, 1) AS total_duration_seconds,
    ROUND((SUM(duration_seconds) / 3600.0)::numeric, 2) AS total_duration_hours
FROM presence_segments
GROUP BY reason_code {{group_by_sql}}
{{limit_sql}}
