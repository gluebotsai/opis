SELECT
    {{dimension_select}}
    ROUND(AVG(EXTRACT(EPOCH FROM (NOW() - queued_at)))::numeric, 1) AS avg_wait_time_live
FROM ccass.conversations c
WHERE c.organization_id = {org_id}
  AND c.status = 'queued'
  AND c.queued_at IS NOT NULL
  AND {{scope_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
