SELECT
    {{dimension_select}}
    COUNT(*)::bigint AS escalation_count
FROM ccass.agent_tasks t
WHERE t.organization_id = {org_id}
  AND t.task_type = 'escalation'
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
