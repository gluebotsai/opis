WITH base_conversation AS (
{{base_conversation}}
),
contacts_in_window AS (
    SELECT DISTINCT contact_id
    FROM base_conversation
    WHERE {{scope_sql}}
      AND {{time_sql}}
      AND {{segment_sql}}
      AND {{filters_sql}}
      AND contact_id IS NOT NULL
),
earlier_contacts AS (
    SELECT DISTINCT c.contact_id
    FROM contacts_in_window cw
    JOIN ccass.conversations c ON c.contact_id = cw.contact_id
        AND c.organization_id = {org_id}
        AND c.created_at < TIMESTAMPTZ '{{time_start}}'
)
SELECT
    {{dimension_select}}
    COUNT(cw.contact_id)::bigint AS total_contacts,
    COUNT(ec.contact_id)::bigint AS returning_contacts,
    (COUNT(cw.contact_id) - COUNT(ec.contact_id))::bigint AS new_contacts,
    ROUND(
        (COUNT(cw.contact_id) - COUNT(ec.contact_id))::numeric
        / NULLIF(COUNT(cw.contact_id), 0),
        4
    ) AS new_contact_rate,
    ROUND(
        COUNT(ec.contact_id)::numeric
        / NULLIF(COUNT(cw.contact_id), 0),
        4
    ) AS returning_contact_rate
FROM contacts_in_window cw
LEFT JOIN earlier_contacts ec ON ec.contact_id = cw.contact_id
{{group_by_sql}}
{{limit_sql}}
