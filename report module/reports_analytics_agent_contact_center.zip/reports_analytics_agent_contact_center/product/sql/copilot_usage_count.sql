SELECT
    {{dimension_select}}
    COUNT(*)::bigint AS copilot_usage_count
FROM ccass.copilot_turns ct
WHERE ct.organization_id = {org_id}
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
