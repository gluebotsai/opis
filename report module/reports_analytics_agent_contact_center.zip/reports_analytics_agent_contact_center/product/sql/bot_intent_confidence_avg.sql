SELECT
    {{dimension_select}}
    ROUND(AVG(t.confidence)::numeric, 4) AS bot_intent_confidence_avg
FROM ccass.nlp_turns t
WHERE t.organization_id = {org_id}
  AND t.confidence IS NOT NULL
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
