SELECT
    {{dimension_select}}
    COUNT(*)::bigint AS message_count
FROM ccass.conversation_messages m
WHERE m.organization_id = {org_id}
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
