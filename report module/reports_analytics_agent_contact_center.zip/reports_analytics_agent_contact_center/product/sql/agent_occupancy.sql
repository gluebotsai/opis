WITH presence_segments AS (
    SELECT
        p.agent_id,
        p.new_state AS presence_state,
        p.started_at,
        EXTRACT(EPOCH FROM (
            COALESCE(
                LEAD(p.started_at) OVER (PARTITION BY p.agent_id, p.organization_id ORDER BY p.started_at),
                NOW()
            ) - p.started_at
        )) AS duration_seconds
    FROM ccass.agent_presence_history p
    WHERE p.organization_id = {org_id}
      AND {{scope_sql}}
      AND {{time_sql}}
      AND {{filters_sql}}
)
SELECT
    {{dimension_select}}
    ROUND(
        SUM(duration_seconds) FILTER (WHERE presence_state IN ('busy', 'after_contact_work'))::numeric
        / NULLIF(SUM(duration_seconds) FILTER (WHERE presence_state != 'offline'), 0),
        4
    ) AS agent_occupancy
FROM presence_segments
{{group_by_sql}}
{{limit_sql}}
