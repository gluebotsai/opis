SELECT
    {{dimension_select}}
    ROUND(AVG(ct.latency_ms)::numeric, 1) AS copilot_latency_avg
FROM ccass.copilot_turns ct
WHERE ct.organization_id = {org_id}
  AND ct.latency_ms IS NOT NULL
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
