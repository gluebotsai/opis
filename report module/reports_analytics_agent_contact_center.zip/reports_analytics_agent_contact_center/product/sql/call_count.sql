SELECT
    {{dimension_select}}
    COUNT(*)::bigint AS call_count
FROM ccass.call_cdr c
WHERE c.domain_id = {org_id}
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
