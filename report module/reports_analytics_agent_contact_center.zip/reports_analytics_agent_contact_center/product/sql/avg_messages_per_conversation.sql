SELECT
    {{dimension_select}}
    ROUND(
        COUNT(*)::numeric
        / NULLIF(COUNT(DISTINCT m.conversation_id), 0),
        2
    ) AS avg_messages_per_conversation
FROM ccass.conversation_messages m
WHERE m.organization_id = {org_id}
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
