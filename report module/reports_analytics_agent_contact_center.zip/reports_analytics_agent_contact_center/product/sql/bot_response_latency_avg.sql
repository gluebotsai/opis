SELECT
    {{dimension_select}}
    ROUND(AVG(t.latency_ms)::numeric, 1) AS bot_response_latency_avg
FROM ccass.nlp_turns t
WHERE t.organization_id = {org_id}
  AND t.latency_ms IS NOT NULL
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
