SELECT
    {{dimension_select}}
    COUNT(*) FILTER (WHERE ct.accepted = true)::bigint AS accepted_count,
    COUNT(*) FILTER (WHERE ct.accepted IS NOT NULL)::bigint AS total_suggestions,
    ROUND(
        COUNT(*) FILTER (WHERE ct.accepted = true)::numeric
        / NULLIF(COUNT(*) FILTER (WHERE ct.accepted IS NOT NULL), 0),
        4
    ) AS copilot_acceptance_rate
FROM ccass.copilot_turns ct
WHERE ct.organization_id = {org_id}
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
