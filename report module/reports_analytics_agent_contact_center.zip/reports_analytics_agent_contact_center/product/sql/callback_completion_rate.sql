SELECT
    {{dimension_select}}
    COUNT(*) FILTER (WHERE status = 'completed')::bigint AS completed_callbacks,
    COUNT(*)::bigint AS total_callbacks,
    ROUND(
        COUNT(*) FILTER (WHERE status = 'completed')::numeric
        / NULLIF(COUNT(*), 0),
        4
    ) AS callback_completion_rate
FROM ccass.agent_tasks t
WHERE t.organization_id = {org_id}
  AND t.task_type = 'callback'
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
