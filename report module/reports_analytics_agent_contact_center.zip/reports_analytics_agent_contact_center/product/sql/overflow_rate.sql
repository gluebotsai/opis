SELECT
    {{dimension_select}}
    COUNT(*) FILTER (WHERE ra.queue_id = rp.overflow_queue_id)::bigint AS overflow_attempts,
    COUNT(*)::bigint AS total_attempts,
    ROUND(
        COUNT(*) FILTER (WHERE ra.queue_id = rp.overflow_queue_id)::numeric
        / NULLIF(COUNT(*), 0),
        4
    ) AS overflow_rate
FROM ccass.routing_attempts ra
LEFT JOIN ccass.routing_policies rp ON rp.queue_id = ra.queue_id AND rp.organization_id = ra.organization_id
WHERE ra.organization_id = {org_id}
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
