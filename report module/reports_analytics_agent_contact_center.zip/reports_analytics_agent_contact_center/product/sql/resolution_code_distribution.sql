SELECT
    {{dimension_select}}
    c.resolution_code,
    COUNT(*)::bigint AS conversation_count
FROM ccass.conversations c
WHERE c.organization_id = {org_id}
  AND c.resolution_code IS NOT NULL
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
GROUP BY c.resolution_code {{group_by_sql}}
{{limit_sql}}
