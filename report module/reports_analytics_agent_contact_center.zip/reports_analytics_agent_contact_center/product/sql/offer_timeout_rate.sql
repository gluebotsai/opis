SELECT
    {{dimension_select}}
    COUNT(*) FILTER (WHERE state = 'expired')::bigint AS expired_count,
    COUNT(*)::bigint AS total_offers,
    ROUND(
        COUNT(*) FILTER (WHERE state = 'expired')::numeric
        / NULLIF(COUNT(*), 0),
        4
    ) AS offer_timeout_rate
FROM ccass.conversation_assignments ca
WHERE ca.organization_id = {org_id}
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
