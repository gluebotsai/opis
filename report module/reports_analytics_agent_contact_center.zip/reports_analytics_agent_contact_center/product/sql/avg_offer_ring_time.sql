SELECT
    {{dimension_select}}
    ROUND(AVG(EXTRACT(EPOCH FROM (accepted_at - offered_at)))::numeric, 1) AS avg_offer_ring_time
FROM ccass.conversation_assignments ca
WHERE ca.organization_id = {org_id}
  AND ca.accepted_at IS NOT NULL
  AND ca.offered_at IS NOT NULL
  AND {{scope_sql}}
  AND {{time_sql}}
  AND {{segment_sql}}
  AND {{filters_sql}}
{{group_by_sql}}
{{limit_sql}}
