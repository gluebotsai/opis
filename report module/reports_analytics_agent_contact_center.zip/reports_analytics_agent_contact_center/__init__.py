"""Reports & Analytics Agent for Contact Center (V2 Architecture).

SQL-only analytics pack for Contact Center.
Two role tiers: admin, agent.
"""

from __future__ import annotations
