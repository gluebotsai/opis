"""Slot-filling helper for SQL templates."""

from __future__ import annotations

import re


def fill_slots(template: str, slots: dict[str, str]) -> str:
    """Replace {{slot_name}} tokens with their corresponding values."""
    result = template
    for key, value in slots.items():
        pattern = r"\{\{\s*" + re.escape(key) + r"\s*\}\}"
        result = re.sub(pattern, str(value), result)
    return result
