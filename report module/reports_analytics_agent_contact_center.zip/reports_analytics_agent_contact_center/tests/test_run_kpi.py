import pytest
from reports_analytics_agent_contact_center.core.run_kpi import run_kpi


def test_admin_org_scope_compiles():
    res = run_kpi(
        "conversation_count",
        organization_id=1000,
        user_id=1005,
        role="admin",
        scope_level="org",
    )
    assert res["status"] in ("compiled", "ok")
    assert "conversation_count" in res["sql"]
    assert "organization_id = 1000" in res["sql"]


def test_agent_own_scope_enforced():
    res = run_kpi(
        "conversation_count",
        organization_id=1000,
        user_id=1005,
        role="agent",
        queue_ids=[401],
        scope_level="own",
    )
    assert res["status"] in ("compiled", "ok")
    assert "assigned_agent_id = 1005" in res["sql"]


def test_agent_queue_scope_enforced():
    res = run_kpi(
        "conversation_count",
        organization_id=1000,
        user_id=1005,
        role="agent",
        queue_ids=[401, 402],
        scope_level="queue",
    )
    assert res["status"] in ("compiled", "ok")
    assert "queue_id IN (401, 402)" in res["sql"]


def test_agent_org_scope_denied():
    res = run_kpi(
        "conversation_count",
        organization_id=1000,
        user_id=1005,
        role="agent",
        queue_ids=[401],
        scope_level="org",
    )
    assert res["status"] == "error"
    assert res["error_type"] == "DENY"
