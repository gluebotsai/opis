"""Worktual Lola multi-agent runner."""

from __future__ import annotations

from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo

from app.agents.custom_lola_worktual.llm import get_worktual_llm
from app.agents.custom_lola_worktual.memory import Memory, SessionManager
from app.agents.custom_lola_worktual.multi_agent import Agent, AgentRouter
from app.agents.custom_lola_worktual.prompt_overlay import apply_social_overlay
from app.agents.custom_lola_worktual.prompts import (
    BOOKING_SYSTEM_PROMPT,
    SALES_SYSTEM_PROMPT,
    SERVICE_SYSTEM_PROMPT,
)
from app.agents.custom_lola_worktual.session import set_turn_context
from app.agents.custom_lola_worktual.tools import (
    BOOK_APPOINTMENT,
    CALENDAR_TOOL,
    CALL_BACK,
    CONTACT_ENRICH,
    CREATE_TICKET,
    GET_SALES_KNOWLEDGE,
    GET_SERVICE_KNOWLEDGE,
    GET_TICKET_STATUS,
    LIVE_AGENT,
    RESCHEDULE_APPOINTMENT,
    SEND_OTP,
    VALIDATE_EMAIL,
    VALIDATE_PHONE_NUMBER,
    VERIFY_CONTACT_FOR_TICKET,
    VERIFY_OTP,
    WEB_SEARCH_TOOL,
    Tool,
    account_verification,
    book_appointment,
    calendar_tool,
    call_back,
    contact_enrich,
    create_ticket,
    get_conversation_summary,
    get_sales_knowledge,
    get_service_knowledge,
    get_ticket_status,
    live_agent,
    reschedule_meeting,
    validate_email,
    validate_phone_number,
    verify_contact_for_ticket,
    verify_otp,
    websearch_tool,
)
from app.services.contact_enrich_policy import (
    ContactProfileSnapshot,
    format_contact_profile_block,
)

session_manager = SessionManager()
longterm_cache: dict[str, dict[str, int]] = {}

CONTACT_ENRICH_GUIDANCE = """

CONTACT PROFILE ENRICHMENT:
- The authoritative profile below is read-only context. Never invent missing values.
- Whenever the customer explicitly provides an email, phone, first name, last name,
  display name, company, city, or country, call contact_enrich before claiming it
  was saved. Send only values explicitly stated by the customer.
- If the authoritative profile already contains the same normalized value, do not
  call contact_enrich again.
- Read the structured tool response. Claim only appliedFields were saved.
- If requiresConfirmation contains fields, naturally ask whether those exact fields
  should replace the values on file. Do not claim they were updated.
- After the customer clearly approves replacement, call contact_enrich again with
  only those values and list their names in confirmedFields.
- If the tool reports an error, respond naturally without claiming any field was saved.
- Never expose tool JSON, internal field names, IDs, or implementation details.
- You must write the customer-facing response yourself from the tool result. Do not
  use a fixed success or conflict message.
- Respond in plain text only. Never emit HTML tags such as <p>, <b>, <ul>, or <li>.
"""

COUNTRY_TIMEZONE_MAP = {
    "India": "Asia/Kolkata",
    "United States": "America/New_York",
    "Australia": "Australia/Sydney",
    "United Kingdom": "Europe/London",
    "Japan": "Asia/Tokyo",
    "Russia": "Europe/Moscow",
    "United Arab Emirates": "Asia/Dubai",
    "Germany": "Europe/Berlin",
    "South Africa": "Africa/Johannesburg",
}


def _build_contact_system_suffix(profile: ContactProfileSnapshot) -> str:
    return CONTACT_ENRICH_GUIDANCE + "\n" + format_contact_profile_block(profile)


def _refresh_router_contact_profile(
    router: AgentRouter,
    profile: ContactProfileSnapshot,
) -> None:
    suffix = _build_contact_system_suffix(profile)
    routing = router.routing_instruction
    for agent in router.agents.values():
        base = getattr(agent, "_profile_free_system", "")
        if not base:
            continue
        agent.update_system(
            [
                {
                    "role": "system",
                    "content": base + suffix + routing,
                }
            ]
        )


def get_time_by_country(country_name: str) -> tuple[str, str]:
    try:
        tz_name = COUNTRY_TIMEZONE_MAP.get(country_name, "Asia/Kolkata")
        country_time = datetime.now(ZoneInfo(tz_name))
        formatted_time = country_time.strftime("%A, %d %B %Y, %I:%M %p")
        return (
            f"Current time in {country_name} ({tz_name}): {formatted_time}",
            formatted_time,
        )
    except Exception:
        return "", ""


def setup_router(
    *,
    conversation_id: str,
    organization_id: str,
    tenant_context: dict[str, Any],
    channel: str,
    country_name: str = "India",
) -> tuple[AgentRouter, str]:
    set_turn_context(
        conversation_id,
        {
            "conversation_id": conversation_id,
            "organization_id": organization_id,
            "tenant_context": tenant_context,
            "channel": channel,
            "contact_profile": tenant_context.get("contact_profile") or {},
        },
    )

    profile = ContactProfileSnapshot.from_mapping(
        tenant_context.get("contact_profile") or {}
    )

    if session_manager.is_session_present(conversation_id):
        router = session_manager.get_router(conversation_id)
        _refresh_router_contact_profile(router, profile)
        _, formatted_time = get_time_by_country(country_name)
        return router, formatted_time

    current_date, formatted_time = get_time_by_country(country_name)
    longterm_memory = tenant_context.get("_lola_long_term_summary") or get_conversation_summary(
        organization_id, conversation_id, formatted_time
    )
    contact_context = _build_contact_system_suffix(profile)

    if conversation_id not in longterm_cache:
        longterm_cache[conversation_id] = {
            "islongterm": 0 if longterm_memory == "No information provided" else 1,
        }

    sales_prompt = apply_social_overlay(
        SALES_SYSTEM_PROMPT.format(current_date=current_date, long_term_summary=longterm_memory)
        + contact_context,
        channel,
    )
    service_prompt = apply_social_overlay(
        SERVICE_SYSTEM_PROMPT.format(current_date=current_date, long_term_summary=longterm_memory)
        + contact_context,
        channel,
    )
    booking_prompt = apply_social_overlay(
        BOOKING_SYSTEM_PROMPT.format(current_date=current_date, long_term_summary=longterm_memory)
        + contact_context,
        channel,
    )

    llm = get_worktual_llm()
    live_agent_tool = Tool(LIVE_AGENT, live_agent)
    call_back_tool = Tool(CALL_BACK, call_back)
    contact_enrich_tool = Tool(CONTACT_ENRICH, contact_enrich)

    sales_agent = Agent(
        name="SalesAgent",
        system=sales_prompt,
        tools=[
            Tool(GET_SALES_KNOWLEDGE, get_sales_knowledge),
            Tool(WEB_SEARCH_TOOL, websearch_tool),
            contact_enrich_tool,
            live_agent_tool,
            call_back_tool,
        ],
        llm=llm,
        handoff_instruction=(
            "sales-focused conversational assistant that engages new prospects, "
            "understands their needs, and drives conversions."
        ),
    )
    sales_agent._profile_free_system = apply_social_overlay(
        SALES_SYSTEM_PROMPT.format(current_date=current_date, long_term_summary=longterm_memory),
        channel,
    )
    booking_agent = Agent(
        name="BookingAgent",
        system=booking_prompt,
        tools=[
            Tool(VALIDATE_PHONE_NUMBER, validate_phone_number),
            Tool(VALIDATE_EMAIL, validate_email),
            Tool(CALENDAR_TOOL, calendar_tool),
            Tool(BOOK_APPOINTMENT, book_appointment),
            Tool(RESCHEDULE_APPOINTMENT, reschedule_meeting),
            contact_enrich_tool,
            live_agent_tool,
            call_back_tool,
        ],
        llm=llm,
        handoff_instruction="Booking Assistant for appointments and demos.",
    )
    booking_agent._profile_free_system = apply_social_overlay(
        BOOKING_SYSTEM_PROMPT.format(current_date=current_date, long_term_summary=longterm_memory),
        channel,
    )
    service_agent = Agent(
        name="ServiceAgent",
        system=service_prompt,
        tools=[
            Tool(GET_SERVICE_KNOWLEDGE, get_service_knowledge),
            Tool(VALIDATE_EMAIL, validate_email),
            Tool(VERIFY_CONTACT_FOR_TICKET, verify_contact_for_ticket),
            Tool(SEND_OTP, account_verification),
            Tool(VERIFY_OTP, verify_otp),
            Tool(CREATE_TICKET, create_ticket),
            Tool(GET_TICKET_STATUS, get_ticket_status),
            contact_enrich_tool,
            live_agent_tool,
            call_back_tool,
        ],
        llm=llm,
        handoff_instruction="support assistant for service queries, tickets, and troubleshooting.",
    )
    service_agent._profile_free_system = apply_social_overlay(
        SERVICE_SYSTEM_PROMPT.format(current_date=current_date, long_term_summary=longterm_memory),
        channel,
    )

    agent_router = AgentRouter(
        agents=[sales_agent, service_agent, booking_agent],
        memory=Memory(),
    )
    router = session_manager.create_router(conversation_id, agent_router)
    return router, formatted_time


def run_worktual_turn(
    *,
    organization_id: str,
    conversation_id: str,
    message: str,
    tenant_context: dict[str, Any],
    channel: str,
) -> dict[str, Any]:
    country = str(tenant_context.get("primaryLocation") or tenant_context.get("country") or "India")
    if "," in country:
        country = country.split(",")[-1].strip()

    router, formatted_time = setup_router(
        conversation_id=conversation_id,
        organization_id=organization_id,
        tenant_context=tenant_context,
        channel=channel,
        country_name=country or "India",
    )

    result = router.execute(
        message,
        "",
        "",
        "",
        conversation_id,
        "",
        "",
        conversation_id,
        "",
        organization_id,
        formatted_time,
        longterm_cache,
    )
    response = str(result.get("response") or "").replace("<<", "<").replace(">>", ">")
    return {
        "reply": response,
        "handoff_recommended": bool(result.get("handoff_recommended")),
        "messages": router.memory.get_session_messages(),
        "from_agent": result.get("from"),
    }
