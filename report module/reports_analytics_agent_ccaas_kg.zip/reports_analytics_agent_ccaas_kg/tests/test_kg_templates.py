"""Tests for CCaaS certified Cypher templates and schema registry loading."""

from core.loader import (
    load_rules,
    load_schema_registry,
    load_templates,
)


def test_certified_templates_loaded():
    templates = load_templates().get("templates", {})
    assert len(templates) >= 5
    assert "conversation_volume_summary" in templates
    assert "channel_comparison_root_cause" in templates
    assert "queue_wait_times_and_performance" in templates
    assert "agent_workload_and_performance" in templates
    assert "conversation_outcomes_and_reasons" in templates


def test_schema_registry_structure():
    reg = load_schema_registry()
    labels = reg.get("labels", [])
    assert "Conversation" in labels
    assert "Queue" in labels
    assert "Staff" in labels


def test_rules_loaded():
    rules = load_rules()
    assert rules.get("ontology_domain") == "CCaaS Contact Center Knowledge Graph"
    assert rules.get("governance_rules", {}).get("read_only", {}).get("enforced") is True
