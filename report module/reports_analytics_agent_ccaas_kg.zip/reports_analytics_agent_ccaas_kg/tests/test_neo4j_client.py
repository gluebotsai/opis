"""Tests for live Neo4j database client connection and tenant isolation."""

from core.kg_client import Neo4jClient, normalize_org_db


def test_tenant_db_normalization():
    assert normalize_org_db("1012") == "org1012"
    assert normalize_org_db("org_1012") == "org1012"
    assert normalize_org_db("org1012") == "org1012"


def test_neo4j_read_query_live():
    client = Neo4jClient.get_instance()
    # Simple read query to check live Neo4j connectivity
    res = client.execute_cypher("RETURN 1 AS online", org_id="1012")
    assert res.status == "success"
    assert len(res.rows) == 1
    assert res.rows[0]["online"] == 1


def test_neo4j_conversation_count_live():
    client = Neo4jClient.get_instance()
    res = client.execute_cypher("MATCH (c:Conversation) RETURN count(c) AS cnt", org_id="1012")
    assert res.status == "success"
    assert len(res.rows) == 1
    assert res.rows[0]["cnt"] >= 0
