"""Tests for CCaaS RBAC permissions and sensitive credentials protection."""

import pytest
from core.access import (
    AccessDenied,
    can_access_sensitive_pii,
    validate_role_kg_template_access,
)


def test_admin_has_full_access():
    assert can_access_sensitive_pii("admin") is True
    # Admin is authorized for all templates
    validate_role_kg_template_access("admin", "conversation_volume_summary")
    validate_role_kg_template_access("admin", "agent_workload_and_performance")


def test_agent_role_restricted():
    assert can_access_sensitive_pii("agent") is False
    # Agent can access general volume
    validate_role_kg_template_access("agent", "conversation_volume_summary")
    # Agent is blocked from general agent workload rankings across all staff
    with pytest.raises(AccessDenied, match="not authorized to execute CCaaS template"):
        validate_role_kg_template_access("agent", "agent_workload_and_performance")


def test_team_lead_permissions():
    assert can_access_sensitive_pii("team_lead") is False
    validate_role_kg_template_access("team_lead", "queue_wait_times_and_performance")
    validate_role_kg_template_access("team_lead", "agent_workload_and_performance")
