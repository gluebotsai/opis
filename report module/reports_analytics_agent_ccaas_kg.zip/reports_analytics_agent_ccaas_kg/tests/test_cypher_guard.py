"""Tests for CCaaS Cypher AST guardrails and read-only enforcement."""

import pytest
from core.cypher_guard import (
    CypherSecurityViolation,
    validate_and_guard_cypher,
)
from core.models import AgentContext


def test_guard_blocks_create():
    with pytest.raises(CypherSecurityViolation, match="Forbidden Cypher clause detected: 'CREATE'"):
        validate_and_guard_cypher("CREATE (c:Conversation {id: 'conv_1'})")


def test_guard_blocks_merge():
    with pytest.raises(CypherSecurityViolation, match="Forbidden Cypher clause detected: 'MERGE'"):
        validate_and_guard_cypher("MERGE (q:Queue {name: 'Escalations'})")


def test_guard_blocks_delete():
    with pytest.raises(CypherSecurityViolation, match="Forbidden Cypher clause detected: 'DELETE'"):
        validate_and_guard_cypher("MATCH (c:Conversation) DELETE c")


def test_guard_blocks_detach_delete():
    with pytest.raises(CypherSecurityViolation, match="Forbidden Cypher clause detected: 'DETACH'"):
        validate_and_guard_cypher("MATCH (s:Staff) DETACH DELETE s")


def test_guard_blocks_set_property():
    with pytest.raises(CypherSecurityViolation, match="Forbidden Cypher clause detected: 'SET'"):
        validate_and_guard_cypher("MATCH (c:Conversation) SET c.status = 'closed'")


def test_guard_blocks_multiple_statements():
    with pytest.raises(CypherSecurityViolation, match="Multiple Cypher statements are not allowed"):
        validate_and_guard_cypher("MATCH (c:Conversation) RETURN c; MATCH (q:Queue) RETURN q;")


def test_guard_caps_excessive_limit():
    guarded = validate_and_guard_cypher("MATCH (c:Conversation) RETURN c LIMIT 5000")
    assert "LIMIT 100" in guarded.cypher


def test_guard_appends_default_limit():
    guarded = validate_and_guard_cypher("MATCH (c:Conversation) RETURN c")
    assert "LIMIT 100" in guarded.cypher


def test_guard_blocks_sensitive_credentials_for_agent():
    ctx = AgentContext(role="agent")
    with pytest.raises(CypherSecurityViolation, match="not authorized to query sensitive"):
        validate_and_guard_cypher("MATCH (s:Staff) RETURN s.name, s.password", context=ctx)


def test_guard_blocks_ticketing_entities():
    with pytest.raises(CypherSecurityViolation, match="restricted from querying ticketing entities"):
        validate_and_guard_cypher("MATCH (t:Ticket) RETURN t")

    with pytest.raises(CypherSecurityViolation, match="restricted from querying ticketing entities"):
        validate_and_guard_cypher("MATCH (s:TicketSLA) RETURN s")

    with pytest.raises(CypherSecurityViolation, match="restricted from querying ticketing entities"):
        validate_and_guard_cypher("MATCH (t:Ticket)-[:HAS_TICKET_AUDIT_TRAIL]->(a:TicketAuditTrail) RETURN a")


def test_guard_normalizes_casing_variations():
    # Test IN with TitleCase and lowercase
    q1 = "MATCH (c:Conversation) WHERE c.status IN ['Closed', 'BOT_ACTIVE', 'Queued'] RETURN count(c)"
    g1 = validate_and_guard_cypher(q1)
    assert "toLower(c.status) IN ['closed', 'bot_active', 'queued']" in g1.cypher

    # Test single equality with mixed case
    q2 = "MATCH (c:Conversation) WHERE c.status = 'Closed' RETURN count(c)"
    g2 = validate_and_guard_cypher(q2)
    assert "toLower(c.status) = 'closed'" in g2.cypher

    # Test reversed equality
    q3 = "MATCH (c:Conversation) WHERE 'Closed' = c.status RETURN count(c)"
    g3 = validate_and_guard_cypher(q3)
    assert "'closed' = toLower(c.status)" in g3.cypher

    # Test inequality
    q4 = "MATCH (c:Conversation) WHERE c.status <> 'Closed' RETURN count(c)"
    g4 = validate_and_guard_cypher(q4)
    assert "toLower(c.status) <> 'closed'" in g4.cypher

    # Test CONTAINS
    q5 = "MATCH (c:Conversation) WHERE c.channel CONTAINS 'Web' RETURN count(c)"
    g5 = validate_and_guard_cypher(q5)
    assert "toLower(c.channel) CONTAINS 'web'" in g5.cypher

    # Test already toLower wrapped property with uppercase value
    q6 = "MATCH (c:Conversation) WHERE toLower(c.status) = 'Closed' RETURN count(c)"
    g6 = validate_and_guard_cypher(q6)
    assert "toLower(c.status) = 'closed'" in g6.cypher

