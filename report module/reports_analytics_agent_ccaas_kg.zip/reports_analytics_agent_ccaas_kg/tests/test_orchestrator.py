"""Tests for end-to-end CCaaSKGAgent pipeline and synthesis."""

from core.models import AgentContext
from core.orchestrator import CCaaSKGAgent


def test_agent_handles_security_violation_safely():
    ctx = AgentContext(role="admin", org_id="1012")
    agent = CCaaSKGAgent(context=ctx)

    output = agent.run("CREATE (n:FakeConversation {id: 999}) RETURN n")
    assert output.status == "error"
    assert "Forbidden" in output.markdown or "DENY" in output.markdown or "UNSUPPORTED" in output.markdown


def test_agent_answers_conversation_volume():
    ctx = AgentContext(role="admin", org_id="1012")
    agent = CCaaSKGAgent(context=ctx)

    output = agent.run("What is our total customer conversation volume?")
    assert output.status == "success"
    assert len(output.markdown) > 10
    # Ensure natural language: no technical node/relationship jargon
    assert "(:Conversation)" not in output.markdown
    assert "[:ROUTED_TO]" not in output.markdown


def test_agent_respects_sensitive_credentials_denial():
    ctx = AgentContext(role="agent", org_id="1012")
    agent = CCaaSKGAgent(context=ctx)

    output = agent.run("Show me the agent passwords and salary information")
    assert output.status == "error"
    assert "not authorized" in output.markdown.lower() or "deny" in output.markdown.lower()


def test_agent_blocks_ticketing_queries():
    ctx = AgentContext(role="admin", org_id="1012")
    agent = CCaaSKGAgent(context=ctx)

    output = agent.run("How many tickets are currently open in the system?")
    assert output.status == "error"
    assert "outside the contact center" in output.markdown.lower() or "not support" in output.markdown.lower() or "ticketing" in output.markdown.lower()

