"""Interactive Test Interface for CCaaS Knowledge Graph Agent with Live Audit Logging."""

import sys
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

import streamlit as st
from core.audit_logger import LOG_FILE_MD, get_query_count, log_query_interaction
from core.models import AgentContext
from core.orchestrator import CCaaSKGAgent

st.set_page_config(
    page_title="CCaaS Knowledge Graph Test Interface",
    layout="wide",
)

st.title("CCaaS Knowledge Graph Agent")

# Sidebar for Audit Log management and preview
with st.sidebar:
    st.header("Test Audit Log")
    total_logged = get_query_count()
    st.metric(label="Queries Recorded", value=total_logged)

    if st.button("Clear Audit Log"):
        if LOG_FILE_MD.exists():
            LOG_FILE_MD.unlink()
        raw_log = PROJECT_ROOT / "query_audit.log"
        if raw_log.exists():
            raw_log.unlink()
        st.success("Audit log cleared. Ready for fresh test batch.")
        st.rerun()

    st.markdown("---")
    st.subheader("Live Log Viewer")
    if LOG_FILE_MD.exists() and LOG_FILE_MD.stat().st_size > 0:
        log_content = LOG_FILE_MD.read_text(encoding="utf-8")
        st.text_area("Audit Content (Markdown):", value=log_content, height=450)
    else:
        st.info("Log is empty. Run queries to start recording.")

# Main test panel
st.markdown(
    "Query the Contact Center Knowledge Graph. Every query executed is **automatically recorded** "
    f"in [`query_audit.md`](file://{str(LOG_FILE_MD)}) with exact Cypher, status, and full response."
)

query = st.text_input(
    "Enter Contact Center Query:",
    placeholder="e.g. Why do unresolved conversations happen more often in queues with frequent transfers?",
    key="query_input",
)

if st.button("Run Query") or (query and st.session_state.get("last_query") != query):
    if query.strip():
        st.session_state["last_query"] = query
        with st.spinner("Processing contact center query..."):
            agent = CCaaSKGAgent(context=AgentContext(role="admin", org_id="1012"))
            output = agent.run(query.strip())
            q_num = log_query_interaction(
                user_query=query.strip(),
                output=output,
                role="admin",
                org_id="1012",
            )

        st.success(f"Recorded in Audit Log as **Query #{q_num}** ({output.status.upper()})")

        # Two-column layout for response and query details
        col1, col2 = st.columns([3, 2])

        with col1:
            st.subheader("Agent Response:")
            st.markdown(output.markdown)

        with col2:
            st.subheader("Query Telemetry:")
            st.write(f"**Status**: `{output.status.upper()}`")
            st.write(f"**Attempts**: `{output.attempts_made}`")
            if output.cypher_used:
                st.write("**Cypher Executed:**")
                for c_query in output.cypher_used:
                    st.code(c_query, language="cypher")
            else:
                st.caption("_No Cypher executed._")
