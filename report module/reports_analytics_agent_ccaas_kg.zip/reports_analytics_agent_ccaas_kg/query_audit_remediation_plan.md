# CCaaS Knowledge Graph Agent — Remediation Plan & Audit Diagnostics

**Generated**: 2026-09-28 21:15:00  
**Target Path**: `/home/vectone/shiva/cursor_report_agent/reports_analytics_agent_ccaas_kg/`  
**Database**: `org1012`  

---

## 1. Executive Summary & Audit Log Diagnostic

A deep audit of [`query_audit.md`](file:///home/vectone/shiva/cursor_report_agent/reports_analytics_agent_ccaas_kg/query_audit.md) and [`query_audit.log`](file:///home/vectone/shiva/cursor_report_agent/reports_analytics_agent_ccaas_kg/query_audit.log) reveals that while the agent successfully executes Cypher, **the underlying answers suffer from 5 critical structural flaws**:

| Query # in Audit | User Question | Fatal Flaw in Agent's Execution | Root Cause in Code / Schema |
| :--- | :--- | :--- | :--- |
| **#1, #2, #3, #4, #8** | Channels requiring more routing attempts / handoff problems / transfer loops | Agent claimed: *"There are no recorded system-level failures (such as no_ready_agents or live_agent_unavailable) in this dataset."* | Template `transfer_loops_and_chained_sessions` ran `ORDER BY c1.id DESC LIMIT 20`. This truncated out Conversation `144789` where the system failure flags actually live! |
| **#7** | *"Why do missed conversations happen more often after bot escalation?"* | Agent ran the same generic `CONTINUES` query and claimed: *"There are no recorded system failure flags... customers are choosing to leave."* | `MissedContact` node label and relationship `(:Conversation)-[:HAS]->(:MissedContact)` are **completely missing** from `schema_registry.json`! |
| **#12** | *"Why do some bot sessions generate more messages before escalation than others?"* | Agent concluded: *"Because there are zero recorded escalations in this dataset... no handoffs have taken place."* | Agent filtered on non-existent `end_reason = 'bot_handoff'` and `c.bot_active = true`, completely missing all handoffs (`c.handoff_reason`). |
| **#5, #11** | Unresolved outcomes & missed conversations | Agent claimed agents engaged in *"lengthy interactions averaging ~36 minutes before declining."* | Failure to segregate handle time by channel. An asynchronous email open for 5.5 hours was averaged into 3-minute voice calls. |
| **#1, #2, #7, #8** | 4 completely distinct questions | Agent picked the **exact same query template** 6 times in a row without adapting to the specific analytical intent. | Template registry lacks dedicated templates for bot escalations and missed contacts. |

---

## 2. The 3 Missing Schema Elements in `schema_registry.json`

### A. Missing Node Label: `MissedContact`
In Neo4j database `org1012`, there is an explicit node:
```cypher
(:Conversation {id: 144789})-[:HAS]->(mc:MissedContact:ContactCentre {
    id: 1247,
    reason: 'no_agent_available',
    custom_reasonCode: 'no_ready_agents',
    channel: 'webchat',
    queue_id: 1029,
    missed_at: datetime('2026-09-27T14:17:23.029622Z')
})
```
* **Impact:** Because `MissedContact` was not registered in `schema_registry.json`, the LLM planner could never query it, causing Query #7 to fail completely and claim no missed contacts exist.

### B. Missing Properties on `Conversation`
The following properties are heavily populated in Neo4j but omitted from `schema_registry.json`:
1. `c.handoff_reason`: Contains `'User requested live agent'` (present on 26 conversations).
2. `c.previous_conversation_id`: Tracks the previous session in a reconnect chain.

### C. Missing Relationship Type: `HAS`
`Conversation` connects to `MissedContact` and `ConversationHistory` via `-[:HAS]->`. It must be registered in the relationships list.

---

## 3. The Flawed Certified Template in `templates.yml`

In [`ontology/templates.yml`](file:///home/vectone/shiva/cursor_report_agent/reports_analytics_agent_ccaas_kg/ontology/templates.yml#L163-L176):

### Current Flawed Template:
```cypher
MATCH (c1:Conversation)-[:CONTINUES]->(c2:Conversation)
RETURN c1.id AS from_conversation_id,
       c2.id AS to_conversation_id,
       c1.channel AS channel,
       c1.facts AS system_facts,
       c1.summary AS system_summary,
       coalesce(c1.end_actor, 'unknown') AS end_actor,
       coalesce(c1.end_reason, 'unknown') AS end_reason
ORDER BY c1.id DESC
LIMIT 20
```

### Why It Fails:
1. `ORDER BY c1.id DESC LIMIT 20` fetches sessions `146723` down to `146676`. Conversation `144789` (where the failure happened) is ID 144,789, so it is chopped off by the `LIMIT 20`!
2. In `(144906)-[:CONTINUES]->(144789)`, `144789` is `c2`, not `c1`. Inspecting only `c1.facts` returns `null`!
3. It does not check `handoff_reason` or `MissedContact`.

---

## 4. Remediation Code Changes

### Step 1: Update `ontology/schema_registry.json`

Add `MissedContact` to `labels`, `HAS` to `relationships`, and the missing properties to `Conversation`:

```json
{
  "labels": [
    "Conversation",
    "ContactCentre",
    "MissedContact",
    ...
  ],
  "relationships": [
    "ROUTED_TO",
    "HANDLED_BY",
    "CONTINUES",
    "HAS",
    ...
  ],
  "properties": {
    "Conversation": [
      "id",
      "channel",
      "status",
      "lifecycle_state",
      "end_reason",
      "end_actor",
      "sla_status",
      "bot_active",
      "live_agent_enabled",
      "nlp_enabled",
      "visitor_id",
      "contact_id",
      "priority",
      "subject",
      "resolution_code",
      "resolution_summary",
      "disposition_code",
      "disposition_note",
      "custom_conclusion",
      "assigned_agent_id",
      "assigned_user_id",
      "queue_id",
      "facts",
      "summary",
      "handoff_reason",
      "previous_conversation_id",
      "created_at",
      "ended_at",
      "resolved_at",
      "updated_at",
      "organization_id"
    ],
    "MissedContact": [
      "id",
      "conversation_id",
      "queue_id",
      "channel",
      "reason",
      "custom_reasonCode",
      "customer_name",
      "customer_email",
      "customer_phone",
      "missed_at"
    ]
  }
}
```

---

### Step 2: Replace & Add Templates in `ontology/templates.yml`

#### 1. Fix `transfer_loops_and_chained_sessions`:
```yaml
  transfer_loops_and_chained_sessions:
    description: Analysis of transferred, continued, and chained sessions across webchat and voice, inspecting routing failure facts (no_ready_agents, live_agent_unavailable) across both sides of the continuation.
    parameters: []
    cypher: |
      MATCH (c1:Conversation)-[:CONTINUES]->(c2:Conversation)
      WITH c1, c2,
           coalesce(c1.facts, c2.facts, []) AS combined_facts,
           coalesce(c1.summary, c2.summary, '') AS combined_summary,
           coalesce(c1.handoff_reason, c2.handoff_reason, 'none') AS handoff_reason
      RETURN c1.id AS from_session_id,
             c2.id AS to_session_id,
             c1.channel AS channel,
             handoff_reason,
             combined_facts AS system_facts,
             combined_summary AS system_summary,
             coalesce(c1.end_actor, 'unknown') AS from_end_actor,
             coalesce(c1.end_reason, 'unknown') AS from_end_reason,
             coalesce(c2.end_actor, 'unknown') AS to_end_actor,
             coalesce(c2.end_reason, 'unknown') AS to_end_reason
      ORDER BY CASE WHEN size(combined_facts) > 0 THEN 0 ELSE 1 END, c1.id DESC
      LIMIT 25
```

#### 2. Add New Template: `bot_escalation_and_missed_contacts` (For Query #7 and #11):
```yaml
  bot_escalation_and_missed_contacts:
    description: Analysis of bot-to-agent escalations resulting in missed contacts, inspecting reason codes (no_ready_agents, no_agent_available) and customer drop-offs.
    parameters: []
    cypher: |
      MATCH (c:Conversation)
      WHERE c.handoff_reason IS NOT NULL 
         OR exists((c)-[:HAS]->(:MissedContact))
         OR any(f IN coalesce(c.facts, []) WHERE f IN ['live_agent_unavailable', 'no_ready_agents'])
      OPTIONAL MATCH (c)-[:HAS]->(mc:MissedContact)
      OPTIONAL MATCH (c)-[:ROUTED_TO]->(q)
      OPTIONAL MATCH (c)-[:HANDLED_BY]->(a)
      RETURN c.id AS conversation_id,
             c.channel AS channel,
             c.handoff_reason AS handoff_reason,
             coalesce(mc.reason, 'none') AS missed_contact_reason,
             coalesce(mc.custom_reasonCode, 'none') AS missed_reason_code,
             coalesce(q.name, 'Support Queue') AS queue_name,
             coalesce(a.display_name, 'None (Unassigned)') AS assigned_agent,
             c.status AS status,
             coalesce(c.resolution_code, 'none') AS resolution_code,
             c.end_actor AS end_actor,
             c.end_reason AS end_reason,
             c.facts AS telemetry_facts,
             c.summary AS system_summary
      ORDER BY c.id DESC
      LIMIT 20
```

#### 3. Add New Template: `bot_sessions_and_handoff_volume` (For Query #12):
```yaml
  bot_sessions_and_handoff_volume:
    description: Analysis of bot sessions, message volume, and handoff triggers, verifying whether escalations occurred via handoff_reason or missed contact.
    parameters: []
    cypher: |
      MATCH (c:Conversation)
      RETURN c.channel AS channel,
             count(c) AS total_conversations,
             count(CASE WHEN c.handoff_reason IS NOT NULL THEN 1 END) AS handoffs_requested,
             count(CASE WHEN exists((c)-[:HAS]->(:MissedContact)) THEN 1 END) AS missed_contacts_logged,
             count(CASE WHEN any(f IN coalesce(c.facts, []) WHERE f = 'no_ready_agents') THEN 1 END) AS no_ready_agent_failures,
             count(CASE WHEN c.assigned_agent_id IS NOT NULL THEN 1 END) AS transferred_to_human_staff,
             round(avg(duration.between(c.created_at, c.ended_at).seconds), 1) AS avg_duration_seconds
      ORDER BY total_conversations DESC
```

---

### Step 3: Update `agent.md` Directives

Add these 3 specific directives into `agent.md` to prevent future regressions:

1. **Prioritize Root-Cause Prioritization over ID DESC:**  
   *"When querying continuation chains `[:CONTINUES]`, sort priority by sessions with non-empty `facts` or `summary` rather than purely `c1.id DESC` to avoid chopping off root escalation failures."*
2. **Channel-Segregated Handle Times:**  
   *"Always report average handle times separated by channel (`call` vs. `email` vs. `webchat`). Never report a blended average where an asynchronous 5-hour email distorts 3-minute phone calls."*
3. **Escalation Property Definition:**  
   *"Escalations in this schema are indicated by `c.handoff_reason IS NOT NULL` (e.g. `'User requested live agent'`) or `(:Conversation)-[:HAS]->(:MissedContact)`. NEVER filter for fictitious values like `end_reason = 'bot_handoff'`."*
