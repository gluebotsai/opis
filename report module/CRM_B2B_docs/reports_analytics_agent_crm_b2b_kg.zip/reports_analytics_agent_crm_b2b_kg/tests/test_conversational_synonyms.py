"""Unit tests verifying that the agent dynamically understands conversational phrasing and synonyms without hardcoding."""

import pytest
from core.models import AgentContext
from core.orchestrator import CRMB2BKGAgent


@pytest.fixture
def admin_agent():
    ctx = AgentContext(org_id=1003, role="admin", user_id=1015)
    return CRMB2BKGAgent(context=ctx)


def test_conversational_failed_deals(admin_agent):
    """User asks 'why did our deals fail?' instead of 'deal_root_cause_loss'."""
    res = admin_agent.run("why did our deals fail?")
    assert res.status == "success"
    assert len(res.cypher_used) > 0
    assert any("closed_lost" in q.lower() or "lost_reason" in q.lower() for q in res.cypher_used)


def test_conversational_unpaid_bills(admin_agent):
    """User asks 'show me unpaid bills that are late' instead of 'overdue_invoice_aging_and_risk'."""
    res = admin_agent.run("show me unpaid bills that are late")
    assert res.status == "success"
    assert len(res.cypher_used) > 0
    assert any("invoice" in q.lower() for q in res.cypher_used)


def test_conversational_unclaimed_prospects(admin_agent):
    """User asks 'what prospects do not have an owner yet?' instead of 'unassigned_leads_pool'."""
    res = admin_agent.run("what prospects do not have an owner yet?")
    assert res.status == "success"
    assert len(res.cypher_used) > 0
    assert any("salesprofile" in q.lower() for q in res.cypher_used)


def test_conversational_active_agreements(admin_agent):
    """User asks 'which agreements are currently active?' instead of 'contract_arr_and_renewals'."""
    res = admin_agent.run("which agreements are currently active?")
    assert res.status == "success"
    assert len(res.cypher_used) > 0
    assert any("contract" in q.lower() for q in res.cypher_used)
