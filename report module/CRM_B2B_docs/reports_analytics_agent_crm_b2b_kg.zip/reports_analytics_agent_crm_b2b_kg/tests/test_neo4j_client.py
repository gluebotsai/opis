"""Unit tests for CRM B2B Neo4j Client and Database Router."""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.kg_client import Neo4jClient, normalize_org_db


def test_normalize_org_db():
    assert normalize_org_db(1003) == "org1003"
    assert normalize_org_db("1003") == "org1003"
    assert normalize_org_db("org1003") == "org1003"
    assert normalize_org_db("org_1003") == "org1003"
    assert normalize_org_db(1012) == "org1012"
    assert normalize_org_db(None) == "org1003"


def test_neo4j_client_singleton():
    c1 = Neo4jClient.get_instance()
    c2 = Neo4jClient.get_instance()
    assert c1 is c2


def test_live_neo4j_read_query():
    client = Neo4jClient.get_instance()
    # Test reading active tenant org1003
    res = client.execute_cypher("RETURN 1 as test_val", org_id=1003)
    assert res.status == "success"
    assert res.row_count == 1
    assert res.rows[0]["test_val"] == 1


def test_nonexistent_org_db_fails_honestly():
    client = Neo4jClient.get_instance()
    res = client.execute_cypher("RETURN 1 as test_val", org_id=999999)
    assert res.status == "error"
    assert res.error_type == "DB_ERROR"
    assert "Database does not exist" in res.error or "error" in res.error.lower()
