"""Unit tests for CRM B2B Cypher Query Guardrail."""

import pytest
import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.cypher_guard import (
    CypherSecurityViolation,
    MAX_CYPHER_LIMIT,
    normalize_cypher_case_insensitivity,
    validate_and_guard_cypher,
)
from core.models import AgentContext


def test_reject_mutating_cypher():
    mutating_queries = [
        "CREATE (d:Deal {title: 'New Deal'})",
        "MATCH (d:Deal) DELETE d",
        "MATCH (d:Deal) DETACH DELETE d",
        "MATCH (d:Deal) SET d.amount = 5000",
        "MATCH (d:Deal) REMOVE d.forecast_category",
        "MERGE (a:Account {name: 'Acme'})",
        "DROP INDEX ON :Deal(id)",
        "ALTER USER neo4j SET PASSWORD '123'",
        "CALL dbms.components()",
        "LOAD CSV FROM 'file:///deals.csv' AS row",
    ]
    for q in mutating_queries:
        with pytest.raises(CypherSecurityViolation):
            validate_and_guard_cypher(q)


def test_reject_empty_and_multistatement():
    with pytest.raises(CypherSecurityViolation):
        validate_and_guard_cypher("")

    with pytest.raises(CypherSecurityViolation):
        validate_and_guard_cypher("MATCH (d:Deal) RETURN d; MATCH (a:Account) RETURN a;")


def test_reject_sensitive_credentials():
    with pytest.raises(CypherSecurityViolation):
        validate_and_guard_cypher("MATCH (u:User) RETURN u.password")

    with pytest.raises(CypherSecurityViolation):
        validate_and_guard_cypher("MATCH (k:ApiKey) RETURN k.api_key_hash")


def test_reject_ticketing_leakage():
    with pytest.raises(CypherSecurityViolation):
        validate_and_guard_cypher("MATCH (t:Ticket) RETURN t.id, t.subject")

    with pytest.raises(CypherSecurityViolation):
        validate_and_guard_cypher("MATCH (ts:TicketSLA) RETURN ts.display_name")


def test_enforce_limit_cap():
    # Automatically add LIMIT if missing
    res1 = validate_and_guard_cypher("MATCH (d:Deal) RETURN d.id")
    assert f"LIMIT {MAX_CYPHER_LIMIT}" in res1.cypher

    # Cap excessive LIMIT to 100
    res2 = validate_and_guard_cypher("MATCH (d:Deal) RETURN d.id LIMIT 5000")
    assert f"LIMIT {MAX_CYPHER_LIMIT}" in res2.cypher

    # Preserve smaller LIMIT
    res3 = validate_and_guard_cypher("MATCH (d:Deal) RETURN d.id LIMIT 25")
    assert "LIMIT 25" in res3.cypher


def test_normalize_case_insensitivity():
    q = "MATCH (d:Deal) WHERE d.stage = 'Closed_Won' AND d.lost_reason = 'Pricing' RETURN d"
    normalized = normalize_cypher_case_insensitivity(q)
    assert "toLower(d.stage) = 'closed_won'" in normalized
    assert "toLower(d.lost_reason) = 'pricing'" in normalized

    q_in = "MATCH (d:Deal) WHERE d.stage IN ['Qualification', 'Discover'] RETURN d"
    norm_in = normalize_cypher_case_insensitivity(q_in)
    assert "toLower(d.stage) IN ['qualification', 'discover']" in norm_in
