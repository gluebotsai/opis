"""Unit tests for CRM B2B RBAC and Row-Level Scoping Policies."""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.access import (
    AccessDenied,
    can_view_all_records,
    get_effective_user_scope,
    validate_agents_ops_access,
    validate_finance_access,
    validate_role_kg_template_access,
)


def test_org_wide_visibility_flags():
    assert can_view_all_records("admin") is True
    assert can_view_all_records("sales_manager") is True
    assert can_view_all_records("finance") is True
    assert can_view_all_records("sales_rep") is False
    assert can_view_all_records("presales") is False
    assert can_view_all_records("marketing") is False
    assert can_view_all_records("viewer") is False


def test_fail_closed_user_scoping():
    # Org-wide roles do not fail closed to sentinel 0
    assert get_effective_user_scope("admin", None) == 0
    assert get_effective_user_scope("admin", 1000) == 1000

    # Non-org-wide roles MUST fail closed to sentinel 0 when user_id is missing or None
    assert get_effective_user_scope("sales_rep", None) == 0
    assert get_effective_user_scope("sales_rep", 0) == 0
    assert get_effective_user_scope("sales_rep", 1005) == 1005
    assert get_effective_user_scope("viewer", None) == 0


def test_finance_access_governance():
    # Admin, sales_manager, finance can access
    validate_finance_access("admin")
    validate_finance_access("sales_manager")
    validate_finance_access("finance")

    # Rep, marketing, viewer are denied
    with pytest.raises(AccessDenied):
        validate_finance_access("sales_rep")

    with pytest.raises(AccessDenied):
        validate_finance_access("marketing")

    with pytest.raises(AccessDenied):
        validate_finance_access("viewer")


def test_agents_ops_access_governance():
    validate_agents_ops_access("admin")
    validate_agents_ops_access("sales_manager")

    with pytest.raises(AccessDenied):
        validate_agents_ops_access("finance")

    with pytest.raises(AccessDenied):
        validate_agents_ops_access("sales_rep")


def test_role_kg_template_governance():
    # Admin can run anything
    validate_role_kg_template_access("admin", "deal_root_cause_loss")
    validate_role_kg_template_access("admin", "finance_approval_queue")

    # Sales rep can run deal loss and pipeline templates
    validate_role_kg_template_access("sales_rep", "deal_root_cause_loss")
    validate_role_kg_template_access("sales_rep", "open_pipeline_health")

    # Sales rep cannot run finance approval queue
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("sales_rep", "finance_approval_queue")

    # Marketing cannot run deal loss
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("marketing", "deal_root_cause_loss")


def test_non_admin_roles_template_governance():
    """Verify granular template access across all non-admin roles."""
    # Sales Manager: full access across sales, finance, and operations
    validate_role_kg_template_access("sales_manager", "deal_root_cause_loss")
    validate_role_kg_template_access("sales_manager", "finance_approval_queue")
    validate_role_kg_template_access("sales_manager", "unassigned_leads_pool")

    # Sales Rep: allowed sales templates, denied standalone finance and unassigned pool
    validate_role_kg_template_access("sales_rep", "deal_root_cause_loss")
    validate_role_kg_template_access("sales_rep", "open_pipeline_health")
    validate_role_kg_template_access("sales_rep", "quote_acceptance_and_friction")
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("sales_rep", "finance_approval_queue")
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("sales_rep", "invoice_outstanding_and_due")
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("sales_rep", "unassigned_leads_pool")

    # Presales: same sales access as rep, denied standalone finance
    validate_role_kg_template_access("presales", "deal_root_cause_loss")
    validate_role_kg_template_access("presales", "open_pipeline_health")
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("presales", "finance_approval_queue")

    # Finance: allowed finance templates, denied sales pipeline and marketing
    validate_role_kg_template_access("finance", "finance_approval_queue")
    validate_role_kg_template_access("finance", "invoice_outstanding_and_due")
    validate_role_kg_template_access("finance", "contract_arr_and_renewals")
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("finance", "deal_root_cause_loss")
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("finance", "open_pipeline_health")
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("finance", "pipeline_by_owner")

    # Marketing: allowed contacts and activities, denied sales pipeline and finance
    validate_role_kg_template_access("marketing", "lead_status_mix")
    validate_role_kg_template_access("marketing", "lead_source_conversion")
    validate_role_kg_template_access("marketing", "open_task_and_touch_cadence")
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("marketing", "deal_root_cause_loss")
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("marketing", "open_pipeline_health")
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("marketing", "finance_approval_queue")

    # Viewer: read-only sales access, denied finance
    validate_role_kg_template_access("viewer", "open_pipeline_health")
    validate_role_kg_template_access("viewer", "top_open_opportunities")
    with pytest.raises(AccessDenied):
        validate_role_kg_template_access("viewer", "finance_approval_queue")


def test_non_admin_live_row_scoping():
    """Verify live database row-scoping against org1003 for non-admin roles."""
    from core.models import AgentContext
    from core.kg_runner import execute_kg_template

    # 1. Rep 1017 owns no lost deals -> must return 0 records
    ctx_1017 = AgentContext(org_id=1003, role="sales_rep", user_id=1017)
    res_1017, fact_1017 = execute_kg_template("deal_root_cause_loss", ctx_1017)
    assert res_1017.status == "success"
    assert res_1017.row_count == 0

    # 2. Rep 1015 owns the lost deal ('crm', $125,500, Pricing) -> must return exactly 1 row
    ctx_1015 = AgentContext(org_id=1003, role="sales_rep", user_id=1015)
    res_1015, fact_1015 = execute_kg_template("deal_root_cause_loss", ctx_1015)
    assert res_1015.status == "success"
    assert res_1015.row_count == 1
    assert res_1015.rows[0]["lost_reason"] == "Pricing"
    assert res_1015.rows[0]["total_lost_amount"] in (1255.0, 1255, 125500)

    # 3. Missing user_id (None) -> fail-closed sentinel 0 -> 0 records
    ctx_none = AgentContext(org_id=1003, role="sales_rep", user_id=None)
    res_none, fact_none = execute_kg_template("deal_root_cause_loss", ctx_none)
    assert res_none.status == "success"
    assert res_none.row_count == 0

    # 4. Sales Manager -> sees all 12 open deals across org
    ctx_mgr = AgentContext(org_id=1003, role="sales_manager", user_id=1014)
    res_mgr, fact_mgr = execute_kg_template("open_pipeline_health", ctx_mgr)
    assert res_mgr.status == "success"
    total_mgr_deals = sum(r["deal_count"] for r in res_mgr.rows)
    assert total_mgr_deals == 12

    # 5. Sales Rep 1017 -> sees only their 3 open deals
    res_rep_pipe, _ = execute_kg_template("open_pipeline_health", ctx_1017)
    assert res_rep_pipe.status == "success"
    total_rep_deals = sum(r["deal_count"] for r in res_rep_pipe.rows)
    assert total_rep_deals == 3

    # 6. Finance -> denied deal_root_cause_loss, allowed finance_approval_queue
    ctx_fin = AgentContext(org_id=1003, role="finance", user_id=1016)
    res_fin_deal, _ = execute_kg_template("deal_root_cause_loss", ctx_fin)
    assert res_fin_deal.status == "error"
    assert res_fin_deal.error_type == "DENY"

    res_fin_queue, _ = execute_kg_template("finance_approval_queue", ctx_fin)
    assert res_fin_queue.status == "success"
    assert res_fin_queue.row_count == 3

    # 7. Marketing -> denied open_pipeline_health, allowed lead_status_mix scoped to 8 contacts for 1018
    ctx_mkt = AgentContext(org_id=1003, role="marketing", user_id=1018)
    res_mkt_pipe, _ = execute_kg_template("open_pipeline_health", ctx_mkt)
    assert res_mkt_pipe.status == "error"
    assert res_mkt_pipe.error_type == "DENY"

    res_mkt_lead, _ = execute_kg_template("lead_status_mix", ctx_mkt)
    assert res_mkt_lead.status == "success"
    total_mkt_contacts = sum(r["contact_count"] for r in res_mkt_lead.rows)
    assert total_mkt_contacts == 8

    # 8. Viewer 1017 -> sees only their 3 open deals
    ctx_view = AgentContext(org_id=1003, role="viewer", user_id=1017)
    res_view, _ = execute_kg_template("top_open_opportunities", ctx_view)
    assert res_view.status == "success"
    assert res_view.row_count == 3
    for row in res_view.rows:
        assert row["owner_user_id"] == 1017
