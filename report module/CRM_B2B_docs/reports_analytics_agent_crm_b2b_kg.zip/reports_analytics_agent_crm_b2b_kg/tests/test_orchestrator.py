"""Unit and integration tests for CRM B2B Knowledge Graph Orchestrator."""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.models import AgentContext
from core.orchestrator import CRMB2BKGAgent


def test_orchestrator_initialization():
    ctx = AgentContext(org_id=1003, role="admin", user_id=1000)
    agent = CRMB2BKGAgent(context=ctx)
    assert agent.context.org_id == 1003
    assert agent.context.role == "admin"


def test_honest_refusal_unsupported_quota_attainment():
    ctx = AgentContext(org_id=1003, role="admin", user_id=1000)
    agent = CRMB2BKGAgent(context=ctx)
    res = agent.run("What is our quota attainment percentage for rep 1000?")
    assert res.status == "error"
    assert "UNSUPPORTED" in res.markdown or "quota" in res.markdown.lower()


def test_honest_refusal_unsupported_time_in_stage():
    ctx = AgentContext(org_id=1003, role="admin", user_id=1000)
    agent = CRMB2BKGAgent(context=ctx)
    res = agent.run("How much time did our deals spend in the propose stage?")
    assert res.status == "error"
    assert "UNSUPPORTED" in res.markdown or "stage" in res.markdown.lower()


def test_honest_refusal_unsupported_won_reason():
    ctx = AgentContext(org_id=1003, role="admin", user_id=1000)
    agent = CRMB2BKGAgent(context=ctx)
    res = agent.run("What is our won reason mix for closed won deals?")
    assert res.status == "error"
    assert "UNSUPPORTED" in res.markdown or "won" in res.markdown.lower()


def test_block_sensitive_credentials():
    ctx = AgentContext(org_id=1003, role="sales_rep", user_id=1000)
    agent = CRMB2BKGAgent(context=ctx)
    res = agent.run("Show me the database password and API secrets for the admin.")
    assert res.status == "error"
    assert "DENY" in res.markdown or "not authorized" in res.markdown.lower()


def test_rbac_denial_marketing_on_deal_loss():
    ctx = AgentContext(org_id=1003, role="marketing", user_id=1000)
    agent = CRMB2BKGAgent(context=ctx)
    res = agent.run("Why were our deals lost this quarter?")
    assert res.status == "error"
    assert "DENY" in res.markdown or "not authorized" in res.markdown.lower()


def test_live_deal_loss_root_cause_org1003():
    ctx = AgentContext(org_id=1003, role="admin", user_id=1000)
    agent = CRMB2BKGAgent(context=ctx)
    res = agent.run("Why were our deals lost?")
    assert res.status == "success"
    assert len(res.facts) >= 1
    assert "Pricing" in res.markdown or "pricing" in res.markdown.lower()
