"""Unit tests for CRM B2B Certified Cypher Templates."""

import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.cypher_guard import validate_and_guard_cypher
from core.loader import load_templates
from core.models import AgentContext


def test_templates_load_and_contain_required_fields():
    templates_dict = load_templates().get("templates", {})
    assert len(templates_dict) >= 15

    for t_name, t_meta in templates_dict.items():
        assert "description" in t_meta, f"Template {t_name} missing description"
        assert "cypher" in t_meta, f"Template {t_name} missing cypher query"
        cypher = t_meta["cypher"].strip()
        assert len(cypher) > 10, f"Template {t_name} cypher query is too short"


def test_templates_comply_with_cypher_guardrail():
    templates_dict = load_templates().get("templates", {})
    ctx = AgentContext(org_id=1003, role="admin", user_id=1000)

    for t_name, t_meta in templates_dict.items():
        raw_cypher = t_meta["cypher"]
        # Validate through security guardrail
        guarded = validate_and_guard_cypher(raw_cypher, params={"org_id": 1003}, context=ctx)
        assert "LIMIT" in guarded.cypher
        # Ensure no write operations in any certified template
        for forbidden in ["CREATE", "DELETE", "DETACH", "SET", "MERGE", "DROP", "ALTER"]:
            assert forbidden not in guarded.cypher.upper().split()


def test_core_kpi_templates_exist():
    templates_dict = load_templates().get("templates", {})
    expected_core = [
        "deal_root_cause_loss",
        "deal_forecast_risk_and_stall",
        "open_pipeline_health",
        "top_open_opportunities",
        "deal_commercial_path_walk",
        "quote_acceptance_and_friction",
        "invoice_outstanding_and_due",
        "overdue_invoice_aging_and_risk",
        "collected_revenue_mix",
        "finance_approval_queue",
        "contract_arr_and_renewals",
        "customer_account_commercial_summary",
        "lead_status_mix",
        "unassigned_leads_pool",
        "sales_velocity_breakdown",
    ]
    for key in expected_core:
        assert key in templates_dict, f"Expected template '{key}' not found in registry"
