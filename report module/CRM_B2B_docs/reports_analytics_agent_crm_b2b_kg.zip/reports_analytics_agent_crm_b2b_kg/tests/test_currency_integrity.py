"""Unit tests verifying currency integrity, quote currency traversal, and zero currency mixing."""

import pytest
from core.models import AgentContext
from core.kg_runner import execute_kg_template
from core.synthesis import _build_markdown_table, _currency_symbol


def test_deal_quote_currency_and_value_traversal():
    """Verify that open deals traverse to approved quotes to get true currency and value."""
    ctx = AgentContext(org_id=1003, role="admin", user_id=1015)
    res, fact = execute_kg_template("top_open_opportunities", ctx)
    assert res.status == "success"
    assert res.row_count > 0

    # GRT Jewellers has approved quote Q-00004 ($12,394 USD)
    grt_deal = next((r for r in res.rows if "GRT Jewellers" in str(r.get("company_name"))), None)
    assert grt_deal is not None
    assert grt_deal.get("currency") == "USD"
    assert grt_deal.get("amount") in (123.94, 12394)


def test_invoice_returns_inr_currency():
    """Verify that invoice templates return INR and do not default to USD."""
    ctx = AgentContext(org_id=1003, role="admin", user_id=1015)
    res, fact = execute_kg_template("invoice_outstanding_and_due", ctx)
    assert res.status == "success"
    assert res.row_count > 0
    for r in res.rows:
        assert r.get("currency") == "INR"


def test_table_builder_multi_currency_separation():
    """Verify that table builder never mixes USD and INR into a single combined sum."""
    test_rows = [
        {"deal_title": "Enterprise Deal", "amount": 10000, "currency": "USD"},
        {"deal_title": "Domestic Invoice", "amount": 500000, "currency": "INR"},
    ]
    table_md, totals = _build_markdown_table(test_rows, include_totals=True)
    assert "Total" in table_md
    # Total must NOT be 510000! It must present USD and INR separately!
    assert "510,000" not in table_md
    assert "$10,000 (USD)" in table_md or "10,000" in table_md
    assert "₹500,000 (INR)" in table_md or "500,000" in table_md


def test_currency_symbol_mapping():
    """Verify correct currency symbols for standard global currencies."""
    assert _currency_symbol("USD") == "$"
    assert _currency_symbol("INR") == "₹"
    assert _currency_symbol("EUR") == "€"
    assert _currency_symbol("GBP") == "£"
    assert _currency_symbol(None) == ""
    assert _currency_symbol("None") == ""
    assert _currency_symbol("N/A") == ""


def test_sales_velocity_currency_and_quote_amount():
    """Verify sales velocity returns USD currency and accurate non-zero pipeline from quotes."""
    ctx = AgentContext(org_id=1003, role="admin", user_id=1015)
    res, fact = execute_kg_template("sales_velocity_breakdown", ctx)
    assert res.status == "success"
    assert res.row_count > 0
    row = res.rows[0]
    assert row.get("currency") == "USD"
    assert row.get("total_pipeline") > 0


def test_deal_aging_bands_currency_and_quote_amount():
    """Verify deal aging bands return USD currency and non-zero amount from quotes."""
    ctx = AgentContext(org_id=1003, role="admin", user_id=1015)
    res, fact = execute_kg_template("deal_aging_bands", ctx)
    assert res.status == "success"
    assert res.row_count > 0
    assert any(r.get("currency") == "USD" for r in res.rows)
    assert any(r.get("total_amount", 0) > 0 for r in res.rows)


def test_deals_by_period_currency_and_quote_amount():
    """Verify deals by period return USD currency and accurate deal amounts."""
    ctx = AgentContext(org_id=1003, role="admin", user_id=1015)
    res, fact = execute_kg_template("deals_by_period_or_month", ctx)
    assert res.status == "success"
    assert res.row_count > 0
    sept = next((r for r in res.rows if r.get("year") == 2026 and r.get("month") == 9), None)
    assert sept is not None
    assert sept.get("currency") == "USD"
    assert sept.get("total_amount") > 0


def test_customer_account_commercial_summary_currencies():
    """Verify account summary distinguishes deal currency (USD or tenant INR) from invoice currency (INR)."""
    ctx = AgentContext(org_id=1003, role="admin", user_id=1015)
    res, fact = execute_kg_template("customer_account_commercial_summary", ctx)
    assert res.status == "success"
    assert res.row_count > 0
    for r in res.rows:
        assert r.get("deal_currency") in ("USD", "INR")
        assert r.get("invoice_currency") == "INR"

    # Accounts with USD quotes (like Open AI) must preserve USD
    openai_acc = next((r for r in res.rows if "Open AI" in str(r.get("company_name"))), None)
    if openai_acc:
        assert openai_acc.get("deal_currency") == "USD"


def test_dynamic_tenant_location_currency_resolution():
    """Verify that org1003 resolves default currency to INR from Tenant.country ('India')."""
    from core.kg_client import resolve_org_default_currency
    curr = resolve_org_default_currency(1003)
    assert curr == "INR"


def test_deal_without_quote_defaults_to_org_location_currency():
    """Verify that a won deal with no quote (Dell) defaults to tenant location currency (INR), while deals with USD quotes preserve USD."""
    ctx = AgentContext(org_id=1003, role="admin", user_id=1015)
    res, fact = execute_kg_template("won_deals_overview", ctx)
    assert res.status == "success"
    assert res.row_count > 0
    # Dell deal has no quote, so it defaults to tenant location currency (INR)
    dell_deal = next((r for r in res.rows if "Dell" in str(r.get("deal_title"))), None)
    assert dell_deal is not None
    assert dell_deal.get("currency") == "INR"


