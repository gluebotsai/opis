"""Test suite for CRM B2B Knowledge Graph Agent."""
