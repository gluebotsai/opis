"""Interactive Test Interface for CRM B2B Knowledge Graph Agent with Live Audit Logging."""

import sys
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

import streamlit as st
from core.audit_logger import LOG_FILE_MD, get_query_count
from core.models import AgentContext
from core.orchestrator import CRMB2BKGAgent

st.set_page_config(
    page_title="CRM B2B Knowledge Graph Agent",
    layout="wide",
)

st.title("CRM B2B Knowledge Graph Agent")

# Sidebar for Context & Audit Log
with st.sidebar:
    st.header("Caller Context")
    role = st.selectbox(
        "RBAC Role:",
        ["admin", "sales_manager", "sales_rep", "presales", "finance", "marketing", "viewer"],
        index=0,
    )
    org_id = st.number_input("Organization ID:", value=1003, step=1)
    user_id = st.number_input("User ID:", value=1015, step=1)
    st.caption("Active reps in org1003: 1015, 1017, 1018, 1028, 1066")

    st.markdown("---")
    st.header("Test Audit Log")
    total_logged = get_query_count()
    st.metric(label="Queries Recorded", value=total_logged)

    if st.button("Clear Audit Log"):
        if LOG_FILE_MD.exists():
            LOG_FILE_MD.unlink()
        raw_log = PROJECT_ROOT / "query_audit.log"
        if raw_log.exists():
            raw_log.unlink()
        st.success("Audit log cleared. Ready for fresh test batch.")
        st.rerun()

    st.markdown("---")
    st.subheader("Live Log Viewer")
    if LOG_FILE_MD.exists() and LOG_FILE_MD.stat().st_size > 0:
        log_content = LOG_FILE_MD.read_text(encoding="utf-8")
        st.text_area("Audit Content (Markdown):", value=log_content, height=400)
    else:
        st.info("Log is empty. Run queries to start recording.")

# Main test panel
st.markdown(
    "Query the **CRM B2B Commercial Knowledge Graph** (Neo4j). Every query executed is **automatically recorded** "
    f"in [`query_audit.md`](file://{str(LOG_FILE_MD)}) with exact Cypher, status, and full response."
)

# Quick query suggestions
st.markdown("**Sample Analytical Queries:**")
cols = st.columns(3)
with cols[0]:
    if st.button("Why were our deals lost?"):
        st.session_state["query_input"] = "Why were our deals lost?"
    if st.button("What is our lead status mix?"):
        st.session_state["query_input"] = "What is our lead status mix across contacts?"
with cols[1]:
    if st.button("Which deals are stalling in forecast?"):
        st.session_state["query_input"] = "Which deals are at risk of stalling or slipping out of the forecast?"
    if st.button("Show overdue invoices and delays"):
        st.session_state["query_input"] = "Show me all overdue invoices and why they are delayed"
with cols[2]:
    if st.button("Active pipeline by stage & weight"):
        st.session_state["query_input"] = "What is our current active pipeline by stage and weighted value?"
    if st.button("Quota attainment (Honest Refusal)"):
        st.session_state["query_input"] = "What is the quota attainment percentage for sales rep 1000?"

default_query = st.session_state.get("query_input", "")
query = st.text_input(
    "Enter CRM B2B Query:",
    value=default_query,
    placeholder="e.g. Why were our deals lost this quarter?",
    key="current_input",
)

if st.button("Run Query") or (query and st.session_state.get("last_query") != query):
    if query.strip():
        st.session_state["last_query"] = query
        with st.spinner("Processing Knowledge Graph query..."):
            ctx = AgentContext(org_id=int(org_id), role=role, user_id=int(user_id))
            agent = CRMB2BKGAgent(context=ctx)
            output = agent.run(query.strip())

            st.markdown("---")
            if output.status == "success":
                st.success(f"Status: SUCCESS (Attempts: {output.attempts_made})")
            else:
                st.error(f"Status: {output.status.upper()} (Attempts: {output.attempts_made})")

            # Cypher inspection
            if output.cypher_used:
                with st.expander("Executed Cypher Queries", expanded=False):
                    for q in output.cypher_used:
                        st.code(q.strip(), language="cypher")

            # Executive Synthesis
            st.markdown("### Executive Commercial Briefing")
            st.markdown(output.markdown)
