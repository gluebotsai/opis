"""FastAPI Server exposing CRM B2B Knowledge Graph Agent REST Endpoints."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any, Optional

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from core.kg_client import Neo4jClient
from core.models import AgentContext, SynthesisOutput
from core.orchestrator import CRMB2BKGAgent

app = FastAPI(
    title="CRM B2B Knowledge Graph Analytics Agent",
    description="Autonomous Knowledge Graph reporting, analytics, traversal, and root-cause explanation service.",
    version="1.0.0",
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class QueryRequest(BaseModel):
    """Incoming query request payload."""
    query: str = Field(..., description="Natural language question to ask the CRM B2B Knowledge Graph.", example="Why were our deals lost?")
    org_id: int = Field(default=1003, description="Tenant organization ID.", example=1003)
    role: str = Field(default="admin", description="RBAC Role: admin, sales_manager, sales_rep, presales, finance, marketing, viewer.", example="admin")
    user_id: Optional[int] = Field(default=1015, description="Caller user ID for row-level scoping.", example=1015)


class FactItem(BaseModel):
    """Structured fact item extracted from Knowledge Graph."""
    label: str
    value: Any = None
    unit: Optional[str] = None
    breakdown: Optional[list[dict[str, Any]]] = None


class QueryResponse(BaseModel):
    """Structured response payload returned to caller."""
    status: str
    query: str
    org_id: int
    role: str
    user_id: Optional[int]
    markdown: str
    attempts_made: int
    cypher_used: list[str]
    facts: list[FactItem]
    error: Optional[str] = None


@app.get("/health")
def health_check():
    """Health check endpoint verifying Neo4j connectivity."""
    try:
        client = Neo4jClient.get_instance()
        res = client.execute_cypher("RETURN 1 as ping", org_id=1003)
        neo4j_healthy = (res.status == "success")
    except Exception:
        neo4j_healthy = False

    return {
        "status": "healthy" if neo4j_healthy else "degraded",
        "agent": "reports_analytics_agent_crm_b2b_kg",
        "neo4j_connected": neo4j_healthy,
        "default_org_id": 1003,
    }


def _sanitize_for_json(obj: Any) -> Any:
    """Recursively convert neo4j DateTime, Date, Time, Duration and custom objects into JSON-serializable types."""
    if obj is None:
        return None
    if isinstance(obj, (int, float, str, bool)):
        return obj
    if hasattr(obj, "isoformat"):
        return obj.isoformat()
    if hasattr(obj, "to_native"):
        return obj.to_native().isoformat()
    if isinstance(obj, dict):
        return {k: _sanitize_for_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [_sanitize_for_json(item) for item in obj]
    return str(obj)


@app.post("/api/v1/crm-b2b/query", response_model=QueryResponse)
def execute_query(req: QueryRequest) -> QueryResponse:
    """Execute dynamic planning, Cypher traversal, and executive briefing synthesis."""
    if not req.query.strip():
        raise HTTPException(status_code=400, detail="Query cannot be empty.")

    ctx = AgentContext(
        org_id=req.org_id,
        role=req.role.lower().strip(),
        user_id=req.user_id,
    )

    agent = CRMB2BKGAgent(context=ctx)
    result: SynthesisOutput = agent.run(req.query.strip())

    fact_items = []
    for f in result.facts:
        fact_items.append(
            FactItem(
                label=f.label,
                value=_sanitize_for_json(f.value),
                unit=f.unit,
                breakdown=_sanitize_for_json(f.breakdown),
            )
        )

    return QueryResponse(
        status=result.status,
        query=req.query.strip(),
        org_id=req.org_id,
        role=req.role,
        user_id=req.user_id,
        markdown=result.markdown,
        attempts_made=result.attempts_made,
        cypher_used=result.cypher_used,
        facts=fact_items,
        error=result.error,
    )


if __name__ == "__main__":
    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=False)
