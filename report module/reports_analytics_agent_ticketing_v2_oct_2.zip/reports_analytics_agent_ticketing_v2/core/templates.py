"""Fill named slots. No business lists in this file."""

from __future__ import annotations

from pathlib import Path

TRUE = "TRUE"

TICKETING_DIMENSION_EXPR: dict[str, str] = {
    "status": "status",
    "priority": "priority",
    "channel": "channel",
    "category": "category",
    "queue": "queue_name",
    "agent": "assignee_name",
    "resolver": "resolver_name",
    "customer": "customer_name",
    "created_by": "created_by_name",
    "day": "DATE_TRUNC('day', created_at)::date",
    "week": "DATE_TRUNC('week', created_at)::date",
    "month": "DATE_TRUNC('month', created_at)::date",
}

TICKETING_DIMENSION_ALIASES: dict[str, str] = {
    "assignee": "agent",
    "owner": "agent",
    "queue_name": "queue",
}


def dimension_slots(dimension: str | None, allowed: list | None) -> tuple[str, str]:
    """Certified KPI GROUP BY expressions. Empty when no dimension is requested."""
    if not dimension:
        return "", ""
    raw = str(dimension).strip().lower()
    if raw in {"", "null", "none"}:
        return "", ""
    dim = TICKETING_DIMENSION_ALIASES.get(raw, raw)
    allowed_ids = {str(a).strip().lower() for a in (allowed or []) if a}
    if allowed_ids and dim not in allowed_ids:
        return "", ""
    expr = TICKETING_DIMENSION_EXPR.get(dim)
    if not expr:
        return "", ""
    return f"{expr} AS {dim},", f"GROUP BY {expr} ORDER BY 2 DESC NULLS LAST"


def fill_slots(sql: str, slots: dict[str, str], *, base_ticket: str | None = None) -> str:
    out = sql
    if base_ticket is not None:
        out = out.replace("{{base_ticket}}", base_ticket)
    mapping = {
        "org_id": slots["org_id"],
        "tenant_sql": slots.get("tenant_sql", f"organization_id = {slots['org_id']}"),
        "scope_sql": slots.get("scope_sql", TRUE),
        "time_sql": slots.get("time_sql", TRUE),
        "segment_sql": slots.get("segment_sql", TRUE),
        "filters_sql": slots.get("filters_sql", TRUE),
        "dimension_select": slots.get("dimension_select", ""),
        "group_by_sql": slots.get("group_by_sql", ""),
        "window_days": slots.get("window_days", "1"),
        "window_days_sql": slots.get("window_days_sql", "1"),
        "segment_predicate": slots.get("segment_predicate", slots.get("segment_sql", TRUE)),
        "limit_sql": slots.get("limit_sql", ""),
    }
    for key, value in mapping.items():
        out = out.replace("{{" + key + "}}", value)
    if "{{" in out:
        raise ValueError(f"unfilled SQL slots remain: {out}")
    return out


def load_sql(path: Path) -> str:
    return path.read_text()


def fill_named(text: str, slots: dict[str, str]) -> str:
    out = text
    for key, value in slots.items():
        out = out.replace("{{" + key + "}}", str(value))
    if "{{" in out:
        raise ValueError(f"unfilled slots remain: {out}")
    return out
