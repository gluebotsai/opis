# B2B CRM database reference for the reports spoke

This file is the table reference for the reports domain agent. The SQL executor uses it to know which table answers a metric, how tables join, and which columns are safe to filter. The knowledge-graph executor uses the purpose text and the sample row to explain why a number looks the way it does.

The CRM application stores its own rows in the `crm` schema. It reads and writes the shared product catalog in `inventory` and it reads and writes existing person and tenant columns in `cdp` and `accounts`. CRM does not create or alter tables in `cdp`, `accounts`, or `inventory`. Columns listed for those three schemas are the columns this CRM code already uses. If a column is not listed, the SQL executor must not invent it.

Every example row is an illustration that matches the real columns and enum values. It is not a copy of a production row.

## Why CRM reads accounts, cdp, and inventory

### accounts

CRM does not store the login user or the tenant. `accounts.organizations` is the tenant: its `id` is `organization_id` on every CRM row, `business_type` decides B2B versus B2C versus B2B2C, and `industry_type` selects the field pack. `accounts.setup_users` is the person who logs in. `accounts.setup_user_product_access` plus `accounts.setup_roles` is how that user gets a CRM role such as sales_rep or finance. `accounts.auth_sessions` is the live login. `accounts.mail_oauth_connections` and `accounts.a2a_spoke_clients` are shared connection records. Reports join `owner_user_id` and `created_by_user_id` to `accounts.setup_users.id` so a metric can show the owner's name. They filter `organization_id` so one tenant never sees another tenant's rows.

### cdp

CRM does not store the person's name, email, or phone on its own contact table. Those live in `cdp.customer_profile` and `cdp.identity_keys`. `crm.contact_profiles.account_contact_id` equals `cdp.customer_profile.cdp_id`. A contact report always joins those tables. Lead status, owner, company, BANT, and marketing opt-out stay on `crm.contact_profiles` because they are CRM facts, not shared identity facts. Soft-delete of a CRM contact is `crm.contact_profiles.crm_status`, not a delete of the CDP person. `cdp.products` is a different catalog and is not the product list CRM sells.

### inventory

The only product catalog is `inventory.products`. Quote lines, order lines, invoice lines, offers, add-ons, and price-book entries store `product_id` and join here for the product name, SKU, status, and billing type. CRM may insert and update existing product columns. It must not add columns. Revenue by product is the sum of commercial lines grouped by this id.

## Shared tables CRM uses outside Prisma

### accounts.organizations

Tenant root. One row is one Worktual customer organization.

CRM filters every query by organization id taken from the signed-in user. business_type gates modules. industry_type selects which extra fields a contact or company form shows.

Columns CRM already uses:

- id bigint PK
- business_type text — b2b, b2c, or b2b2c. B2C must not see finance.
- company_name text — tenant display name.
- industry_type text — mapped to the CRM field pack, not a separate industry table.

Example row:

```json
{
  "id": 42,
  "business_type": "b2b",
  "company_name": "Blue Harbor Logistics",
  "industry_type": "software"
}
```

### accounts.setup_users

Login user directory shared across Worktual products.

Deal owner, contact owner, and activity assignee store this id. A report joins it to print the rep name. Password columns are out of scope for both executors.

Columns CRM already uses:

- id bigint PK
- organization_id bigint FK to accounts.organizations.id
- work_email text — mailbox used for login and for meeting invites when no Google mailbox is connected.
- first_name text
- last_name text
- status text — active users can be assigned records.
- password_hash text — never select this in a report.
- password_set_at timestamptz
- updated_at timestamptz

Example row:

```json
{
  "id": 9001,
  "organization_id": 42,
  "work_email": "ava.khan@northwind.example",
  "first_name": "Priya",
  "last_name": "Shah",
  "status": "active"
}
```

### accounts.setup_roles

Role name catalog. CRM maps the name into admin, sales_manager, sales_rep, presales, marketing, finance, or viewer.

The SQL executor uses the resolved CRM role to decide owner scope. It does not invent new role names.

Columns CRM already uses:

- id bigint PK
- name text — role label joined through product access.

Example row:

```json
{
  "id": 3,
  "name": "Blue Harbor Logistics"
}
```

### accounts.setup_user_product_access

Grants one user one role on one product. CRM reads rows where product_id is crm.

This is how a user becomes a sales rep or a finance user inside CRM. Reports do not change this table.

Columns CRM already uses:

- user_id bigint FK to accounts.setup_users.id
- product_id text — crm for this application.
- role_id bigint FK to accounts.setup_roles.id

Example row:

```json
{
  "user_id": 9001,
  "product_id": "crm",
  "role_id": 3
}
```

### accounts.auth_sessions

Live login session for a user. CRM uses it to know who is signed in and to revoke a session.

Session health is an operations question, not a sales KPI. The SQL executor may count active sessions only for an admin operations report and must not return token material.

Columns CRM already uses:

- Columns are owned by accounts. CRM reads the session to resolve the user id and organization id. Do not project secrets or raw tokens into a report.

Example row:

```json
{
  "user_id": 9001,
  "organization_id": 42,
  "revoked": false
}
```

### accounts.mail_oauth_connections

Shared OAuth connection for a mailbox. CRM also keeps product-specific connection state in crm.user_integration_connections.

A coverage report can say whether a rep has connected mail. The token itself is never a report column.

Columns CRM already uses:

- Treat this as an accounts-owned connection row. Report only whether a connection exists for the user. Do not return refresh tokens.

Example row:

```json
{
  "user_id": 9001,
  "provider": "google",
  "connected": true
}
```

### accounts.a2a_spoke_clients

One Hub client id for this CRM spoke, plus the tokens Hub uses. Approved CRM-owned exception table inside accounts.

The reports agent does not need this table for KPIs. If an admin asks whether the spoke is registered, answer yes or no without secrets.

Columns CRM already uses:

- client_id text
- client_secret text — never select in a report.
- access and refresh tokens — never select in a report.

Example row:

```json
{
  "client_id": "crm-spoke",
  "has_secret": "[not readable by reports]"
}
```

### cdp.customer_profile

Shared person profile. One row is one human the tenant knows.

Contact name and employer on a report come from here. CRM sales status does not. Join to crm.contact_profiles on cdp_id = account_contact_id and to crm.companies when the overlay has a company_id.

Columns CRM already uses:

- cdp_id text PK — stored in crm.contact_profiles.account_contact_id.
- organization_id bigint
- contact_type text — values the CRM code branches on include contact, customer, and churned. Customer and churned are aligned to lead_status converted.
- first_name, last_name, company_name text when present on the shared row.
- custom_fields jsonb — CRM reads keys such as title, industry, company_domain, and address_line. Do not invent other keys.

Example row:

```json
{
  "cdp_id": "cdp_8f3a",
  "organization_id": 42,
  "contact_type": "contact",
  "first_name": "Priya",
  "last_name": "Shah",
  "company_name": "Blue Harbor Logistics",
  "custom_fields": {
    "title": "VP Operations",
    "industry": "logistics",
    "company_domain": "blueharbor.example"
  }
}
```

### cdp.identity_keys

Email and phone keys for a CDP person. Unique on organization_id, key_type, key_value.

Looking up a person by email or phone starts here, then joins customer_profile, then contact_profiles. A duplicate email in the same org is rejected by the unique key. Reports must not dump every email in the tenant unless the question asks for a contact list the role is allowed to see.

Columns CRM already uses:

- identity_id PK
- cdp_id FK to cdp.customer_profile.cdp_id ON DELETE CASCADE
- organization_id bigint
- key_type text — email, phone, email_secondary, phone_secondary
- key_value text
- source_system text
- verified boolean

Example row:

```json
{
  "identity_id": 55012,
  "cdp_id": "cdp_8f3a",
  "organization_id": 42,
  "key_type": "email",
  "key_value": "priya.shah@blueharbor.example",
  "source_system": "crm",
  "verified": true
}
```

### inventory.products

Shared product catalog. Prisma model Product maps to this table. Full column list is in the inventory.products section below.

Product revenue, attach rate, and catalog status all join here. Do not use cdp.products.

Columns CRM already uses:

- id is the product_id stored on quote, order, and invoice lines.

Example row:

```json
{
  "id": "row_1001",
  "name": "Blue Harbor Logistics",
  "status": "active",
  "billing_type": "recurring"
}
```

## Enumerations

These are the allowed values for categorical columns that use a Prisma enum. A filter that uses any other spelling will not match rows.

- `LocationType`: hq, branch
- `CompanyChannelRole`: standard, franchise, owned_store, brand_hq
- `OrganizationVertical`: general, ecommerce, healthcare, finance, telecom
- `DealStage`: qualification, discover, propose, negotiate, closed_won, closed_lost
- `ActivityType`: call, meeting, email, sms, note, task
- `TaskStatus`: open, in_progress, completed
- `InboxFolder`: inbox, sent, draft, trash
- `EmailDirection`: outbound, inbound
- `IntegrationProvider`: google, microsoft, zoom, yahoo
- `ProductStatus`: draft, active, archived
- `ProductType`: fixed, customizable
- `ProductBillingType`: one_time, recurring
- `ProductBillingFrequency`: monthly, quarterly, annual
- `ProductUnitOfMeasure`: per_seat, per_agent, per_ticket, flat
- `AddonPricingModel`: flat, per_unit, stepped, tiered
- `AddonMeterKey`: seat, minute, session, email, agent, flat, custom
- `QuoteStatus`: draft, sent, accepted, rejected, void
- `ProposalStatus`: draft, shared, accepted, declined
- `ProposalTemplateKind`: standard
- `QuoteTemplateKind`: standard
- `InvoiceTemplateKind`: standard
- `OrderStatus`: draft, confirmed, fulfilled, cancelled
- `InvoiceStatus`: draft, sent, paid, void, overdue
- `InvoiceLineKind`: product, addon
- `InvoiceBillingKind`: standard, setup, subscription_start, renewal, amendment, adjustment, credit
- `ContractStatus`: active, expired, cancelled
- `ContractBillingScheduleStatus`: scheduled, generated, cancelled
- `InvoicePaymentMethod`: offline, manual, stripe, razorpay
- `InvoicePaymentProvider`: stripe, razorpay
- `InvoicePaymentSessionStatus`: active, expired, paid, cancelled
- `PaymentGatewayProvider`: stripe, razorpay
- `AuditAction`: create, update, delete, stage_change, assign, convert, merge, quote_sent, quote_accepted, order_created, invoice_created
- `LeadEnrichmentStatus`: pending, running, enriched, skipped, failed
- `ProspectPullStatus`: pending, searching, qualifying, personnel, ready_for_review, importing, imported, failed, cancelled
- `ResearchProvider`: apollo, zoominfo, lusha, builtwith
- `ProposalCorpusBatchStatus`: uploading, processing, pending_review, failed, completed
- `ProposalCorpusItemKind`: requirement, proposal
- `ProposalCorpusItemStatus`: pending, ingested, structured, failed
- `ProposalCorpusJobStatus`: pending, ingesting, structuring, pairing, synthesizing, pending_review, failed, cancelled
- `ProposalPlaybookStatus`: draft, pending_review, approved, rejected
- `AgentStepStatus`: started, ok, failed, skipped
- `LeadNurtureStatus`: pending, analyzing, sent, waited, skipped, failed
- `LeadScoringStatus`: pending, scoring, scored, failed
- `LeadLifecycleStatus`: pending, analyzing, applied, waited, skipped, failed
- `EmailAutoReplyStatus`: pending, analyzing, replied, awaiting_demo, escalated, skipped, failed
- `MailProvider`: google, microsoft
- `SalesSeniorityTier`: junior, mid, senior
- `GmailPushWatchKind`: user, crm_bot
- `CalendarMeetCaptureStatus`: pending, dispatched, cancelled, failed
- `MeetingAssistStatus`: active, ended, failed
- `MeetingAssistProvider`: google_meet, zoom, teams, other
- `ProcessConfirmationStatus`: pending, approved, rejected, expired
- `AppointmentStatus`: scheduled, canceled, completed, no_show
- `AppointmentSource`: crm_ui, ccaas_webchat, demo_agent

String statuses that are not Prisma enums, taken from the CRM code that writes them:

- `crm.contact_profiles.lead_status`: new, contacted, qualified, disqualified, converted. `converted` is also written when CDP `contact_type` is customer or churned.
- `crm.contact_profiles.crm_status`: active is the live row. A report of current contacts filters `crm_status = active`.
- `crm.contact_profiles.disqualify_reason` and `assignment_reason` are short reason codes written by lifecycle and assignment jobs. Group by the stored code. Do not invent a code list beyond what is in the rows.

## CRM and inventory tables

### crm.companies

Prisma model `Company`.

This is the B2B account the sales team sells to. A row is one legal or operating company inside the tenant, with a name, optional parent for brand-to-store hierarchy, and a channel role that says whether it is a normal account, a franchise, an owned store, or a brand headquarters. CRM refers to this table whenever a deal, quote, order, invoice, contract, or contact must be tied to a company rather than only to a person.

Primary key: id.

Foreign keys and why the join exists:

- parentCompanyId -> Company.id on delete SetNull. Purpose of the join: crm.companies.id. Join it to walk from a store or franchise up to the brand.

Categorical columns:

- `CompanyChannelRole`: standard, franchise, owned_store, brand_hq.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `domain` | String | no |  | `domain` stores the domain for this row, typed as String. Select or group by it when the question is about domain. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `industry` | String | no |  | `industry` stores the industry for this row, typed as String. Select or group by it when the question is about industry. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `employee_count` | Int | no |  | `employee_count` stores the employee count for this row, typed as Int. Select or group by it when the question is about employee count. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `linkedin_url` | String | no |  | `linkedin_url` stores the linkedin url for this row, typed as String. Select or group by it when the question is about linkedin url. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `logo_url` | String | no |  | `logo_url` stores the logo url for this row, typed as String. Select or group by it when the question is about logo url. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `owner_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it to print the owner's name. Reps are filtered on this column. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `channel_role` | CompanyChannelRole | yes |  | Channel hierarchy under the same tenant (franchise B2B2C). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `parent_company_id` | String | no | FK | Foreign key to crm.companies.id. Join it to walk from a store or franchise up to the brand. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `expansion_signal` | String | no |  | Expansion & Revenue Matcher overlay (HITL): agent only flags a signal + drafts outreach talking points on closed-won deal history; never creates a deal/quote or contacts the company itself (human-only send). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `expansion_reason` | String | no |  | `expansion_reason` stores the expansion reason for this row, typed as String. Select or group by it when the question is about expansion reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `expansion_draft` | String | no |  | `expansion_draft` stores the expansion draft for this row, typed as String. Select or group by it when the question is about expansion draft. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `expansion_last_run_at` | DateTime | no |  | Timestamp for expansion last run. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `collection_risk_level` | String | no |  | Company Collection Risk Agent overlay (HITL): aggregates this company's whole invoice payment history into a risk band. Flag only — agent never blocks/pauses the account. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `collection_risk_reason` | String | no |  | `collection_risk_reason` stores the collection risk reason for this row, typed as String. Select or group by it when the question is about collection risk reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `collection_risk_last_run_at` | DateTime | no |  | Timestamp for collection risk last run. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "name": "Blue Harbor Logistics",
  "domain": "Blue Harbor Logistics",
  "industry": "Blue Harbor Logistics",
  "employee_count": 1,
  "linkedin_url": "Blue Harbor Logistics",
  "logo_url": "Blue Harbor Logistics",
  "owner_user_id": 42,
  "channel_role": "standard",
  "parent_company_id": "parentCompanyId_1001",
  "created_at": "2026-09-15T10:30:00Z"
}
```

### crm.company_locations

Prisma model `CompanyLocation`.

This stores an office or site that belongs to one company, such as headquarters or a branch, including address lines and an optional region code. Contacts and commercial documents can point at a location so a report can split pipeline and revenue by site instead of only by the parent company name.

Primary key: id.

Foreign keys and why the join exists:

- companyId -> Company.id on delete Cascade. Purpose of the join: crm.companies.id. Join it to show the account name, channel role, and parent company.

Categorical columns:

- `LocationType`: hq, branch.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `company_id` | String | yes | FK | Foreign key to crm.companies.id. Join it to show the account name, channel role, and parent company. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `type` | LocationType | yes |  | `type` stores the type for this row, typed as LocationType. Select or group by it when the question is about type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `address` | String | no |  | `address` stores the address for this row, typed as String. Select or group by it when the question is about address. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `city` | String | no |  | `city` stores the city for this row, typed as String. Select or group by it when the question is about city. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `industry` | String | no |  | `industry` stores the industry for this row, typed as String. Select or group by it when the question is about industry. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `employee_count` | Int | no |  | `employee_count` stores the employee count for this row, typed as Int. Select or group by it when the question is about employee count. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `owner_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it to print the owner's name. Reps are filtered on this column. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "company_id": "companyId_1001",
  "name": "Blue Harbor Logistics",
  "type": "hq",
  "address": "Blue Harbor Logistics",
  "city": "Blue Harbor Logistics",
  "industry": "Blue Harbor Logistics",
  "employee_count": 1,
  "owner_user_id": 42,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.contact_profiles

Prisma model `ContactProfile`.

This is the CRM overlay on a CDP person. The person name, email, and phone live in cdp.customer_profile and cdp.identity_keys; this row stores the sales fields those shared tables must not hold, including owner, lead status, company link, BANT, nurture state, and marketing opt-out. Every contact report joins this table to CDP on account_contact_id = cdp_id and filters by organization_id.

Primary key: id.

Foreign keys and why the join exists:

- companyId -> Company.id on delete SetNull. Purpose of the join: crm.companies.id. Join it to show the account name, channel role, and parent company.
- locationId -> CompanyLocation.id on delete SetNull. Purpose of the join: crm.company_locations.id. Join it to show the office or branch address.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `account_contact_id` | String | yes | unique FK | Foreign key to cdp.customer_profile.cdp_id. This is the bridge from the CRM overlay to the shared person. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `company_id` | String | no | FK | Foreign key to crm.companies.id. Join it to show the account name, channel role, and parent company. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `location_id` | String | no | FK | Foreign key to crm.company_locations.id. Join it to show the office or branch address. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `owner_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it to print the owner's name. Reps are filtered on this column. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `created_by_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it when the question is who created the row, which can differ from the current owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `assignment_reason` | String | no |  | Assignment Agent ownership (score-gated route) Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `sla_deadline` | DateTime | no |  | Timestamp for sla deadline. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `assigned_at` | DateTime | no |  | Timestamp for assigned. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `assignment_escalated` | Boolean | yes |  | `assignment_escalated` stores the assignment escalated for this row, typed as Boolean. Select or group by it when the question is about assignment escalated. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `nurture_status` | String | no |  | Nurturing Agent ownership overlay Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `nurture_sequence_step` | Int | no |  | `nurture_sequence_step` stores the nurture sequence step for this row, typed as Int. Select or group by it when the question is about nurture sequence step. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `nurture_started_at` | DateTime | no |  | Timestamp for nurture started. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `nurture_last_touch_at` | DateTime | no |  | Timestamp for nurture last touch. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `flagged_for_review` | Boolean | yes |  | Lifecycle Agent review flag (ambiguous evidence / stall) Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `flag_reason` | String | no |  | `flag_reason` stores the flag reason for this row, typed as String. Select or group by it when the question is about flag reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `lifecycle_last_action` | String | no |  | `lifecycle_last_action` stores the lifecycle last action for this row, typed as String. Select or group by it when the question is about lifecycle last action. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `lifecycle_last_reason` | String | no |  | `lifecycle_last_reason` stores the lifecycle last reason for this row, typed as String. Select or group by it when the question is about lifecycle last reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `lifecycle_last_run_at` | DateTime | no |  | Timestamp for lifecycle last run. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `lead_source` | String | no |  | `lead_source` stores the lead source for this row, typed as String. Select or group by it when the question is about lead source. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `lead_status` | String | yes |  | Where this person sits in the lead path: new, contacted, qualified, disqualified, or converted. Converted is also written when the CDP contact_type is customer or churned. This is CRM state. The person's name and email are not in this column. |
| `disqualify_reason` | String | no |  | `disqualify_reason` stores the disqualify reason for this row, typed as String. Select or group by it when the question is about disqualify reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `bant_budget` | Boolean | no |  | One BANT flag on the CRM contact overlay: budget, authority, need, or timeline. True means the rep or the lifecycle flow recorded that the buyer has that element. Null means it was not captured. Do not treat null as false in a qualification rate unless the question says to. |
| `bant_authority` | Boolean | no |  | One BANT flag on the CRM contact overlay: budget, authority, need, or timeline. True means the rep or the lifecycle flow recorded that the buyer has that element. Null means it was not captured. Do not treat null as false in a qualification rate unless the question says to. |
| `bant_need` | Boolean | no |  | One BANT flag on the CRM contact overlay: budget, authority, need, or timeline. True means the rep or the lifecycle flow recorded that the buyer has that element. Null means it was not captured. Do not treat null as false in a qualification rate unless the question says to. |
| `bant_timeline` | Boolean | no |  | One BANT flag on the CRM contact overlay: budget, authority, need, or timeline. True means the rep or the lifecycle flow recorded that the buyer has that element. Null means it was not captured. Do not treat null as false in a qualification rate unless the question says to. |
| `converted_deal_id` | String | no | FK | Foreign key to crm.deals.id. Join it to the opportunity created when the lead was converted. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `tags` | String[] | yes |  | `tags` stores the tags for this row, typed as String[]. Select or group by it when the question is about tags. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `crm_status` | String | yes |  | `crm_status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `notes` | String | no |  | This is the free-text note saved by a user or an agent. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `marketing_opt_out` | Boolean | yes |  | True when this person must not receive automated marketing. Nurture and campaign counts of people who can be mailed must exclude these rows. The timestamp beside it, when present, is when the opt-out was recorded. |
| `marketing_opt_out_at` | DateTime | no |  | Timestamp for marketing opt out. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `custom_attributes` | Json | no |  | Vertical pack field values (CRM overlay — never CDP columns). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `is_pinned` | Boolean | yes |  | `is_pinned` stores the is pinned for this row, typed as Boolean. Select or group by it when the question is about is pinned. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "account_contact_id": "accountContactId_1001",
  "organization_id": 42,
  "company_id": "companyId_1001",
  "location_id": "locationId_1001",
  "owner_user_id": 42,
  "created_by_user_id": 42,
  "assignment_reason": "round_robin",
  "sla_deadline": "2026-09-15T10:30:00Z",
  "assigned_at": "2026-09-15T10:30:00Z",
  "assignment_escalated": false,
  "nurture_status": "Blue Harbor Logistics"
}
```

### crm.organization_profiles

Prisma model `OrganizationProfile`.

This is optional CRM configuration for one tenant, keyed by the same organization id used in accounts.organizations. It holds the industry field-pack choice, internal email domains used to tell staff from customers, and related settings. Reports use it when a metric must respect tenant industry or internal-domain rules.

Primary key: organization_id.

Categorical columns:

- `OrganizationVertical`: general, ecommerce, healthcare, finance, telecom.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `organization_id` | BigInt | yes | PK FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `vertical` | OrganizationVertical | yes |  | `vertical` stores the vertical for this row, typed as OrganizationVertical. Select or group by it when the question is about vertical. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `vertical_config` | Json | yes |  | `vertical_config` stores the vertical config for this row, typed as Json. Select or group by it when the question is about vertical config. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `internal_domains` | String[] | yes |  | Auto-derived (or admin-entered) email domains treated as "internal" for this org — foundation for future Internal Meeting Assist routing. Derived from `setup_users.work_email` via `emailDomainType()`, excluding free/public providers (gmail, yahoo, outlook, ...). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `internal_domains_mode` | String | yes |  | derived Use this column for that fact only. Do not infer a second business meaning that is not written in the value. | manual | needs_manual — see backend/src/service/account/internal-domains.ts This value is stored for OrganizationProfile and should be selected when a question mentions internal Domains Mode. |
| `internal_domain_overrides` | String[] | yes |  | Specific email addresses always treated as internal regardless of domain (alias/personal-email edge case), admin-entered only. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `internal_domains_updated_at` | DateTime | no |  | Timestamp for internal domains updated. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "organization_id": 42,
  "vertical": "general",
  "vertical_config": {
    "source": "example"
  },
  "internal_domains": [
    "enterprise"
  ],
  "internal_domains_mode": "Blue Harbor Logistics",
  "internal_domain_overrides": [
    "enterprise"
  ],
  "internal_domains_updated_at": "2026-09-15T10:30:00Z",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.deals

Prisma model `Deal`.

This is a B2B opportunity. A row is one sales pursuit with an amount, currency, stage, company, primary contact, and owner. Pipeline, win rate, forecast, and won or lost revenue are calculated from this table. Stage history is not stored here; the current stage and updated_at are the live values.

Primary key: id.

Foreign keys and why the join exists:

- companyId -> Company.id on delete Cascade. Purpose of the join: crm.companies.id. Join it to show the account name, channel role, and parent company.
- locationId -> CompanyLocation.id on delete Cascade. Purpose of the join: crm.company_locations.id. Join it to show the office or branch address.

Categorical columns:

- `DealStage`: qualification, discover, propose, negotiate, closed_won, closed_lost.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `title` | String | yes |  | This is the human name of this record shown in lists. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `stage` | DealStage | yes |  | Current deal stage: qualification, discover, propose, negotiate, closed_won, or closed_lost. There is no stage-history table, so this value is the stage now, not the path the deal took. Open pipeline is the first four values. Won and lost are the last two. |
| `amount` | Decimal | no |  | `amount` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `company_id` | String | yes | FK | Foreign key to crm.companies.id. Join it to show the account name, channel role, and parent company. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `location_id` | String | yes | FK | Foreign key to crm.company_locations.id. Join it to show the office or branch address. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `contact_id` | String | no | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `contact_name` | String | no |  | `contact_name` stores the contact name for this row, typed as String. Select or group by it when the question is about contact name. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `contact_email` | String | no |  | `contact_email` stores the contact email for this row, typed as String. Select or group by it when the question is about contact email. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `owner_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it to print the owner's name. Reps are filtered on this column. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `notes` | String | no |  | This is the free-text note saved by a user or an agent. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `lost_reason` | String | no |  | Text the user stored when the deal moved to closed_lost. Group lost deals by this value when someone asks why deals were lost. There is no won-reason column. Do not invent one. |
| `expected_close_date` | DateTime | no |  | Timestamp for expected close date. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `closed_at` | DateTime | no |  | Timestamp for closed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `forecast_category` | String | no |  | Forecast overlay written by the pipeline forecast auditor. It does not change the deal stage, amount, or expected close date. Use it to explain forecast flags. Use stage weights when the question asks for weighted pipeline. |
| `forecast_confidence_percent` | Int | no |  | Forecast overlay written by the pipeline forecast auditor. It does not change the deal stage, amount, or expected close date. Use it to explain forecast flags. Use stage weights when the question asks for weighted pipeline. |
| `forecast_flagged` | Boolean | yes |  | Forecast overlay written by the pipeline forecast auditor. It does not change the deal stage, amount, or expected close date. Use it to explain forecast flags. Use stage weights when the question asks for weighted pipeline. |
| `forecast_reason` | String | no |  | Forecast overlay written by the pipeline forecast auditor. It does not change the deal stage, amount, or expected close date. Use it to explain forecast flags. Use stage weights when the question asks for weighted pipeline. |
| `forecast_last_run_at` | DateTime | no |  | Timestamp for forecast last run. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "title": "Blue Harbor \u2014 platform expansion",
  "stage": "propose",
  "amount": 125000,
  "company_id": "companyId_1001",
  "location_id": "locationId_1001",
  "contact_id": "contactId_1001",
  "contact_name": "Priya Shah",
  "contact_email": "priya.shah@blueharbor.example",
  "owner_user_id": 42,
  "notes": "Budget is confirmed for this fiscal year. Legal review is still open."
}
```

### crm.deal_activities

Prisma model `DealActivity`.

This is the timeline of work logged against one deal: a call, meeting, email, SMS, note, or task. Reports that ask what happened on an opportunity, how many touches it had, or which tasks are still open read this table and join it to deals on deal_id.

Primary key: id.

Foreign keys and why the join exists:

- dealId -> Deal.id on delete Cascade. Purpose of the join: crm.deals.id. Join it to show the opportunity title, stage, amount, and owner.

Categorical columns:

- `ActivityType`: call, meeting, email, sms, note, task.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `deal_id` | String | yes | FK | Foreign key to crm.deals.id. Join it to show the opportunity title, stage, amount, and owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `type` | ActivityType | yes |  | `type` stores the type for this row, typed as ActivityType. Select or group by it when the question is about type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `subject` | String | yes |  | This is the short label of the activity or message. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `body` | String | no |  | This is the longer text of the activity, email, or document. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `due_at` | DateTime | no |  | Timestamp for due. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `completed_at` | DateTime | no |  | Timestamp for completed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_by_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it when the question is who created the row, which can differ from the current owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "deal_id": "dealId_1001",
  "type": "call",
  "subject": "Discovery call \u2014 warehouse rollout",
  "body": "Priya asked for a revised rollout plan before the 15 October committee.",
  "due_at": "2026-09-15T10:30:00Z",
  "completed_at": "2026-09-15T10:30:00Z",
  "created_by_user_id": 42,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.contact_activities

Prisma model `ContactActivity`.

This is the same kind of timeline stored against a person rather than a deal. A call or meeting booked from the contact page lands here. Contact activity reports and last-touch metrics join this table to contact_profiles on account_contact_id.

Primary key: id.

Categorical columns:

- `ActivityType`: call, meeting, email, sms, note, task.
- `EmailDirection`: outbound, inbound.
- `InboxFolder`: inbox, sent, draft, trash.
- `MailProvider`: google, microsoft.
- `TaskStatus`: open, in_progress, completed.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `type` | ActivityType | yes |  | `type` stores the type for this row, typed as ActivityType. Select or group by it when the question is about type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `folder` | InboxFolder | yes |  | `folder` stores the folder for this row, typed as InboxFolder. Select or group by it when the question is about folder. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `thread_id` | String | no |  | Groups replies into one conversation in the Inbox UI Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `gmail_message_id` | String | no | unique | `gmail_message_id` stores the gmail message id for this row, typed as String. Select or group by it when the question is about gmail message id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `gmail_thread_id` | String | no |  | `gmail_thread_id` stores the gmail thread id for this row, typed as String. Select or group by it when the question is about gmail thread id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `provider_message_id` | String | no | unique | Provider-agnostic message id (Gmail id or Graph message id) for dedupe Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `provider_thread_id` | String | no |  | Provider-agnostic conversation id (Gmail threadId or Graph conversationId) Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `mail_provider` | MailProvider | no |  | `mail_provider` stores the mail provider for this row, typed as MailProvider. Select or group by it when the question is about mail provider. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `rfc_message_id` | String | no |  | RFC Message-ID header — required for client-side reply threading Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `email_direction` | EmailDirection | no |  | `email_direction` stores the email direction for this row, typed as EmailDirection. Select or group by it when the question is about email direction. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `needs_manual_response` | Boolean | yes |  | Set by the auto-reply agent when a human must answer (sensitive content) Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `subject` | String | yes |  | This is the short label of the activity or message. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `body` | String | no |  | This is the longer text of the activity, email, or document. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `due_at` | DateTime | no |  | Timestamp for due. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `assignee_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it to the person who must complete the task. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `task_status` | TaskStatus | no |  | Task workflow status (null for non-task activities). Overdue is derived. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `reminder_sent_at` | DateTime | no |  | Timestamp for reminder sent. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `reminder_24h_sent_at` | DateTime | no |  | Timestamp for reminder 24h sent. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `reminder_1h_sent_at` | DateTime | no |  | Timestamp for reminder 1h sent. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `miss_escalated_at` | DateTime | no |  | Timestamp for miss escalated. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `mom_sent_at` | DateTime | no |  | Timestamp for mom sent. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `transcript_text` | String | no |  | Meeting / call transcript text once a provider (or manual upload) supplies it Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `transcript_source` | String | no |  | `transcript_source` stores the transcript source for this row, typed as String. Select or group by it when the question is about transcript source. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `transcript_analyzed_at` | DateTime | no |  | Timestamp for transcript analyzed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `transcript_insights` | Json | no |  | Extracted signals: intent, commitments, objections, BANT hints Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `completed_at` | DateTime | no |  | Timestamp for completed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_by_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it when the question is who created the row, which can differ from the current owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contact_id": "contactId_1001",
  "type": "call",
  "folder": "inbox",
  "thread_id": "threadId_1001",
  "gmail_message_id": "gmailMessageId_1001",
  "gmail_thread_id": "gmailThreadId_1001",
  "provider_message_id": "providerMessageId_1001",
  "provider_thread_id": "providerThreadId_1001",
  "mail_provider": "google",
  "rfc_message_id": "rfcMessageId_1001"
}
```

### crm.user_integration_connections

Prisma model `UserIntegrationConnection`.

This stores one user's connected mailbox or calendar credentials for Gmail, Outlook, or Google Calendar. The reports agent should not read token columns. It may count whether a user has connected mail or calendar, and only inside the same organization.

Primary key: id.

Categorical columns:

- `IntegrationProvider`: google, microsoft, zoom, yahoo.
- `SalesSeniorityTier`: junior, mid, senior.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `user_id` | BigInt | yes | FK | Foreign key to accounts.setup_users.id. Join it to the CRM user this row belongs to. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `provider` | IntegrationProvider | yes |  | `provider` stores the provider for this row, typed as IntegrationProvider. Select or group by it when the question is about provider. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `account_email` | String | no |  | `account_email` stores the account email for this row, typed as String. Select or group by it when the question is about account email. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `access_token` | String | yes |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `refresh_token` | String | no |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `token_expires_at` | DateTime | no |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `scope` | String | no |  | `scope` stores the scope for this row, typed as String. Select or group by it when the question is about scope. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `enum` | SalesSeniorityTier | yes |  | `enum` stores the enum for this row, typed as SalesSeniorityTier. Select or group by it when the question is about enum. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "user_id": 42,
  "provider": "google",
  "account_email": "Blue Harbor Logistics",
  "access_token": "[not readable by reports]",
  "refresh_token": "[not readable by reports]",
  "token_expires_at": "[not readable by reports]",
  "scope": "Blue Harbor Logistics",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z",
  "enum": "junior"
}
```

### crm.org_assignment_settings

Prisma model `OrgAssignmentSettings`.

This stores how the tenant wants new leads assigned, including the assignment mode and related rules. A routing or coverage report reads this to explain why an owner was chosen. It does not itself contain the lead rows.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | unique FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `senior_amount_threshold` | Int | yes |  | `senior_amount_threshold` stores the senior amount threshold for this row, typed as Int. Select or group by it when the question is about senior amount threshold. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `lead_icp` | Json | no |  | ICP knobs for Fit scoring: { targetIndustries, sizeTiers, serviceableGeos } Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `updated_by_user_id` | BigInt | no |  | `updated_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "senior_amount_threshold": 1,
  "lead_icp": {
    "source": "example"
  },
  "updated_by_user_id": 42,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.org_finance_settings

Prisma model `OrgFinanceSettings`.

This stores tenant finance preferences such as default currency and invoice behaviour. Finance reports use it so totals are labelled in the tenant currency and draft-versus-send rules match the org, not a hardcoded default.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | unique FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `default_payment_terms` | String | yes |  | `default_payment_terms` stores the default payment terms for this row, typed as String. Select or group by it when the question is about default payment terms. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `zero_amount_auto_paid` | Boolean | yes |  | `zero_amount_auto_paid` stores the zero amount auto paid for this row, typed as Boolean. Select or group by it when the question is about zero amount auto paid. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `offline_reference_min_len` | Int | yes |  | `offline_reference_min_len` stores the offline reference min len for this row, typed as Int. Select or group by it when the question is about offline reference min len. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `duplicate_invoice_guard` | Boolean | yes |  | `duplicate_invoice_guard` stores the duplicate invoice guard for this row, typed as Boolean. Select or group by it when the question is about duplicate invoice guard. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `online_payments_enabled` | Boolean | yes |  | `online_payments_enabled` stores the online payments enabled for this row, typed as Boolean. Select or group by it when the question is about online payments enabled. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `payment_routing_rules` | Json | no |  | { defaultProvider, rules: [{ currency, offlineOnlyAbove, allowedProviders }] } Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `bank_details` | Json | no |  | { accountName, bankName, accountNumber, ifsc, iban, swift, ... } Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `invoice_number_prefix` | String | no |  | `invoice_number_prefix` stores the invoice number prefix for this row, typed as String. Select or group by it when the question is about invoice number prefix. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `invoice_number_next_seq` | Int | yes |  | `invoice_number_next_seq` stores the invoice number next seq for this row, typed as Int. Select or group by it when the question is about invoice number next seq. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `stripe_publishable_key` | String | no |  | `stripe_publishable_key` stores the stripe publishable key for this row, typed as String. Select or group by it when the question is about stripe publishable key. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `stripe_secret_key_enc` | String | no |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `stripe_webhook_secret_enc` | String | no |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `razorpay_key_id` | String | no |  | `razorpay_key_id` stores the razorpay key id for this row, typed as String. Select or group by it when the question is about razorpay key id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `razorpay_key_secret_enc` | String | no |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `razorpay_webhook_secret_enc` | String | no |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `billing_cutoff_day` | Int | yes |  | Day of month (1–28) used for subscription billing cutoff scheduling. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `renewal_window_days` | Int | yes |  | Days before contract end to create renewal deal. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `auto_renew_default` | Boolean | yes |  | `auto_renew_default` stores the auto renew default for this row, typed as Boolean. Select or group by it when the question is about auto renew default. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `renewal_quote_auto_create` | Boolean | yes |  | `renewal_quote_auto_create` stores the renewal quote auto create for this row, typed as Boolean. Select or group by it when the question is about renewal quote auto create. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `revenue_target_monthly` | Decimal | no |  | `revenue_target_monthly` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `revenue_target_quarterly` | Decimal | no |  | `revenue_target_quarterly` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `revenue_forecast_last_run` | Json | no |  | Cached last forecast — { hasTarget, narrative, atRiskInvoiceIds, gapScenario, source }. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `revenue_forecast_last_run_at` | DateTime | no |  | Timestamp for revenue forecast last run. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `updated_by_user_id` | BigInt | no |  | `updated_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "default_payment_terms": "Blue Harbor Logistics",
  "zero_amount_auto_paid": true,
  "offline_reference_min_len": 1,
  "duplicate_invoice_guard": true,
  "online_payments_enabled": true,
  "payment_routing_rules": {
    "source": "example"
  },
  "bank_details": {
    "source": "example"
  },
  "invoice_number_prefix": "Blue Harbor Logistics",
  "invoice_number_next_seq": 1,
  "stripe_publishable_key": "Blue Harbor Logistics"
}
```

### crm.payment_gateway_events

Prisma model `PaymentGatewayEvent`.

This stores a webhook event received from a payment provider after an invoice payment link is used. Collection and paid-invoice reports join it to invoices to show that money moved, including the provider reference. It is an event log, not the invoice itself.

Primary key: id.

Categorical columns:

- `PaymentGatewayProvider`: stripe, razorpay.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `provider` | PaymentGatewayProvider | yes |  | `provider` stores the provider for this row, typed as PaymentGatewayProvider. Select or group by it when the question is about provider. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `external_event_id` | String | yes |  | `external_event_id` stores the external event id for this row, typed as String. Select or group by it when the question is about external event id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `invoice_id` | String | no | FK | Foreign key to crm.invoices.id. Join it to show invoice status, total, and whether it has been paid. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `payload` | Json | no |  | `payload` stores the payload for this row, typed as Json. Select or group by it when the question is about payload. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `processed_at` | DateTime | yes |  | Timestamp for processed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "provider": "stripe",
  "external_event_id": "externalEventId_1001",
  "invoice_id": "invoiceId_1001",
  "payload": {
    "source": "example"
  },
  "processed_at": "2026-09-15T10:30:00Z"
}
```

### crm.sales_user_assignment_profiles

Prisma model `SalesUserAssignmentProfile`.

This stores assignment attributes for one CRM user, such as skills or territories used by lead routing. Coverage and assignment-fairness reports join it to accounts.setup_users on user id so a metric can group leads by the rep profile rather than by the lead alone.

Primary key: id.

Categorical columns:

- `SalesSeniorityTier`: junior, mid, senior.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `user_id` | BigInt | yes | FK | Foreign key to accounts.setup_users.id. Join it to the CRM user this row belongs to. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `accepting_leads` | Boolean | yes |  | `accepting_leads` stores the accepting leads for this row, typed as Boolean. Select or group by it when the question is about accepting leads. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `max_open_deals` | Int | no |  | `max_open_deals` stores the max open deals for this row, typed as Int. Select or group by it when the question is about max open deals. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `seniority_tier` | SalesSeniorityTier | no |  | `seniority_tier` stores the seniority tier for this row, typed as SalesSeniorityTier. Select or group by it when the question is about seniority tier. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `on_pto_until` | DateTime | no |  | Timestamp for on pto until. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `country` | String | no |  | `country` stores the country for this row, typed as String. Select or group by it when the question is about country. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "user_id": 42,
  "accepting_leads": true,
  "max_open_deals": 1,
  "seniority_tier": "junior",
  "on_pto_until": "2026-09-15T10:30:00Z",
  "country": "Blue Harbor Logistics",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### inventory.products

Prisma model `Product`.

This is the shared product catalog in inventory.products. CRM does not own the table. A row is one sellable product with a name, price, status, and billing type. Quotes, orders, invoices, and offers point at product id so revenue can be split by what was sold.

Primary key: id.

Categorical columns:

- `ProductBillingFrequency`: monthly, quarterly, annual.
- `ProductBillingType`: one_time, recurring.
- `ProductStatus`: draft, active, archived.
- `ProductType`: fixed, customizable.
- `ProductUnitOfMeasure`: per_seat, per_agent, per_ticket, flat.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `tagline` | String | no |  | Short line shown on cards Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `description` | String | no |  | `description` stores the description for this row, typed as String. Select or group by it when the question is about description. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `specifications` | String | no |  | Full specifications / details (long text) Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `image_url` | String | no |  | `image_url` stores the image url for this row, typed as String. Select or group by it when the question is about image url. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `gallery_urls` | Json | no |  | Extra image URLs (JSON string array) Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `product_url` | String | no |  | Product page / PDP / datasheet. Not an image. Null = none. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `sku` | String | no |  | `sku` stores the sku for this row, typed as String. Select or group by it when the question is about sku. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `brand` | String | no |  | Retail / commerce merchandising (optional on B2B). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `subcategory` | String | no |  | `subcategory` stores the subcategory for this row, typed as String. Select or group by it when the question is about subcategory. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `stock_on_hand` | Int | no |  | Warehouse units. Null = not inventory-tracked (services, subscriptions). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `price` | Decimal | no |  | `price` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `max_discount_percent` | Decimal | no |  | `max_discount_percent` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `currency` | String | yes |  | ISO currency code for the money columns on this row, such as USD or INR. Group totals by this code. A mixed-currency sum without conversion is not a valid KPI. |
| `status` | ProductStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `product_type` | ProductType | yes |  | `product_type` stores the product type for this row, typed as ProductType. Select or group by it when the question is about product type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `category` | String | no |  | `category` stores the category for this row, typed as String. Select or group by it when the question is about category. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `tags` | String | no |  | Comma-separated or freeform tags Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `billing_type` | ProductBillingType | yes |  | `billing_type` stores the billing type for this row, typed as ProductBillingType. Select or group by it when the question is about billing type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `billing_frequency` | ProductBillingFrequency | no |  | `billing_frequency` stores the billing frequency for this row, typed as ProductBillingFrequency. Select or group by it when the question is about billing frequency. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `unit_of_measure` | ProductUnitOfMeasure | yes |  | `unit_of_measure` stores the unit of measure for this row, typed as ProductUnitOfMeasure. Select or group by it when the question is about unit of measure. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `pricing_tiers` | Json | no |  | Legacy volume tiers on product (prefer Addon / AddonTier for customizable) Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `custom_attributes` | Json | no |  | Non-pricing industry labels/notes (not used for quote math). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "name": "Blue Harbor Logistics",
  "tagline": "Blue Harbor Logistics",
  "description": "Blue Harbor Logistics",
  "specifications": "Blue Harbor Logistics",
  "image_url": "Blue Harbor Logistics",
  "gallery_urls": {
    "source": "example"
  },
  "product_url": "Blue Harbor Logistics",
  "sku": "Blue Harbor Logistics",
  "brand": "Blue Harbor Logistics",
  "subcategory": "Blue Harbor Logistics"
}
```

### crm.product_offers

Prisma model `ProductOffer`.

This is a CRM commercial wrapper around one catalog product, such as a named offer the sales team can put on a quote. It joins inventory.products so the catalog stays shared while CRM-only offer terms stay in crm. Reports that ask which offer is attached to revenue start here and follow the product id.

Primary key: id.

Foreign keys and why the join exists:

- productId -> Product.id on delete Cascade. Purpose of the join: inventory.products.id. Join it to show the catalog name, SKU, and billing type.

Categorical columns:

- `AddonMeterKey`: seat, minute, session, email, agent, flat, custom.
- `ProductBillingFrequency`: monthly, quarterly, annual.
- `ProductBillingType`: one_time, recurring.
- `ProductStatus`: draft, active, archived.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `product_id` | String | yes | FK | Foreign key to inventory.products.id. Join it to show the catalog name, SKU, and billing type. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `code` | String | no |  | `code` stores the code for this row, typed as String. Select or group by it when the question is about code. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `billing_type` | ProductBillingType | no |  | `billing_type` stores the billing type for this row, typed as ProductBillingType. Select or group by it when the question is about billing type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `billing_frequency` | ProductBillingFrequency | no |  | `billing_frequency` stores the billing frequency for this row, typed as ProductBillingFrequency. Select or group by it when the question is about billing frequency. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `included_qty` | Int | no |  | `included_qty` stores the included qty for this row, typed as Int. Select or group by it when the question is about included qty. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `meter_key` | AddonMeterKey | no |  | `meter_key` stores the meter key for this row, typed as AddonMeterKey. Select or group by it when the question is about meter key. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sort_order` | Int | yes |  | `sort_order` stores the sort order for this row, typed as Int. Select or group by it when the question is about sort order. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | ProductStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "product_id": "productId_1001",
  "name": "Blue Harbor Logistics",
  "code": "Blue Harbor Logistics",
  "billing_type": "one_time",
  "billing_frequency": "monthly",
  "included_qty": 1,
  "meter_key": "seat",
  "sort_order": 1,
  "status": "draft",
  "created_at": "2026-09-15T10:30:00Z"
}
```

### crm.price_books

Prisma model `PriceBook`.

This is a named price list for the tenant, for example standard or partner pricing. It has no amounts by itself. Quote lines resolve a price through price book entries, so a price-list report starts at this header and joins the entries.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `code` | String | no |  | `code` stores the code for this row, typed as String. Select or group by it when the question is about code. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `currency` | String | yes |  | ISO currency code for the money columns on this row, such as USD or INR. Group totals by this code. A mixed-currency sum without conversion is not a valid KPI. |
| `is_default` | Boolean | yes |  | `is_default` stores the is default for this row, typed as Boolean. Select or group by it when the question is about is default. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "name": "Blue Harbor Logistics",
  "code": "Blue Harbor Logistics",
  "currency": "USD",
  "is_default": true,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z",
  "entries": [
    "enterprise"
  ]
}
```

### crm.price_book_entries

Prisma model `PriceBookEntry`.

This is one product's price inside one price book, including amount and currency. It joins price_books and inventory.products. A report that compares list price to the price actually quoted uses this row as the list price.

Primary key: id.

Foreign keys and why the join exists:

- priceBookId -> PriceBook.id on delete Cascade. Purpose of the join: crm.price_books.id. Join it to name the price list that produced the entry.
- productId -> Product.id on delete Cascade. Purpose of the join: inventory.products.id. Join it to show the catalog name, SKU, and billing type.
- offerId -> ProductOffer.id on delete Cascade. Purpose of the join: crm.product_offers.id. Join it to the CRM offer wrapped around a catalog product.
- addonId -> Addon.id on delete Cascade. Purpose of the join: crm.addons.id. Join it to name the optional extra sold beside a product.

Categorical columns:

- `ProductBillingFrequency`: monthly, quarterly, annual.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `price_book_id` | String | yes | FK | Foreign key to crm.price_books.id. Join it to name the price list that produced the entry. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `product_id` | String | no | FK | Foreign key to inventory.products.id. Join it to show the catalog name, SKU, and billing type. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `offer_id` | String | no | FK | Foreign key to crm.product_offers.id. Join it to the CRM offer wrapped around a catalog product. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `addon_id` | String | no | FK | Foreign key to crm.addons.id. Join it to name the optional extra sold beside a product. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `amount` | Decimal | yes |  | `amount` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `billing_frequency` | ProductBillingFrequency | no |  | `billing_frequency` stores the billing frequency for this row, typed as ProductBillingFrequency. Select or group by it when the question is about billing frequency. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "price_book_id": "priceBookId_1001",
  "product_id": "productId_1001",
  "offer_id": "offerId_1001",
  "addon_id": "addonId_1001",
  "amount": 125000,
  "billing_frequency": "monthly",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.product_addons

Prisma model `Addon`.

This is an optional extra that can be sold alongside a product. The row names the add-on and links it to a catalog product. Quote and invoice lines can include it so attach-rate reports can count how often the extra is sold with the base product.

Primary key: id.

Foreign keys and why the join exists:

- productId -> Product.id on delete Cascade. Purpose of the join: inventory.products.id. Join it to show the catalog name, SKU, and billing type.

Categorical columns:

- `AddonMeterKey`: seat, minute, session, email, agent, flat, custom.
- `AddonPricingModel`: flat, per_unit, stepped, tiered.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `product_id` | String | yes | FK | Foreign key to inventory.products.id. Join it to show the catalog name, SKU, and billing type. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `unit_label` | String | no |  | `unit_label` stores the unit label for this row, typed as String. Select or group by it when the question is about unit label. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `meter_key` | AddonMeterKey | no |  | `meter_key` stores the meter key for this row, typed as AddonMeterKey. Select or group by it when the question is about meter key. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `is_overage` | Boolean | yes |  | `is_overage` stores the is overage for this row, typed as Boolean. Select or group by it when the question is about is overage. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `pricing_model` | AddonPricingModel | yes |  | `pricing_model` stores the pricing model for this row, typed as AddonPricingModel. Select or group by it when the question is about pricing model. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `flat_price` | Decimal | no |  | `flat_price` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `unit_price` | Decimal | no |  | `unit_price` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `step_size` | Int | no |  | `step_size` stores the step size for this row, typed as Int. Select or group by it when the question is about step size. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `step_price` | Decimal | no |  | `step_price` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `sort_order` | Int | yes |  | `sort_order` stores the sort order for this row, typed as Int. Select or group by it when the question is about sort order. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "product_id": "productId_1001",
  "name": "Blue Harbor Logistics",
  "unit_label": "Blue Harbor Logistics",
  "meter_key": "seat",
  "is_overage": true,
  "pricing_model": "flat",
  "flat_price": 48000,
  "unit_price": 48000,
  "step_size": 1,
  "step_price": 48000
}
```

### crm.product_addon_tiers

Prisma model `AddonTier`.

This is a priced tier of an add-on, such as a seat band or usage band. It joins addons. A report that needs the add-on price uses the tier amount rather than inventing a price on the add-on header.

Primary key: id.

Foreign keys and why the join exists:

- addonId -> Addon.id on delete Cascade. Purpose of the join: crm.addons.id. Join it to name the optional extra sold beside a product.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `addon_id` | String | yes | FK | Foreign key to crm.addons.id. Join it to name the optional extra sold beside a product. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `min_qty` | Int | yes |  | `min_qty` stores the min qty for this row, typed as Int. Select or group by it when the question is about min qty. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `max_qty` | Int | no |  | `max_qty` stores the max qty for this row, typed as Int. Select or group by it when the question is about max qty. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `unit_price` | Decimal | yes |  | `unit_price` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "addon_id": "addonId_1001",
  "min_qty": 1,
  "max_qty": 1,
  "unit_price": 48000,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.proposal_templates

Prisma model `ProposalTemplate`.

This is a reusable proposal document template for the tenant. It stores layout and default sections, not a customer-specific proposal. Template-usage reports count how many proposals were created from each template.

Primary key: id.

Categorical columns:

- `ProposalTemplateKind`: standard.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `code` | String | no |  | `code` stores the code for this row, typed as String. Select or group by it when the question is about code. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `kind` | ProposalTemplateKind | yes |  | `kind` stores the kind for this row, typed as ProposalTemplateKind. Select or group by it when the question is about kind. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sections` | Json | yes |  | Sections: [{ id, key, title, body, sortOrder }] Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `blueprint` | Json | no |  | HTML brand blueprint: { version, html, css, theme, slots } Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `assets` | Json | no |  | Inline assets: [{ id, kind, mime, dataBase64 }] Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `is_default` | Boolean | yes |  | `is_default` stores the is default for this row, typed as Boolean. Select or group by it when the question is about is default. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "name": "Blue Harbor Logistics",
  "code": "Blue Harbor Logistics",
  "kind": "standard",
  "sections": {
    "source": "example"
  },
  "blueprint": {
    "source": "example"
  },
  "assets": {
    "source": "example"
  },
  "is_default": true,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z",
  "proposals": [
    "enterprise"
  ]
}
```

### crm.proposals

Prisma model `Proposal`.

This is a customer-specific proposal linked to a deal or company. It stores the document status and content used before or alongside a quote. Proposal pipeline reports join it to deals so a manager can see which opportunities have a proposal.

Primary key: id.

Foreign keys and why the join exists:

- dealId -> Deal.id on delete Cascade. Purpose of the join: crm.deals.id. Join it to show the opportunity title, stage, amount, and owner.
- templateId -> ProposalTemplate.id on delete SetNull. Purpose of the join: the template table for this document type. Join it only to name the layout, not to sum money.

Categorical columns:

- `ProposalStatus`: draft, shared, accepted, declined.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `deal_id` | String | yes | FK | Foreign key to crm.deals.id. Join it to show the opportunity title, stage, amount, and owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `template_id` | String | no | FK | Foreign key to the template table for this document type. Join it only to name the layout, not to sum money. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `number` | String | yes |  | `number` stores the number for this row, typed as String. Select or group by it when the question is about number. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `title` | String | yes |  | This is the human name of this record shown in lists. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `summary` | String | no |  | `summary` stores the summary for this row, typed as String. Select or group by it when the question is about summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sections` | Json | no |  | Customer-specific section bodies after merge/edit Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `blueprint` | Json | no |  | Cloned HTML blueprint from template (layout stays fixed) Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `assets` | Json | no |  | Cloned assets from template Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `customer_name` | String | no |  | Display name used in the document (company or contact) Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `version` | Int | yes |  | `version` stores the version for this row, typed as Int. Select or group by it when the question is about version. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | ProposalStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `attachment_url` | String | no |  | `attachment_url` stores the attachment url for this row, typed as String. Select or group by it when the question is about attachment url. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `shared_at` | DateTime | no |  | Timestamp for shared. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `approved_by_user_id` | BigInt | no |  | `approved_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `approved_at` | DateTime | no |  | Timestamp for approved. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `approval_status` | String | yes |  | `approval_status` stores the approval status for this row, typed as String. Select or group by it when the question is about approval status. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_by_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it when the question is who created the row, which can differ from the current owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "deal_id": "dealId_1001",
  "template_id": "templateId_1001",
  "number": "SO-10042",
  "title": "Blue Harbor \u2014 platform expansion",
  "summary": "Blue Harbor Logistics",
  "sections": {
    "source": "example"
  },
  "blueprint": {
    "source": "example"
  },
  "assets": {
    "source": "example"
  },
  "customer_name": "Blue Harbor Logistics",
  "version": 1
}
```

### crm.quote_templates

Prisma model `QuoteTemplate`.

This is a reusable quote layout for the tenant. It does not hold a customer price. Quote-template reports only count usage. The money sits on quotes and quote lines.

Primary key: id.

Categorical columns:

- `QuoteTemplateKind`: standard.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `code` | String | no |  | `code` stores the code for this row, typed as String. Select or group by it when the question is about code. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `kind` | QuoteTemplateKind | yes |  | `kind` stores the kind for this row, typed as QuoteTemplateKind. Select or group by it when the question is about kind. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sections` | Json | yes |  | Document sections: [{ id, key, title, body, sortOrder }] Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `blueprint` | Json | no |  | HTML brand blueprint: { version, html, css, theme, slots } Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `assets` | Json | no |  | Inline assets: [{ id, kind, mime, dataBase64 }] Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `is_default` | Boolean | yes |  | `is_default` stores the is default for this row, typed as Boolean. Select or group by it when the question is about is default. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "name": "Blue Harbor Logistics",
  "code": "Blue Harbor Logistics",
  "kind": "standard",
  "sections": {
    "source": "example"
  },
  "blueprint": {
    "source": "example"
  },
  "assets": {
    "source": "example"
  },
  "is_default": true,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z",
  "quotes": [
    "enterprise"
  ]
}
```

### crm.quotes

Prisma model `Quote`.

This is a priced offer sent to a company. Status moves through draft, sent, accepted, declined, or expired. The B2B handoff to an order starts when a sent quote is accepted. Quote conversion and discount reports use this header plus its lines.

Primary key: id.

Foreign keys and why the join exists:

- dealId -> Deal.id on delete Cascade. Purpose of the join: crm.deals.id. Join it to show the opportunity title, stage, amount, and owner.
- proposalId -> Proposal.id on delete SetNull. Purpose of the join: the related Proposal row so the report can show that record's name and status instead of only this id.
- templateId -> QuoteTemplate.id on delete SetNull. Purpose of the join: the template table for this document type. Join it only to name the layout, not to sum money.

Categorical columns:

- `QuoteStatus`: draft, sent, accepted, rejected, void.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `deal_id` | String | yes | FK | Foreign key to crm.deals.id. Join it to show the opportunity title, stage, amount, and owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `proposal_id` | String | no |  | Optional link when a quote was created from a proposal Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `renewal_contract_id` | String | no |  | Renewal quote linked to an existing contract (Phase 3). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `template_id` | String | no | FK | Foreign key to the template table for this document type. Join it only to name the layout, not to sum money. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `number` | String | yes |  | `number` stores the number for this row, typed as String. Select or group by it when the question is about number. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `version` | Int | yes |  | `version` stores the version for this row, typed as Int. Select or group by it when the question is about version. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | QuoteStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `currency` | String | yes |  | ISO currency code for the money columns on this row, such as USD or INR. Group totals by this code. A mixed-currency sum without conversion is not a valid KPI. |
| `subtotal` | Decimal | yes |  | `subtotal` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `discount_pct` | Decimal | yes |  | `discount_pct` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `total` | Decimal | yes |  | `total` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `valid_until` | DateTime | no |  | Timestamp for valid until. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `notes` | String | no |  | This is the free-text note saved by a user or an agent. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `document_sections` | Json | no |  | Customer-specific document sections after template merge/edit Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `blueprint` | Json | no |  | Cloned HTML blueprint from template Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `assets` | Json | no |  | Cloned assets from template Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `customer_name` | String | no |  | `customer_name` stores the customer name for this row, typed as String. Select or group by it when the question is about customer name. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `company_name` | String | no |  | `company_name` stores the company name for this row, typed as String. Select or group by it when the question is about company name. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `vendor_name` | String | no |  | `vendor_name` stores the vendor name for this row, typed as String. Select or group by it when the question is about vendor name. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sent_at` | DateTime | no |  | Timestamp for sent. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `accepted_at` | DateTime | no |  | Timestamp for accepted. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `approved_by_user_id` | BigInt | no |  | `approved_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `approved_at` | DateTime | no |  | Timestamp for approved. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `approval_status` | String | yes |  | `approval_status` stores the approval status for this row, typed as String. Select or group by it when the question is about approval status. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `approval_note` | String | no |  | Finance approve/reject note (reject requires a reason). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `created_by_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it when the question is who created the row, which can differ from the current owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "deal_id": "dealId_1001",
  "proposal_id": "proposalId_1001",
  "renewal_contract_id": "renewalContractId_1001",
  "template_id": "templateId_1001",
  "number": "SO-10042",
  "version": 1,
  "status": "draft",
  "currency": "USD",
  "subtotal": 48000,
  "discount_pct": 48000
}
```

### crm.quote_lines

Prisma model `QuoteLine`.

This is one product, offer, or add-on row on a quote, with quantity, unit price, and line total. Product-mix and discount reports join quote_lines to quotes and to inventory.products. The quote header total should equal the sum of these lines.

Primary key: id.

Foreign keys and why the join exists:

- quoteId -> Quote.id on delete Cascade. Purpose of the join: crm.quotes.id. Join it to show quote status, currency, and the company that was quoted.
- productId -> Product.id on delete SetNull. Purpose of the join: inventory.products.id. Join it to show the catalog name, SKU, and billing type.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `quote_id` | String | yes | FK | Foreign key to crm.quotes.id. Join it to show quote status, currency, and the company that was quoted. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `product_id` | String | no | FK | Foreign key to inventory.products.id. Join it to show the catalog name, SKU, and billing type. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `quantity` | Decimal | yes |  | `quantity` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `unit_price` | Decimal | yes |  | `unit_price` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `amount` | Decimal | yes |  | `amount` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `sort_order` | Int | yes |  | `sort_order` stores the sort order for this row, typed as Int. Select or group by it when the question is about sort order. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "quote_id": "quoteId_1001",
  "product_id": "productId_1001",
  "name": "Blue Harbor Logistics",
  "quantity": 48000,
  "unit_price": 48000,
  "amount": 125000,
  "sort_order": 1,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.sales_orders

Prisma model `SalesOrder`.

This is the confirmed order created from an accepted quote. It copies company, contact, deal, currency, and total, and receives a number such as SO-10042. Order reports join it to the quote it came from and to the invoice that finance drafts from it.

Primary key: id.

Foreign keys and why the join exists:

- dealId -> Deal.id on delete SetNull. Purpose of the join: crm.deals.id. Join it to show the opportunity title, stage, amount, and owner.
- quoteId -> Quote.id on delete SetNull. Purpose of the join: crm.quotes.id. Join it to show quote status, currency, and the company that was quoted.
- companyId -> Company.id on delete SetNull. Purpose of the join: crm.companies.id. Join it to show the account name, channel role, and parent company.

Categorical columns:

- `OrderStatus`: draft, confirmed, fulfilled, cancelled.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `deal_id` | String | no | FK | Foreign key to crm.deals.id. Join it to show the opportunity title, stage, amount, and owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `quote_id` | String | no | FK | Foreign key to crm.quotes.id. Join it to show quote status, currency, and the company that was quoted. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `company_id` | String | no | FK | Foreign key to crm.companies.id. Join it to show the account name, channel role, and parent company. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `contact_id` | String | no | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `number` | String | yes |  | `number` stores the number for this row, typed as String. Select or group by it when the question is about number. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | OrderStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `currency` | String | yes |  | ISO currency code for the money columns on this row, such as USD or INR. Group totals by this code. A mixed-currency sum without conversion is not a valid KPI. |
| `total` | Decimal | yes |  | `total` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `confirmed_at` | DateTime | no |  | Timestamp for confirmed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_by_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it when the question is who created the row, which can differ from the current owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "deal_id": "dealId_1001",
  "quote_id": "quoteId_1001",
  "company_id": "companyId_1001",
  "contact_id": "contactId_1001",
  "number": "SO-10042",
  "status": "draft",
  "currency": "USD",
  "total": 125000,
  "confirmed_at": "2026-09-15T10:30:00Z",
  "created_by_user_id": 42
}
```

### crm.order_lines

Prisma model `OrderLine`.

This is one line copied onto the sales order from the quote. Fulfilment and product-quantity reports use these lines. They join sales_orders and the catalog product.

Primary key: id.

Foreign keys and why the join exists:

- orderId -> SalesOrder.id on delete Cascade. Purpose of the join: crm.sales_orders.id. Join it to show the confirmed order created from an accepted quote.
- productId -> Product.id on delete SetNull. Purpose of the join: inventory.products.id. Join it to show the catalog name, SKU, and billing type.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `order_id` | String | yes | FK | Foreign key to crm.sales_orders.id. Join it to show the confirmed order created from an accepted quote. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `product_id` | String | no | FK | Foreign key to inventory.products.id. Join it to show the catalog name, SKU, and billing type. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `quantity` | Decimal | yes |  | `quantity` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `unit_price` | Decimal | yes |  | `unit_price` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `amount` | Decimal | yes |  | `amount` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `sort_order` | Int | yes |  | `sort_order` stores the sort order for this row, typed as Int. Select or group by it when the question is about sort order. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "order_id": "orderId_1001",
  "product_id": "productId_1001",
  "name": "Blue Harbor Logistics",
  "quantity": 48000,
  "unit_price": 48000,
  "amount": 125000,
  "sort_order": 1,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.invoice_templates

Prisma model `InvoiceTemplate`.

This is a reusable invoice layout. It does not hold money owed. Invoice presentation reports may count which template was used. Amounts live on invoices and invoice lines.

Primary key: id.

Categorical columns:

- `InvoiceTemplateKind`: standard.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `code` | String | no |  | `code` stores the code for this row, typed as String. Select or group by it when the question is about code. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `kind` | InvoiceTemplateKind | yes |  | `kind` stores the kind for this row, typed as InvoiceTemplateKind. Select or group by it when the question is about kind. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sections` | Json | yes |  | Document sections: [{ id, key, title, body, sortOrder }] Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `blueprint` | Json | no |  | HTML brand blueprint: { version, html, css, theme, slots } Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `assets` | Json | no |  | Inline assets: [{ id, kind, mime, dataBase64 }] Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `is_default` | Boolean | yes |  | `is_default` stores the is default for this row, typed as Boolean. Select or group by it when the question is about is default. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "name": "Blue Harbor Logistics",
  "code": "Blue Harbor Logistics",
  "kind": "standard",
  "sections": {
    "source": "example"
  },
  "blueprint": {
    "source": "example"
  },
  "assets": {
    "source": "example"
  },
  "is_default": true,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z",
  "invoices": [
    "enterprise"
  ]
}
```

### crm.invoices

Prisma model `Invoice`.

This is the finance document raised from an order. Status covers draft, pending approval, sent, and paid or void paths used by the finance flow. Revenue-collected and accounts-receivable reports use this table, joined to the company and the source order.

Primary key: id.

Foreign keys and why the join exists:

- orderId -> SalesOrder.id on delete SetNull. Purpose of the join: crm.sales_orders.id. Join it to show the confirmed order created from an accepted quote.
- dealId -> Deal.id on delete SetNull. Purpose of the join: crm.deals.id. Join it to show the opportunity title, stage, amount, and owner.
- companyId -> Company.id on delete SetNull. Purpose of the join: crm.companies.id. Join it to show the account name, channel role, and parent company.
- templateId -> InvoiceTemplate.id on delete SetNull. Purpose of the join: the template table for this document type. Join it only to name the layout, not to sum money.
- contractId -> Contract.id on delete SetNull. Purpose of the join: crm.contracts.id. Join it to show the agreement term, ARR, and company.
- billingScheduleId -> ContractBillingSchedule.id on delete SetNull. Purpose of the join: the related ContractBillingSchedule row so the report can show that record's name and status instead of only this id.

Categorical columns:

- `InvoiceBillingKind`: standard, setup, subscription_start, renewal, amendment, adjustment, credit.
- `InvoicePaymentMethod`: offline, manual, stripe, razorpay.
- `InvoicePaymentProvider`: stripe, razorpay.
- `InvoicePaymentSessionStatus`: active, expired, paid, cancelled.
- `InvoiceStatus`: draft, sent, paid, void, overdue.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `order_id` | String | no | FK | Foreign key to crm.sales_orders.id. Join it to show the confirmed order created from an accepted quote. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `deal_id` | String | no | FK | Foreign key to crm.deals.id. Join it to show the opportunity title, stage, amount, and owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `company_id` | String | no | FK | Foreign key to crm.companies.id. Join it to show the account name, channel role, and parent company. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `template_id` | String | no | FK | Foreign key to the template table for this document type. Join it only to name the layout, not to sum money. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `number` | String | yes |  | `number` stores the number for this row, typed as String. Select or group by it when the question is about number. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | InvoiceStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `currency` | String | yes |  | ISO currency code for the money columns on this row, such as USD or INR. Group totals by this code. A mixed-currency sum without conversion is not a valid KPI. |
| `total` | Decimal | yes |  | `total` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `discount_amount` | Decimal | yes |  | `discount_amount` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `tax_amount` | Decimal | yes |  | `tax_amount` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `tax_details` | Json | no |  | Global tax snapshot (IN GST / UK VAT / US sales tax components). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `issue_date` | DateTime | no |  | Timestamp for issue date. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `payment_terms` | String | no |  | `payment_terms` stores the payment terms for this row, typed as String. Select or group by it when the question is about payment terms. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `notes` | String | no |  | This is the free-text note saved by a user or an agent. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `billing_address` | String | no |  | `billing_address` stores the billing address for this row, typed as String. Select or group by it when the question is about billing address. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `lead_email` | String | no |  | `lead_email` stores the lead email for this row, typed as String. Select or group by it when the question is about lead email. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `lead_phone` | String | no |  | `lead_phone` stores the lead phone for this row, typed as String. Select or group by it when the question is about lead phone. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `tax_id` | String | no |  | `tax_id` stores the tax id for this row, typed as String. Select or group by it when the question is about tax id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `due_at` | DateTime | no |  | Timestamp for due. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `paid_at` | DateTime | no |  | Timestamp for paid. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `sections` | Json | no |  | Customer-specific document sections after template merge/edit Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `blueprint` | Json | no |  | Cloned HTML blueprint from template Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `assets` | Json | no |  | Cloned assets from template Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `approved_by_user_id` | BigInt | no |  | `approved_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `approved_at` | DateTime | no |  | Timestamp for approved. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `approval_status` | String | yes |  | `approval_status` stores the approval status for this row, typed as String. Select or group by it when the question is about approval status. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `approval_note` | String | no |  | `approval_note` stores the approval note for this row, typed as String. Select or group by it when the question is about approval note. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `billing_kind` | InvoiceBillingKind | yes |  | `billing_kind` stores the billing kind for this row, typed as InvoiceBillingKind. Select or group by it when the question is about billing kind. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `submitted_for_approval_at` | DateTime | no |  | Timestamp for submitted for approval. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `resubmitted_at` | DateTime | no |  | Timestamp for resubmitted. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `payment_method` | InvoicePaymentMethod | no |  | `payment_method` stores the payment method for this row, typed as InvoicePaymentMethod. Select or group by it when the question is about payment method. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `payment_reference` | String | no |  | `payment_reference` stores the payment reference for this row, typed as String. Select or group by it when the question is about payment reference. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `payment_confirmed_by_user_id` | BigInt | no |  | `payment_confirmed_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `payment_confirmed_at` | DateTime | no |  | Timestamp for payment confirmed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `payment_provider` | InvoicePaymentProvider | no |  | `payment_provider` stores the payment provider for this row, typed as InvoicePaymentProvider. Select or group by it when the question is about payment provider. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `payment_link_url` | String | no |  | `payment_link_url` stores the payment link url for this row, typed as String. Select or group by it when the question is about payment link url. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `payment_session_id` | String | no |  | `payment_session_id` stores the payment session id for this row, typed as String. Select or group by it when the question is about payment session id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `payment_session_expires_at` | DateTime | no |  | Timestamp for payment session expires. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `payment_session_status` | InvoicePaymentSessionStatus | no |  | `payment_session_status` stores the payment session status for this row, typed as InvoicePaymentSessionStatus. Select or group by it when the question is about payment session status. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sent_at` | DateTime | no |  | Timestamp for sent. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `last_sent_at` | DateTime | no |  | Timestamp for last sent. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `voided_at` | DateTime | no |  | Timestamp for voided. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `void_reason` | String | no |  | `void_reason` stores the void reason for this row, typed as String. Select or group by it when the question is about void reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `voided_by_user_id` | BigInt | no |  | `voided_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `created_by_user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it when the question is who created the row, which can differ from the current owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `escalation_severity` | String | no |  | Invoice Escalation Agent — collections-risk overlay. Agent only ever writes these four fields (+ notifications); never marks paid/void, never changes dueAt/total, never sends escalationDraft itself (human-only send). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `escalation_reason` | String | no |  | `escalation_reason` stores the escalation reason for this row, typed as String. Select or group by it when the question is about escalation reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `escalation_draft` | String | no |  | `escalation_draft` stores the escalation draft for this row, typed as String. Select or group by it when the question is about escalation draft. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `escalation_last_run_at` | DateTime | no |  | Timestamp for escalation last run. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `dunning_stage` | String | yes |  | Invoice Dunning Agent — staged reminder->warning->pause_notice cadence. Agent only ever writes these three fields (+ notifications); draft only, a human always reviews and sends (same HITL rule as escalation above). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `dunning_stage_sent_at` | DateTime | no |  | Timestamp for dunning stage sent. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `dunning_draft` | String | no |  | `dunning_draft` stores the dunning draft for this row, typed as String. Select or group by it when the question is about dunning draft. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `contract_id` | String | no | FK | Foreign key to crm.contracts.id. Join it to show the agreement term, ARR, and company. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `billing_schedule_id` | String | no |  | `billing_schedule_id` stores the billing schedule id for this row, typed as String. Select or group by it when the question is about billing schedule id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "order_id": "orderId_1001",
  "deal_id": "dealId_1001",
  "company_id": "companyId_1001",
  "template_id": "templateId_1001",
  "number": "SO-10042",
  "status": "draft",
  "currency": "USD",
  "total": 125000,
  "discount_amount": 48000,
  "tax_amount": 48000
}
```

### crm.invoice_lines

Prisma model `InvoiceLine`.

This is one billed line on an invoice. Product revenue and tax reports sum these lines and join them to invoices and inventory.products. Do not sum invoice headers and lines together or revenue will be double-counted.

Primary key: id.

Foreign keys and why the join exists:

- invoiceId -> Invoice.id on delete Cascade. Purpose of the join: crm.invoices.id. Join it to show invoice status, total, and whether it has been paid.
- productId -> Product.id on delete SetNull. Purpose of the join: inventory.products.id. Join it to show the catalog name, SKU, and billing type.
- addonId -> Addon.id on delete SetNull. Purpose of the join: crm.addons.id. Join it to name the optional extra sold beside a product.

Categorical columns:

- `InvoiceLineKind`: product, addon.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `invoice_id` | String | yes | FK | Foreign key to crm.invoices.id. Join it to show invoice status, total, and whether it has been paid. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `kind` | InvoiceLineKind | yes |  | `kind` stores the kind for this row, typed as InvoiceLineKind. Select or group by it when the question is about kind. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `product_id` | String | no | FK | Foreign key to inventory.products.id. Join it to show the catalog name, SKU, and billing type. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `addon_id` | String | no | FK | Foreign key to crm.addons.id. Join it to name the optional extra sold beside a product. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `description` | String | no |  | `description` stores the description for this row, typed as String. Select or group by it when the question is about description. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `quantity` | Decimal | yes |  | `quantity` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `unit_price` | Decimal | yes |  | `unit_price` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `tax_percent` | Decimal | yes |  | `tax_percent` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `amount` | Decimal | yes |  | `amount` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `sort_order` | Int | yes |  | `sort_order` stores the sort order for this row, typed as Int. Select or group by it when the question is about sort order. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "invoice_id": "invoiceId_1001",
  "kind": "product",
  "product_id": "productId_1001",
  "addon_id": "addonId_1001",
  "name": "Blue Harbor Logistics",
  "description": "Blue Harbor Logistics",
  "quantity": 48000,
  "unit_price": 48000,
  "tax_percent": 48000,
  "amount": 125000
}
```

### crm.contracts

Prisma model `Contract`.

This is a subscription or term agreement with a company, including status, start, and end. Renewal and annual-recurring-revenue reports read contracts and their billing schedule. A contract is not a one-off quote.

Primary key: id.

Foreign keys and why the join exists:

- companyId -> Company.id on delete Cascade. Purpose of the join: crm.companies.id. Join it to show the account name, channel role, and parent company.
- sourceOrderId -> SalesOrder.id on delete SetNull. Purpose of the join: crm.sales_orders.id. Join it to the order that started this contract.

Categorical columns:

- `ContractStatus`: active, expired, cancelled.
- `ProductBillingFrequency`: monthly, quarterly, annual.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `company_id` | String | yes | FK | Foreign key to crm.companies.id. Join it to show the account name, channel role, and parent company. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `deal_id` | String | no | FK | Foreign key to crm.deals.id. Join it to show the opportunity title, stage, amount, and owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `title` | String | yes |  | This is the human name of this record shown in lists. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `starts_at` | DateTime | yes |  | Timestamp for starts. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `ends_at` | DateTime | yes |  | Timestamp for ends. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `arr` | Decimal | no |  | `arr` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `auto_renew` | Boolean | yes |  | `auto_renew` stores the auto renew for this row, typed as Boolean. Select or group by it when the question is about auto renew. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | ContractStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `source_order_id` | String | no | FK | Foreign key to crm.sales_orders.id. Join it to the order that started this contract. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `billing_frequency` | ProductBillingFrequency | no |  | `billing_frequency` stores the billing frequency for this row, typed as ProductBillingFrequency. Select or group by it when the question is about billing frequency. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `cancelled_at` | DateTime | no |  | Timestamp for cancelled. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `cancel_reason` | String | no |  | `cancel_reason` stores the cancel reason for this row, typed as String. Select or group by it when the question is about cancel reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `renew_deal_id` | String | no | FK | Foreign key to crm.deals.id. Join it to the renewal opportunity opened from this contract. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `renewal_reminded_at` | DateTime | no |  | Timestamp for renewal reminded. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "company_id": "companyId_1001",
  "deal_id": "dealId_1001",
  "title": "Blue Harbor \u2014 platform expansion",
  "starts_at": "2026-09-15T10:30:00Z",
  "ends_at": "2026-09-15T10:30:00Z",
  "arr": 180000,
  "auto_renew": true,
  "status": "active",
  "source_order_id": "sourceOrderId_1001",
  "billing_frequency": "monthly"
}
```

### crm.contract_billing_schedules

Prisma model `ContractBillingSchedule`.

This is one dated billing event under a contract, such as a monthly charge. Recurring-revenue reports that need the next invoice date join this table to contracts. The contract header alone does not list each bill.

Primary key: id.

Foreign keys and why the join exists:

- contractId -> Contract.id on delete Cascade. Purpose of the join: crm.contracts.id. Join it to show the agreement term, ARR, and company.

Categorical columns:

- `ContractBillingScheduleStatus`: scheduled, generated, cancelled.
- `InvoiceBillingKind`: standard, setup, subscription_start, renewal, amendment, adjustment, credit.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contract_id` | String | yes | FK | Foreign key to crm.contracts.id. Join it to show the agreement term, ARR, and company. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `billing_kind` | InvoiceBillingKind | yes |  | `billing_kind` stores the billing kind for this row, typed as InvoiceBillingKind. Select or group by it when the question is about billing kind. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `scheduled_for` | DateTime | yes |  | Timestamp for scheduled for. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `status` | ContractBillingScheduleStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `invoice_id` | String | no | FK | Foreign key to crm.invoices.id. Join it to show invoice status, total, and whether it has been paid. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `amount` | Decimal | no |  | `amount` is a money amount in the currency column on the same row. Sum it only inside one currency. Do not add a header total and its line totals together, or the report will double-count. |
| `currency` | String | yes |  | ISO currency code for the money columns on this row, such as USD or INR. Group totals by this code. A mixed-currency sum without conversion is not a valid KPI. |
| `idempotency_key` | String | yes |  | `idempotency_key` stores the idempotency key for this row, typed as String. Select or group by it when the question is about idempotency key. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contract_id": "contractId_1001",
  "billing_kind": "standard",
  "scheduled_for": "2026-09-15T10:30:00Z",
  "status": "scheduled",
  "invoice_id": "invoiceId_1001",
  "amount": 125000,
  "currency": "USD",
  "idempotency_key": "Blue Harbor Logistics",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.audit_logs

Prisma model `AuditLog`.

This is an append-only record of who changed a CRM record and which action they took. Compliance and change-history questions read it. It is not a substitute for stage history on deals, because deal stage changes are not modelled as their own table.

Primary key: id.

Categorical columns:

- `AuditAction`: create, update, delete, stage_change, assign, convert, merge, quote_sent, quote_accepted, order_created, invoice_created.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `actor_user_id` | BigInt | no |  | `actor_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `action` | AuditAction | yes |  | `action` stores the action for this row, typed as AuditAction. Select or group by it when the question is about action. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `entity_type` | String | yes |  | `entity_type` stores the entity type for this row, typed as String. Select or group by it when the question is about entity type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `entity_id` | String | yes |  | `entity_id` stores the entity id for this row, typed as String. Select or group by it when the question is about entity id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `meta` | Json | no |  | `meta` stores the meta for this row, typed as Json. Select or group by it when the question is about meta. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "actor_user_id": 42,
  "action": "create",
  "entity_type": "Blue Harbor Logistics",
  "entity_id": "entityId_1001",
  "meta": {
    "source": "example"
  },
  "created_at": "2026-09-15T10:30:00Z"
}
```

### crm.report_snapshots

Prisma model `ReportSnapshot`.

This stores a saved result of a report so the same numbers can be shown again without re-querying. The SQL executor may write a snapshot only when the product asks to save a report. Live answers should still be calculated from the source tables.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `kind` | String | yes |  | `kind` stores the kind for this row, typed as String. Select or group by it when the question is about kind. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `payload` | Json | yes |  | `payload` stores the payload for this row, typed as Json. Select or group by it when the question is about payload. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `generated_at` | DateTime | yes |  | Timestamp for generated. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "kind": "Blue Harbor Logistics",
  "payload": {
    "source": "example"
  },
  "generated_at": "2026-09-15T10:30:00Z"
}
```

### crm.domain_enrichment_cache

Prisma model `DomainEnrichmentCache`.

This caches enrichment data looked up for a company domain so the same domain is not fetched again. It is a cache, not the company master. Company reports should prefer crm.companies and use this only to explain enrichment freshness.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `domain` | String | yes |  | `domain` stores the domain for this row, typed as String. Select or group by it when the question is about domain. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `payload` | Json | yes |  | `payload` stores the payload for this row, typed as Json. Select or group by it when the question is about payload. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `source` | String | no |  | `source` stores the source for this row, typed as String. Select or group by it when the question is about source. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `expires_at` | DateTime | yes |  | Timestamp for expires. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "domain": "Blue Harbor Logistics",
  "payload": {
    "source": "example"
  },
  "source": "Blue Harbor Logistics",
  "expires_at": "2026-09-15T10:30:00Z",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.lead_enrichment_snapshots

Prisma model `LeadEnrichmentSnapshot`.

This stores the enrichment payload captured for one lead at a point in time. Lead-quality reports can show whether a contact was enriched. The live person record remains in CDP plus contact_profiles.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `company_name` | String | no |  | `company_name` stores the company name for this row, typed as String. Select or group by it when the question is about company name. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `company_size` | String | no |  | `company_size` stores the company size for this row, typed as String. Select or group by it when the question is about company size. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `industry` | String | no |  | `industry` stores the industry for this row, typed as String. Select or group by it when the question is about industry. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `company_description` | String | no |  | `company_description` stores the company description for this row, typed as String. Select or group by it when the question is about company description. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `products` | String | no |  | `products` stores the products for this row, typed as String. Select or group by it when the question is about products. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `revenue_band` | String | no |  | `revenue_band` stores the revenue band for this row, typed as String. Select or group by it when the question is about revenue band. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `seniority_tier` | String | no |  | `seniority_tier` stores the seniority tier for this row, typed as String. Select or group by it when the question is about seniority tier. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `geography` | String | no |  | `geography` stores the geography for this row, typed as String. Select or group by it when the question is about geography. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `email_domain_type` | String | no |  | `email_domain_type` stores the email domain type for this row, typed as String. Select or group by it when the question is about email domain type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `enrichment_confidence` | Float | no |  | `enrichment_confidence` stores the enrichment confidence for this row, typed as Float. Select or group by it when the question is about enrichment confidence. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `enrichment_source` | String | no |  | `enrichment_source` stores the enrichment source for this row, typed as String. Select or group by it when the question is about enrichment source. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `conflict_flags` | Json | no |  | `conflict_flags` stores the conflict flags for this row, typed as Json. Select or group by it when the question is about conflict flags. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `enrichment_timestamp` | DateTime | yes |  | Timestamp for enrichment timestamp. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contact_id": "contactId_1001",
  "company_name": "Blue Harbor Logistics",
  "company_size": "Blue Harbor Logistics",
  "industry": "Blue Harbor Logistics",
  "company_description": "Blue Harbor Logistics",
  "products": "Blue Harbor Logistics",
  "revenue_band": "Blue Harbor Logistics",
  "seniority_tier": "Blue Harbor Logistics",
  "geography": "Blue Harbor Logistics",
  "email_domain_type": "Blue Harbor Logistics"
}
```

### crm.lead_enrichment_jobs

Prisma model `LeadEnrichmentJob`.

This is the queue row for an enrichment run on one lead, including status. Operations reports count failed or stuck enrichment jobs here. The business metric for the lead itself is not this job row.

Primary key: id.

Categorical columns:

- `LeadEnrichmentStatus`: pending, running, enriched, skipped, failed.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `company_id` | String | no | FK | Foreign key to crm.companies.id. Join it to show the account name, channel role, and parent company. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `status` | LeadEnrichmentStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `attempts` | Int | yes |  | `attempts` stores the attempts for this row, typed as Int. Select or group by it when the question is about attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `max_attempts` | Int | yes |  | `max_attempts` stores the max attempts for this row, typed as Int. Select or group by it when the question is about max attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `next_retry_at` | DateTime | no |  | Timestamp for next retry. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `last_error` | String | no |  | `last_error` stores the last error for this row, typed as String. Select or group by it when the question is about last error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `result_summary` | Json | no |  | `result_summary` stores the result summary for this row, typed as Json. Select or group by it when the question is about result summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `completed_at` | DateTime | no |  | Timestamp for completed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contact_id": "contactId_1001",
  "company_id": "companyId_1001",
  "status": "pending",
  "attempts": 1,
  "max_attempts": 1,
  "next_retry_at": "2026-09-15T10:30:00Z",
  "last_error": "Blue Harbor Logistics",
  "result_summary": {
    "source": "example"
  },
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.agent_step_events

Prisma model `AgentStepEvent`.

This is one step an AI agent took, such as a tool call or a decision, stored for audit. Agent-operations reports count steps and failures. Customer pipeline numbers must not be calculated from this log.

Primary key: id.

Categorical columns:

- `AgentStepStatus`: started, ok, failed, skipped.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `agent` | String | yes |  | `agent` stores the agent for this row, typed as String. Select or group by it when the question is about agent. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `job_id` | String | yes |  | `job_id` stores the job id for this row, typed as String. Select or group by it when the question is about job id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `contact_id` | String | no | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `step` | String | yes |  | `step` stores the step for this row, typed as String. Select or group by it when the question is about step. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `label` | String | yes |  | `label` stores the label for this row, typed as String. Select or group by it when the question is about label. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | AgentStepStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `detail` | Json | no |  | `detail` stores the detail for this row, typed as Json. Select or group by it when the question is about detail. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `error_reason` | String | no |  | `error_reason` stores the error reason for this row, typed as String. Select or group by it when the question is about error reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `started_at` | DateTime | yes |  | Timestamp for started. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `ended_at` | DateTime | no |  | Timestamp for ended. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "agent": "Blue Harbor Logistics",
  "job_id": "jobId_1001",
  "contact_id": "contactId_1001",
  "step": "Blue Harbor Logistics",
  "label": "Blue Harbor Logistics",
  "status": "started",
  "detail": {
    "source": "example"
  },
  "error_reason": "Blue Harbor Logistics",
  "started_at": "2026-09-15T10:30:00Z",
  "ended_at": "2026-09-15T10:30:00Z"
}
```

### crm.agent_input_fingerprints

Prisma model `AgentInputFingerprint`.

This stores a fingerprint of an agent input so the same work is not run twice. It is an idempotency record. Reports use it only to explain duplicate suppression, not as a business fact about a deal.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `agent` | String | yes |  | `agent` stores the agent for this row, typed as String. Select or group by it when the question is about agent. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `entity_type` | String | yes |  | `entity_type` stores the entity type for this row, typed as String. Select or group by it when the question is about entity type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `entity_id` | String | yes |  | `entity_id` stores the entity id for this row, typed as String. Select or group by it when the question is about entity id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `input_hash` | String | yes |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `last_checked_at` | DateTime | yes |  | Timestamp for last checked. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `last_llm_at` | DateTime | no |  | Timestamp for last llm. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "agent": "Blue Harbor Logistics",
  "entity_type": "Blue Harbor Logistics",
  "entity_id": "entityId_1001",
  "input_hash": "[not readable by reports]",
  "last_checked_at": "2026-09-15T10:30:00Z",
  "last_llm_at": "2026-09-15T10:30:00Z",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.lead_summaries

Prisma model `LeadSummary`.

This stores the latest AI summary text for a lead. A report that shows the written summary reads it. Counts of leads still come from contact_profiles, not from how many summary rows exist.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `summary` | String | yes |  | `summary` stores the summary for this row, typed as String. Select or group by it when the question is about summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `headline` | String | no |  | `headline` stores the headline for this row, typed as String. Select or group by it when the question is about headline. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `intent` | String | no |  | `intent` stores the intent for this row, typed as String. Select or group by it when the question is about intent. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `recommended_action` | String | no |  | `recommended_action` stores the recommended action for this row, typed as String. Select or group by it when the question is about recommended action. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `flags` | Json | no |  | `flags` stores the flags for this row, typed as Json. Select or group by it when the question is about flags. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `signature` | String | yes |  | `signature` stores the signature for this row, typed as String. Select or group by it when the question is about signature. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `source` | String | yes |  | `source` stores the source for this row, typed as String. Select or group by it when the question is about source. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contact_id": "contactId_1001",
  "summary": "Blue Harbor Logistics",
  "headline": "Blue Harbor Logistics",
  "intent": "Blue Harbor Logistics",
  "recommended_action": "Blue Harbor Logistics",
  "flags": {
    "source": "example"
  },
  "signature": "Blue Harbor Logistics",
  "source": "Blue Harbor Logistics",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.notifications

Prisma model `Notification`.

This is an in-app notification for one user, such as quote accepted or a task due. Adoption reports can count unread notifications. It is not the business event itself; join the linked record if the question is about the quote or deal.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `recipient_user_id` | BigInt | yes |  | `recipient_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `actor_user_id` | BigInt | no |  | `actor_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `kind` | String | yes |  | `kind` stores the kind for this row, typed as String. Select or group by it when the question is about kind. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `title` | String | yes |  | This is the human name of this record shown in lists. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `body` | String | no |  | This is the longer text of the activity, email, or document. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `href` | String | no |  | `href` stores the href for this row, typed as String. Select or group by it when the question is about href. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `entity_type` | String | no |  | `entity_type` stores the entity type for this row, typed as String. Select or group by it when the question is about entity type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `entity_id` | String | no |  | `entity_id` stores the entity id for this row, typed as String. Select or group by it when the question is about entity id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `contact_id` | String | no | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `metadata` | Json | no |  | `metadata` stores the metadata for this row, typed as Json. Select or group by it when the question is about metadata. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `read_at` | DateTime | no |  | Timestamp for read. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "recipient_user_id": 42,
  "actor_user_id": 42,
  "kind": "Blue Harbor Logistics",
  "title": "Blue Harbor \u2014 platform expansion",
  "body": "Priya asked for a revised rollout plan before the 15 October committee.",
  "href": "Blue Harbor Logistics",
  "entity_type": "Blue Harbor Logistics",
  "entity_id": "entityId_1001",
  "contact_id": "contactId_1001",
  "metadata": {
    "source": "example"
  }
}
```

### crm.meeting_analyses

Prisma model `MeetingAnalysis`.

This stores the AI read of one meeting, including summary and extracted points. Meeting-quality and coaching reports join it to the appointment or meeting session. It does not replace the calendar appointment.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `activity_id` | String | yes | unique | `activity_id` stores the activity id for this row, typed as String. Select or group by it when the question is about activity id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `contact_id` | String | no | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `deal_id` | String | no | FK | Foreign key to crm.deals.id. Join it to show the opportunity title, stage, amount, and owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `outcome` | String | no |  | `outcome` stores the outcome for this row, typed as String. Select or group by it when the question is about outcome. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `bant_budget` | Boolean | no |  | One BANT flag on the CRM contact overlay: budget, authority, need, or timeline. True means the rep or the lifecycle flow recorded that the buyer has that element. Null means it was not captured. Do not treat null as false in a qualification rate unless the question says to. |
| `bant_authority` | Boolean | no |  | One BANT flag on the CRM contact overlay: budget, authority, need, or timeline. True means the rep or the lifecycle flow recorded that the buyer has that element. Null means it was not captured. Do not treat null as false in a qualification rate unless the question says to. |
| `bant_need` | Boolean | no |  | One BANT flag on the CRM contact overlay: budget, authority, need, or timeline. True means the rep or the lifecycle flow recorded that the buyer has that element. Null means it was not captured. Do not treat null as false in a qualification rate unless the question says to. |
| `bant_timeline_text` | String | no |  | One BANT flag on the CRM contact overlay: budget, authority, need, or timeline. True means the rep or the lifecycle flow recorded that the buyer has that element. Null means it was not captured. Do not treat null as false in a qualification rate unless the question says to. |
| `next_step_agreed` | String | no |  | `next_step_agreed` stores the next step agreed for this row, typed as String. Select or group by it when the question is about next step agreed. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `objections_raised` | Json | yes |  | `objections_raised` stores the objections raised for this row, typed as Json. Select or group by it when the question is about objections raised. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `confidence` | Float | yes |  | `confidence` stores the confidence for this row, typed as Float. Select or group by it when the question is about confidence. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `evidence` | Json | yes |  | `evidence` stores the evidence for this row, typed as Json. Select or group by it when the question is about evidence. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `analyzed_at` | DateTime | yes |  | Timestamp for analyzed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "activity_id": "activityId_1001",
  "contact_id": "contactId_1001",
  "deal_id": "dealId_1001",
  "outcome": "Blue Harbor Logistics",
  "bant_budget": true,
  "bant_authority": true,
  "bant_need": true,
  "bant_timeline_text": "Blue Harbor Logistics",
  "next_step_agreed": "Blue Harbor Logistics",
  "objections_raised": {
    "source": "example"
  }
}
```

### crm.coaching_insights

Prisma model `CoachingInsight`.

This stores a coaching note produced for a sales user from meetings or activity. Manager coaching reports group these by user. They are observations, not changes to deal amount or stage.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `activity_id` | String | yes | unique | `activity_id` stores the activity id for this row, typed as String. Select or group by it when the question is about activity id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `contact_id` | String | no | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `deal_id` | String | no | FK | Foreign key to crm.deals.id. Join it to show the opportunity title, stage, amount, and owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `rep_user_id` | BigInt | yes |  | `rep_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `interaction_type` | String | yes |  | `interaction_type` stores the interaction type for this row, typed as String. Select or group by it when the question is about interaction type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `overall_impression` | String | yes |  | `overall_impression` stores the overall impression for this row, typed as String. Select or group by it when the question is about overall impression. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `discovery_quality` | String | no |  | `discovery_quality` stores the discovery quality for this row, typed as String. Select or group by it when the question is about discovery quality. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `objection_handling` | String | no |  | `objection_handling` stores the objection handling for this row, typed as String. Select or group by it when the question is about objection handling. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `methodology_note` | String | no |  | `methodology_note` stores the methodology note for this row, typed as String. Select or group by it when the question is about methodology note. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `talk_balance_note` | String | no |  | `talk_balance_note` stores the talk balance note for this row, typed as String. Select or group by it when the question is about talk balance note. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `strengths` | Json | yes |  | `strengths` stores the strengths for this row, typed as Json. Select or group by it when the question is about strengths. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `growth_areas` | Json | yes |  | `growth_areas` stores the growth areas for this row, typed as Json. Select or group by it when the question is about growth areas. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `highlighted_moment` | String | no |  | `highlighted_moment` stores the highlighted moment for this row, typed as String. Select or group by it when the question is about highlighted moment. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `coaching_note` | String | no |  | `coaching_note` stores the coaching note for this row, typed as String. Select or group by it when the question is about coaching note. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `analyzed_at` | DateTime | yes |  | Timestamp for analyzed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "activity_id": "activityId_1001",
  "contact_id": "contactId_1001",
  "deal_id": "dealId_1001",
  "rep_user_id": 42,
  "interaction_type": "Blue Harbor Logistics",
  "overall_impression": "Blue Harbor Logistics",
  "discovery_quality": "Blue Harbor Logistics",
  "objection_handling": "Blue Harbor Logistics",
  "methodology_note": "Blue Harbor Logistics",
  "talk_balance_note": "Blue Harbor Logistics"
}
```

### crm.daily_briefings

Prisma model `DailyBriefing`.

This stores the daily briefing generated for one user. A report can show whether a briefing was produced. Pipeline totals inside the briefing text are not a second source of truth; recompute them from deals.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `user_id` | BigInt | yes | FK | Foreign key to accounts.setup_users.id. Join it to the CRM user this row belongs to. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `briefing_date` | DateTime | yes |  | Timestamp for briefing date. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `script` | String | yes |  | `script` stores the script for this row, typed as String. Select or group by it when the question is about script. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `items` | Json | yes |  | `items` stores the items for this row, typed as Json. Select or group by it when the question is about items. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `played_at` | DateTime | no |  | Timestamp for played. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "user_id": 42,
  "briefing_date": "2026-09-15T10:30:00Z",
  "script": "Blue Harbor Logistics",
  "items": {
    "source": "example"
  },
  "played_at": "2026-09-15T10:30:00Z",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.privacy_requests

Prisma model `PrivacyRequest`.

This stores a privacy request such as delete or export for a person. Compliance reports count open requests. Honouring the request is an operational workflow; the row is the record that it was asked.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `activity_id` | String | yes | unique | `activity_id` stores the activity id for this row, typed as String. Select or group by it when the question is about activity id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `request_type` | String | yes |  | `request_type` stores the request type for this row, typed as String. Select or group by it when the question is about request type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `confidence` | String | yes |  | `confidence` stores the confidence for this row, typed as String. Select or group by it when the question is about confidence. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | String | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `reason` | String | no |  | `reason` stores the reason for this row, typed as String. Select or group by it when the question is about reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `draft_confirmation` | String | no |  | `draft_confirmation` stores the draft confirmation for this row, typed as String. Select or group by it when the question is about draft confirmation. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `reviewed_by_user_id` | BigInt | no |  | `reviewed_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `reviewed_at` | DateTime | no |  | Timestamp for reviewed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `executed_at` | DateTime | no |  | Timestamp for executed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "activity_id": "activityId_1001",
  "contact_id": "contactId_1001",
  "request_type": "Blue Harbor Logistics",
  "confidence": "Blue Harbor Logistics",
  "status": "Blue Harbor Logistics",
  "reason": "Blue Harbor Logistics",
  "draft_confirmation": "Blue Harbor Logistics",
  "reviewed_by_user_id": 42,
  "reviewed_at": "2026-09-15T10:30:00Z",
  "executed_at": "2026-09-15T10:30:00Z"
}
```

### crm.lead_nurture_jobs

Prisma model `LeadNurtureJob`.

This is the queue row for an automated nurture touch on a lead. Nurture operations reports count pending and sent jobs. Marketing opt-out on contact_profiles must be respected before any send is treated as successful.

Primary key: id.

Categorical columns:

- `LeadNurtureStatus`: pending, analyzing, sent, waited, skipped, failed.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `status` | LeadNurtureStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `decision` | String | no |  | `decision` stores the decision for this row, typed as String. Select or group by it when the question is about decision. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `nurture_status` | String | no |  | `nurture_status` stores the nurture status for this row, typed as String. Select or group by it when the question is about nurture status. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `current_sequence_step` | Int | no |  | `current_sequence_step` stores the current sequence step for this row, typed as Int. Select or group by it when the question is about current sequence step. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sequence_started_at` | DateTime | no |  | Timestamp for sequence started. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `attempts` | Int | yes |  | `attempts` stores the attempts for this row, typed as Int. Select or group by it when the question is about attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `max_attempts` | Int | yes |  | `max_attempts` stores the max attempts for this row, typed as Int. Select or group by it when the question is about max attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `next_retry_at` | DateTime | no |  | Timestamp for next retry. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `last_error` | String | no |  | `last_error` stores the last error for this row, typed as String. Select or group by it when the question is about last error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `result_summary` | Json | no |  | `result_summary` stores the result summary for this row, typed as Json. Select or group by it when the question is about result summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `last_sent_at` | DateTime | no |  | Timestamp for last sent. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `completed_at` | DateTime | no |  | Timestamp for completed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contact_id": "contactId_1001",
  "status": "pending",
  "decision": "Blue Harbor Logistics",
  "nurture_status": "Blue Harbor Logistics",
  "current_sequence_step": 1,
  "sequence_started_at": "2026-09-15T10:30:00Z",
  "attempts": 1,
  "max_attempts": 1,
  "next_retry_at": "2026-09-15T10:30:00Z",
  "last_error": "Blue Harbor Logistics"
}
```

### crm.lead_lifecycle_jobs

Prisma model `LeadLifecycleJob`.

This is the queue row for a lifecycle decision on a lead, such as qualify or disqualify. Lifecycle operations reports read job status here. The resulting lead_status is stored on contact_profiles.

Primary key: id.

Categorical columns:

- `LeadLifecycleStatus`: pending, analyzing, applied, waited, skipped, failed.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `status` | LeadLifecycleStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `ladder` | String | no |  | Which ladder moved: lead_status Use this column for that fact only. Do not infer a second business meaning that is not written in the value. | lifecycle | pipeline | none This value is stored for LeadLifecycleJob and should be selected when a question mentions ladder. |
| `from_stage` | String | no |  | `from_stage` stores the from stage for this row, typed as String. Select or group by it when the question is about from stage. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `to_stage` | String | no |  | `to_stage` stores the to stage for this row, typed as String. Select or group by it when the question is about to stage. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `decision` | String | no |  | `decision` stores the decision for this row, typed as String. Select or group by it when the question is about decision. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `reason` | String | no |  | `reason` stores the reason for this row, typed as String. Select or group by it when the question is about reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `trigger_reason` | String | no |  | `trigger_reason` stores the trigger reason for this row, typed as String. Select or group by it when the question is about trigger reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `deal_id` | String | no | FK | Foreign key to crm.deals.id. Join it to show the opportunity title, stage, amount, and owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `attempts` | Int | yes |  | `attempts` stores the attempts for this row, typed as Int. Select or group by it when the question is about attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `max_attempts` | Int | yes |  | `max_attempts` stores the max attempts for this row, typed as Int. Select or group by it when the question is about max attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `next_retry_at` | DateTime | no |  | Timestamp for next retry. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `last_error` | String | no |  | `last_error` stores the last error for this row, typed as String. Select or group by it when the question is about last error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `result_summary` | Json | no |  | `result_summary` stores the result summary for this row, typed as Json. Select or group by it when the question is about result summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `last_applied_at` | DateTime | no |  | Timestamp for last applied. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `completed_at` | DateTime | no |  | Timestamp for completed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contact_id": "contactId_1001",
  "status": "pending",
  "ladder": "Blue Harbor Logistics",
  "from_stage": "Blue Harbor Logistics",
  "to_stage": "Blue Harbor Logistics",
  "decision": "Blue Harbor Logistics",
  "reason": "Blue Harbor Logistics",
  "trigger_reason": "Blue Harbor Logistics",
  "deal_id": "dealId_1001",
  "attempts": 1
}
```

### crm.email_auto_reply_jobs

Prisma model `EmailAutoReplyJob`.

This is the queue row for an automatic email reply. Mail-automation reports count these jobs. The mailbox connection itself is user_integration_connections, and the person is still the CDP contact.

Primary key: id.

Categorical columns:

- `EmailAutoReplyStatus`: pending, analyzing, replied, awaiting_demo, escalated, skipped, failed.
- `GmailPushWatchKind`: user, crm_bot.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `inbound_activity_id` | String | yes | unique | Inbound ContactActivity that triggered this job Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `mailbox_user_id` | BigInt | no |  | `mailbox_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `status` | EmailAutoReplyStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `decision` | String | no |  | `decision` stores the decision for this row, typed as String. Select or group by it when the question is about decision. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sensitivity` | String | no |  | safe Use this column for that fact only. Do not infer a second business meaning that is not written in the value. | sensitive | unknown This value is stored for EmailAutoReplyJob and should be selected when a question mentions sensitivity. |
| `category` | String | no |  | `category` stores the category for this row, typed as String. Select or group by it when the question is about category. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `reason` | String | no |  | `reason` stores the reason for this row, typed as String. Select or group by it when the question is about reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `reply_activity_id` | String | no |  | Outbound ContactActivity created after an auto-reply send Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `escalated_to_user_id` | BigInt | no |  | `escalated_to_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `attempts` | Int | yes |  | `attempts` stores the attempts for this row, typed as Int. Select or group by it when the question is about attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `max_attempts` | Int | yes |  | `max_attempts` stores the max attempts for this row, typed as Int. Select or group by it when the question is about max attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `next_retry_at` | DateTime | no |  | Timestamp for next retry. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `last_error` | String | no |  | `last_error` stores the last error for this row, typed as String. Select or group by it when the question is about last error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `result_summary` | Json | no |  | `result_summary` stores the result summary for this row, typed as Json. Select or group by it when the question is about result summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `completed_at` | DateTime | no |  | Timestamp for completed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `enum` | GmailPushWatchKind | yes |  | `enum` stores the enum for this row, typed as GmailPushWatchKind. Select or group by it when the question is about enum. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contact_id": "contactId_1001",
  "inbound_activity_id": "inboundActivityId_1001",
  "mailbox_user_id": 42,
  "status": "pending",
  "decision": "Blue Harbor Logistics",
  "sensitivity": "Blue Harbor Logistics",
  "category": "Blue Harbor Logistics",
  "reason": "Blue Harbor Logistics",
  "reply_activity_id": "replyActivityId_1001",
  "escalated_to_user_id": 42
}
```

### crm.gmail_push_watches

Prisma model `GmailPushWatch`.

This stores the Gmail push-watch subscription for one mailbox so inbound mail can wake the CRM. It is integration state. A report may show whether the watch is active. It does not contain the email body.

Primary key: id.

Categorical columns:

- `GmailPushWatchKind`: user, crm_bot.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | no | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it to the CRM user this row belongs to. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `account_email` | String | yes | unique | `account_email` stores the account email for this row, typed as String. Select or group by it when the question is about account email. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `watch_kind` | GmailPushWatchKind | yes |  | `watch_kind` stores the watch kind for this row, typed as GmailPushWatchKind. Select or group by it when the question is about watch kind. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `history_id` | String | no |  | `history_id` stores the history id for this row, typed as String. Select or group by it when the question is about history id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `expiration` | DateTime | no |  | Timestamp for expiration. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "user_id": 42,
  "account_email": "Blue Harbor Logistics",
  "watch_kind": "user",
  "history_id": "historyId_1001",
  "expiration": "2026-09-15T10:30:00Z",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.google_calendar_watches

Prisma model `GoogleCalendarWatch`.

This stores the Google Calendar watch subscription for one user. Calendar-sync health reports read it. Meetings themselves are in appointments and activities.

Primary key: id.

Categorical columns:

- `CalendarMeetCaptureStatus`: pending, dispatched, cancelled, failed.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `user_id` | BigInt | yes | unique FK | Foreign key to accounts.setup_users.id. Join it to the CRM user this row belongs to. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `channel_id` | String | yes | unique | `channel_id` stores the channel id for this row, typed as String. Select or group by it when the question is about channel id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `resource_id` | String | no |  | `resource_id` stores the resource id for this row, typed as String. Select or group by it when the question is about resource id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `channel_token` | String | yes |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `sync_token` | String | no |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `expiration` | DateTime | no |  | Timestamp for expiration. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `enum` | CalendarMeetCaptureStatus | yes |  | `enum` stores the enum for this row, typed as CalendarMeetCaptureStatus. Select or group by it when the question is about enum. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "user_id": 42,
  "channel_id": "channelId_1001",
  "resource_id": "resourceId_1001",
  "channel_token": "[not readable by reports]",
  "sync_token": "[not readable by reports]",
  "expiration": "2026-09-15T10:30:00Z",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z",
  "enum": "pending"
}
```

### crm.calendar_meet_captures

Prisma model `CalendarMeetCapture`.

This links a calendar event to a captured Meet session so the transcript and analysis can be tied back to the scheduled meeting. Meeting reports join it to appointments and meeting_assist_sessions.

Primary key: id.

Categorical columns:

- `CalendarMeetCaptureStatus`: pending, dispatched, cancelled, failed.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `user_id` | BigInt | yes | FK | Foreign key to accounts.setup_users.id. Join it to the CRM user this row belongs to. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `google_event_id` | String | yes |  | `google_event_id` stores the google event id for this row, typed as String. Select or group by it when the question is about google event id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `meet_url` | String | no |  | `meet_url` stores the meet url for this row, typed as String. Select or group by it when the question is about meet url. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `meet_code` | String | no |  | `meet_code` stores the meet code for this row, typed as String. Select or group by it when the question is about meet code. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `summary` | String | no |  | `summary` stores the summary for this row, typed as String. Select or group by it when the question is about summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `start_at` | DateTime | no |  | Timestamp for start. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `end_at` | DateTime | no |  | Timestamp for end. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `status` | CalendarMeetCaptureStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `contact_id` | String | no | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `activity_id` | String | no |  | `activity_id` stores the activity id for this row, typed as String. Select or group by it when the question is about activity id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `meeting_service_id` | String | no |  | `meeting_service_id` stores the meeting service id for this row, typed as String. Select or group by it when the question is about meeting service id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `last_error` | String | no |  | `last_error` stores the last error for this row, typed as String. Select or group by it when the question is about last error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "user_id": 42,
  "google_event_id": "googleEventId_1001",
  "meet_url": "Blue Harbor Logistics",
  "meet_code": "Blue Harbor Logistics",
  "summary": "Blue Harbor Logistics",
  "start_at": "2026-09-15T10:30:00Z",
  "end_at": "2026-09-15T10:30:00Z",
  "status": "pending",
  "contact_id": "contactId_1001",
  "activity_id": "activityId_1001"
}
```

### crm.lead_scoring_jobs

Prisma model `LeadScoringJob`.

This is the queue row for a lead-score calculation. Scoring operations reports count jobs by status. The score value the business sees is stored with the lead score result, not only as a job.

Primary key: id.

Categorical columns:

- `LeadScoringStatus`: pending, scoring, scored, failed.
- `MeetingAssistProvider`: google_meet, zoom, teams, other.
- `MeetingAssistStatus`: active, ended, failed.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `status` | LeadScoringStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `score` | Int | no |  | `score` stores the score for this row, typed as Int. Select or group by it when the question is about score. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `fit_score` | Int | no |  | `fit_score` stores the fit score for this row, typed as Int. Select or group by it when the question is about fit score. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `intent_score` | Int | no |  | `intent_score` stores the intent score for this row, typed as Int. Select or group by it when the question is about intent score. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `grade` | String | no |  | `grade` stores the grade for this row, typed as String. Select or group by it when the question is about grade. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `band` | String | no |  | `band` stores the band for this row, typed as String. Select or group by it when the question is about band. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `rationale` | String | no |  | `rationale` stores the rationale for this row, typed as String. Select or group by it when the question is about rationale. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `factors` | Json | no |  | `factors` stores the factors for this row, typed as Json. Select or group by it when the question is about factors. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `next_best_action` | String | no |  | `next_best_action` stores the next best action for this row, typed as String. Select or group by it when the question is about next best action. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `trigger_reason` | String | no |  | `trigger_reason` stores the trigger reason for this row, typed as String. Select or group by it when the question is about trigger reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `previous_score` | Int | no |  | `previous_score` stores the previous score for this row, typed as Int. Select or group by it when the question is about previous score. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `attempts` | Int | yes |  | `attempts` stores the attempts for this row, typed as Int. Select or group by it when the question is about attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `max_attempts` | Int | yes |  | `max_attempts` stores the max attempts for this row, typed as Int. Select or group by it when the question is about max attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `next_retry_at` | DateTime | no |  | Timestamp for next retry. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `last_error` | String | no |  | `last_error` stores the last error for this row, typed as String. Select or group by it when the question is about last error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `result_summary` | Json | no |  | `result_summary` stores the result summary for this row, typed as Json. Select or group by it when the question is about result summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `completed_at` | DateTime | no |  | Timestamp for completed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `enum` | MeetingAssistStatus | yes |  | `enum` stores the enum for this row, typed as MeetingAssistStatus. Select or group by it when the question is about enum. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `enum` | MeetingAssistProvider | yes |  | `enum` stores the enum for this row, typed as MeetingAssistProvider. Select or group by it when the question is about enum. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contact_id": "contactId_1001",
  "status": "pending",
  "score": 1,
  "fit_score": 1,
  "intent_score": 1,
  "grade": "Blue Harbor Logistics",
  "band": "Blue Harbor Logistics",
  "rationale": "Blue Harbor Logistics",
  "factors": {
    "source": "example"
  },
  "next_best_action": "Blue Harbor Logistics"
}
```

### crm.meeting_assist_sessions

Prisma model `MeetingAssistSession`.

This is one live or completed Meet assist session for a meeting. Assist usage reports count sessions and whether a rep opened the panel. Transcript text is in meeting_transcript_chunks.

Primary key: id.

Categorical columns:

- `MeetingAssistProvider`: google_meet, zoom, teams, other.
- `MeetingAssistStatus`: active, ended, failed.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `activity_id` | String | yes | unique | `activity_id` stores the activity id for this row, typed as String. Select or group by it when the question is about activity id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `provider` | MeetingAssistProvider | yes |  | `provider` stores the provider for this row, typed as MeetingAssistProvider. Select or group by it when the question is about provider. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `external_meeting_id` | String | no |  | `external_meeting_id` stores the external meeting id for this row, typed as String. Select or group by it when the question is about external meeting id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `join_url` | String | no |  | `join_url` stores the join url for this row, typed as String. Select or group by it when the question is about join url. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `host_user_id` | BigInt | no |  | `host_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `status` | MeetingAssistStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `started_at` | DateTime | yes |  | Timestamp for started. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `ended_at` | DateTime | no |  | Timestamp for ended. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `last_assist_at` | DateTime | no |  | Timestamp for last assist. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `last_suggestions` | Json | no |  | `last_suggestions` stores the last suggestions for this row, typed as Json. Select or group by it when the question is about last suggestions. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `meta` | Json | no |  | `meta` stores the meta for this row, typed as Json. Select or group by it when the question is about meta. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contact_id": "contactId_1001",
  "activity_id": "activityId_1001",
  "provider": "google_meet",
  "external_meeting_id": "externalMeetingId_1001",
  "join_url": "Blue Harbor Logistics",
  "host_user_id": 42,
  "status": "active",
  "started_at": "2026-09-15T10:30:00Z",
  "ended_at": "2026-09-15T10:30:00Z",
  "last_assist_at": "2026-09-15T10:30:00Z"
}
```

### crm.meeting_transcript_chunks

Prisma model `MeetingTranscriptChunk`.

This is one piece of transcript captured during a Meet assist session. It joins meeting_assist_sessions. Analytical questions about what was said belong to the knowledge-graph executor; the SQL executor only counts or fetches chunks the role is allowed to see.

Primary key: id.

Foreign keys and why the join exists:

- sessionId -> MeetingAssistSession.id on delete Cascade. Purpose of the join: the related MeetingAssistSession row so the report can show that record's name and status instead of only this id.

Categorical columns:

- `ProcessConfirmationStatus`: pending, approved, rejected, expired.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `session_id` | String | yes |  | `session_id` stores the session id for this row, typed as String. Select or group by it when the question is about session id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `seq` | Int | yes |  | `seq` stores the seq for this row, typed as Int. Select or group by it when the question is about seq. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `speaker` | String | no |  | `speaker` stores the speaker for this row, typed as String. Select or group by it when the question is about speaker. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `speaker_email` | String | no |  | `speaker_email` stores the speaker email for this row, typed as String. Select or group by it when the question is about speaker email. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `text` | String | yes |  | `text` stores the text for this row, typed as String. Select or group by it when the question is about text. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `spoken_at` | DateTime | no |  | Timestamp for spoken. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `source` | String | yes |  | live_push Use this column for that fact only. Do not infer a second business meaning that is not written in the value. | zoom_webhook | teams_graph | google_drive | speech_api | manual This value is stored for MeetingTranscriptChunk and should be selected when a question mentions source. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `enum` | ProcessConfirmationStatus | yes |  | `enum` stores the enum for this row, typed as ProcessConfirmationStatus. Select or group by it when the question is about enum. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "session_id": "sessionId_1001",
  "seq": 1,
  "speaker": "Blue Harbor Logistics",
  "speaker_email": "Blue Harbor Logistics",
  "text": "Blue Harbor Logistics",
  "spoken_at": "2026-09-15T10:30:00Z",
  "source": "Blue Harbor Logistics",
  "created_at": "2026-09-15T10:30:00Z",
  "enum": "pending"
}
```

### crm.process_confirmations

Prisma model `ProcessConfirmation`.

This stores a user's confirmation of a proposed process step, so an agent does not apply a change the user rejected. Audit reports for agent actions join it to the related record. It is not a deal stage.

Primary key: id.

Categorical columns:

- `ProcessConfirmationStatus`: pending, approved, rejected, expired.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `owner_user_id` | BigInt | yes | FK | Foreign key to accounts.setup_users.id. Join it to print the owner's name. Reps are filtered on this column. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `activity_id` | String | no |  | `activity_id` stores the activity id for this row, typed as String. Select or group by it when the question is about activity id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `deal_id` | String | no | FK | Foreign key to crm.deals.id. Join it to show the opportunity title, stage, amount, and owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `action_kind` | String | yes |  | email_proposal Use this column for that fact only. Do not infer a second business meaning that is not written in the value. | book_meeting | close_won | close_lost | quote_send | quote_accept This value is stored for ProcessConfirmation and should be selected when a question mentions action Kind. |
| `title` | String | yes |  | This is the human name of this record shown in lists. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `summary` | String | no |  | `summary` stores the summary for this row, typed as String. Select or group by it when the question is about summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `payload` | Json | yes |  | `payload` stores the payload for this row, typed as Json. Select or group by it when the question is about payload. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | ProcessConfirmationStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `decided_at` | DateTime | no |  | Timestamp for decided. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `decided_by_user_id` | BigInt | no |  | `decided_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `result_note` | String | no |  | `result_note` stores the result note for this row, typed as String. Select or group by it when the question is about result note. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contact_id": "contactId_1001",
  "owner_user_id": 42,
  "activity_id": "activityId_1001",
  "deal_id": "dealId_1001",
  "action_kind": "Blue Harbor Logistics",
  "title": "Blue Harbor \u2014 platform expansion",
  "summary": "Blue Harbor Logistics",
  "payload": {
    "source": "example"
  },
  "status": "pending",
  "decided_at": "2026-09-15T10:30:00Z"
}
```

### crm.agent_memories

Prisma model `AgentMemory`.

This stores durable memory notes an agent saved for a tenant or record. It can explain what the agent remembered. KPI numbers must be calculated from deals, invoices, and contacts, not from memory text.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `scope_type` | String | yes |  | org Use this column for that fact only. Do not infer a second business meaning that is not written in the value. | user | contact | deal This value is stored for AgentMemory and should be selected when a question mentions scope Type. |
| `scope_id` | String | yes |  | Empty string for org-wide; otherwise user/contact/deal id. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `slot_key` | String | yes |  | `slot_key` stores the slot key for this row, typed as String. Select or group by it when the question is about slot key. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `slot_value` | Json | yes |  | `slot_value` stores the slot value for this row, typed as Json. Select or group by it when the question is about slot value. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `source` | String | no |  | `source` stores the source for this row, typed as String. Select or group by it when the question is about source. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `expires_at` | DateTime | no |  | Timestamp for expires. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "scope_type": "Blue Harbor Logistics",
  "scope_id": "scopeId_1001",
  "slot_key": "Blue Harbor Logistics",
  "slot_value": {
    "source": "example"
  },
  "source": "Blue Harbor Logistics",
  "expires_at": "2026-09-15T10:30:00Z",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.a2a_spoke_tasks

Prisma model `A2aSpokeTask`.

This stores a task exchanged with another Worktual spoke through the A2A hub. Cross-product operations reports count these tasks by status. CRM business pipeline is still the deals table.

Primary key: id.

Categorical columns:

- `AppointmentSource`: crm_ui, ccaas_webchat, demo_agent.
- `AppointmentStatus`: scheduled, canceled, completed, no_show.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `task_id` | String | yes | unique | `task_id` stores the task id for this row, typed as String. Select or group by it when the question is about task id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `context_id` | String | yes |  | `context_id` stores the context id for this row, typed as String. Select or group by it when the question is about context id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `skill_id` | String | yes |  | `skill_id` stores the skill id for this row, typed as String. Select or group by it when the question is about skill id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `state` | String | yes |  | `state` stores the state for this row, typed as String. Select or group by it when the question is about state. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `actor_id` | String | yes |  | `actor_id` stores the actor id for this row, typed as String. Select or group by it when the question is about actor id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `run_id` | String | yes |  | `run_id` stores the run id for this row, typed as String. Select or group by it when the question is about run id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `idempotency_key` | String | yes |  | `idempotency_key` stores the idempotency key for this row, typed as String. Select or group by it when the question is about idempotency key. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `receipt` | Json | no |  | `receipt` stores the receipt for this row, typed as Json. Select or group by it when the question is about receipt. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `enum` | AppointmentStatus | yes |  | `enum` stores the enum for this row, typed as AppointmentStatus. Select or group by it when the question is about enum. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `enum` | AppointmentSource | yes |  | `enum` stores the enum for this row, typed as AppointmentSource. Select or group by it when the question is about enum. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "task_id": "taskId_1001",
  "context_id": "contextId_1001",
  "skill_id": "skillId_1001",
  "state": "Blue Harbor Logistics",
  "actor_id": "actorId_1001",
  "run_id": "runId_1001",
  "idempotency_key": "Blue Harbor Logistics",
  "receipt": {
    "source": "example"
  },
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.appointments

Prisma model `Appointment`.

This is a scheduled meeting or call on the CRM calendar, including start, end, guests, and links to a contact, company, or deal. Meeting-volume and upcoming-activity reports use this table. A completed meeting may also have an activity row.

Primary key: id.

Categorical columns:

- `AppointmentSource`: crm_ui, ccaas_webchat, demo_agent.
- `AppointmentStatus`: scheduled, canceled, completed, no_show.
- `MeetingAssistProvider`: google_meet, zoom, teams, other.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `contact_id` | String | yes | FK | Foreign key to cdp.customer_profile.cdp_id when the column comment says so, otherwise the contact key stored on this row. Join crm.contact_profiles on account_contact_id for CRM status. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `host_user_id` | BigInt | yes |  | `host_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `activity_id` | String | no | unique | `activity_id` stores the activity id for this row, typed as String. Select or group by it when the question is about activity id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `source` | AppointmentSource | yes |  | `source` stores the source for this row, typed as AppointmentSource. Select or group by it when the question is about source. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | AppointmentStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `title` | String | yes |  | This is the human name of this record shown in lists. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `starts_at` | DateTime | yes |  | Timestamp for starts. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `ends_at` | DateTime | yes |  | Timestamp for ends. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `timezone` | String | yes |  | `timezone` stores the timezone for this row, typed as String. Select or group by it when the question is about timezone. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `provider` | MeetingAssistProvider | yes |  | `provider` stores the provider for this row, typed as MeetingAssistProvider. Select or group by it when the question is about provider. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `join_url` | String | no |  | `join_url` stores the join url for this row, typed as String. Select or group by it when the question is about join url. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `calendar_event_id` | String | no |  | `calendar_event_id` stores the calendar event id for this row, typed as String. Select or group by it when the question is about calendar event id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `guest_emails` | Json | yes |  | `guest_emails` stores the guest emails for this row, typed as Json. Select or group by it when the question is about guest emails. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `assignment_reason` | String | no |  | `assignment_reason` stores the assignment reason for this row, typed as String. Select or group by it when the question is about assignment reason. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `canceled_at` | DateTime | no |  | Timestamp for canceled. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `completed_at` | DateTime | no |  | Timestamp for completed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "contact_id": "contactId_1001",
  "host_user_id": 42,
  "activity_id": "activityId_1001",
  "source": "crm_ui",
  "status": "scheduled",
  "title": "Blue Harbor \u2014 platform expansion",
  "starts_at": "2026-09-15T10:30:00Z",
  "ends_at": "2026-09-15T10:30:00Z",
  "timezone": "Blue Harbor Logistics",
  "provider": "google_meet"
}
```

### crm.api_keys

Prisma model `ApiKey`.

This stores a hashed API key issued for the tenant. Security reports may count active keys and last use. The raw secret is not stored, and the reports agent must never return the hash.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `key_prefix` | String | yes |  | Public hint, e.g. crm_live_ab12cd34 Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `key_hash` | String | yes |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `scopes` | String[] | yes |  | contacts Use this column for that fact only. Do not infer a second business meaning that is not written in the value. | companies | deals | activities | appointments | products | quotes | invoices | commerce This value is stored for ApiKey and should be selected when a question mentions scopes. |
| `created_by_user_id` | BigInt | yes | FK | Foreign key to accounts.setup_users.id. Join it when the question is who created the row, which can differ from the current owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `revoked_at` | DateTime | no |  | Timestamp for revoked. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `last_used_at` | DateTime | no |  | Timestamp for last used. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "name": "Blue Harbor Logistics",
  "key_prefix": "Blue Harbor Logistics",
  "key_hash": "[not readable by reports]",
  "scopes": [
    "enterprise"
  ],
  "created_by_user_id": 42,
  "created_at": "2026-09-15T10:30:00Z",
  "revoked_at": "2026-09-15T10:30:00Z",
  "last_used_at": "2026-09-15T10:30:00Z"
}
```

### crm.org_research_provider_configs

Prisma model `OrgResearchProviderConfig`.

This stores which research or prospect provider the tenant has enabled, such as ZoomInfo, without putting secrets in the report output. Prospect-source reports use it only to name the provider. Pulled people live in prospect tables and then in CDP if imported.

Primary key: id.

Categorical columns:

- `ResearchProvider`: apollo, zoominfo, lusha, builtwith.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `provider` | ResearchProvider | yes |  | `provider` stores the provider for this row, typed as ResearchProvider. Select or group by it when the question is about provider. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `enabled` | Boolean | yes |  | `enabled` stores the enabled for this row, typed as Boolean. Select or group by it when the question is about enabled. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `api_key_enc` | String | no |  | `api_key_enc` stores the api key enc for this row, typed as String. Select or group by it when the question is about api key enc. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `api_key_hint` | String | no |  | `api_key_hint` stores the api key hint for this row, typed as String. Select or group by it when the question is about api key hint. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `settings` | Json | no |  | e.g. { competitorStacks: ["salesforce"], ... } Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `updated_by_user_id` | BigInt | no |  | `updated_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "provider": "apollo",
  "enabled": true,
  "api_key_enc": "Blue Harbor Logistics",
  "api_key_hint": "Blue Harbor Logistics",
  "settings": {
    "source": "example"
  },
  "updated_by_user_id": 42,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.prospect_pull_jobs

Prisma model `ProspectPullJob`.

This is one prospect-search job, including the filters the user asked for and the job status. Prospect operations reports count jobs. People already in contacts are skipped by the product rule and should not be counted again as new leads.

Primary key: id.

Categorical columns:

- `ProspectPullStatus`: pending, searching, qualifying, personnel, ready_for_review, importing, imported, failed, cancelled.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `requested_by_user_id` | BigInt | yes |  | `requested_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `status` | ProspectPullStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `limit_n` | Int | yes |  | `limit_n` stores the limit n for this row, typed as Int. Select or group by it when the question is about limit n. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sources_requested` | Json | yes |  | `sources_requested` stores the sources requested for this row, typed as Json. Select or group by it when the question is about sources requested. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sources_used` | Json | no |  | `sources_used` stores the sources used for this row, typed as Json. Select or group by it when the question is about sources used. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `criteria` | Json | yes |  | `criteria` stores the criteria for this row, typed as Json. Select or group by it when the question is about criteria. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `attempts` | Int | yes |  | `attempts` stores the attempts for this row, typed as Int. Select or group by it when the question is about attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `max_attempts` | Int | yes |  | `max_attempts` stores the max attempts for this row, typed as Int. Select or group by it when the question is about max attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `last_error` | String | no |  | `last_error` stores the last error for this row, typed as String. Select or group by it when the question is about last error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `result_summary` | Json | no |  | `result_summary` stores the result summary for this row, typed as Json. Select or group by it when the question is about result summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `completed_at` | DateTime | no |  | Timestamp for completed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "requested_by_user_id": 42,
  "status": "pending",
  "limit_n": 1,
  "sources_requested": {
    "source": "example"
  },
  "sources_used": {
    "source": "example"
  },
  "criteria": {
    "source": "example"
  },
  "attempts": 1,
  "max_attempts": 1,
  "last_error": "Blue Harbor Logistics",
  "result_summary": {
    "source": "example"
  }
}
```

### crm.prospect_pull_candidates

Prisma model `ProspectPullCandidate`.

This is one person returned by a prospect job before or during import. It joins prospect_pull_jobs. A report of candidates versus imported leads joins this table to contact_profiles and must not treat a skipped known contact as a new lead.

Primary key: id.

Foreign keys and why the join exists:

- jobId -> ProspectPullJob.id on delete Cascade. Purpose of the join: the related ProspectPullJob row so the report can show that record's name and status instead of only this id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `job_id` | String | yes |  | `job_id` stores the job id for this row, typed as String. Select or group by it when the question is about job id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `rank` | Int | no |  | `rank` stores the rank for this row, typed as Int. Select or group by it when the question is about rank. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `selected` | Boolean | yes |  | `selected` stores the selected for this row, typed as Boolean. Select or group by it when the question is about selected. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `first_name` | String | no |  | `first_name` stores the first name for this row, typed as String. Select or group by it when the question is about first name. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `last_name` | String | no |  | `last_name` stores the last name for this row, typed as String. Select or group by it when the question is about last name. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `email` | String | no |  | `email` stores the email for this row, typed as String. Select or group by it when the question is about email. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `phone` | String | no |  | `phone` stores the phone for this row, typed as String. Select or group by it when the question is about phone. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `title` | String | no |  | This is the human name of this record shown in lists. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `company_name` | String | no |  | `company_name` stores the company name for this row, typed as String. Select or group by it when the question is about company name. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `company_domain` | String | no |  | `company_domain` stores the company domain for this row, typed as String. Select or group by it when the question is about company domain. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `linkedin_url` | String | no |  | `linkedin_url` stores the linkedin url for this row, typed as String. Select or group by it when the question is about linkedin url. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `industry` | String | no |  | `industry` stores the industry for this row, typed as String. Select or group by it when the question is about industry. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `employee_count` | Int | no |  | `employee_count` stores the employee count for this row, typed as Int. Select or group by it when the question is about employee count. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `city` | String | no |  | `city` stores the city for this row, typed as String. Select or group by it when the question is about city. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `country` | String | no |  | `country` stores the country for this row, typed as String. Select or group by it when the question is about country. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `technographics` | Json | no |  | `technographics` stores the technographics for this row, typed as Json. Select or group by it when the question is about technographics. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sources_found_in` | Json | yes |  | `sources_found_in` stores the sources found in for this row, typed as Json. Select or group by it when the question is about sources found in. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `qualify_reasons` | Json | no |  | `qualify_reasons` stores the qualify reasons for this row, typed as Json. Select or group by it when the question is about qualify reasons. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `qualify_score` | Int | no |  | `qualify_score` stores the qualify score for this row, typed as Int. Select or group by it when the question is about qualify score. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `provider_payload` | Json | no |  | `provider_payload` stores the provider payload for this row, typed as Json. Select or group by it when the question is about provider payload. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `imported_contact_id` | String | no |  | `imported_contact_id` stores the imported contact id for this row, typed as String. Select or group by it when the question is about imported contact id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "job_id": "jobId_1001",
  "organization_id": 42,
  "rank": 1,
  "selected": true,
  "first_name": "Priya",
  "last_name": "Shah",
  "email": "priya.shah@blueharbor.example",
  "phone": "Blue Harbor Logistics",
  "title": "Blue Harbor \u2014 platform expansion",
  "company_name": "Blue Harbor Logistics",
  "company_domain": "Blue Harbor Logistics"
}
```

### crm.prospect_provider_cache

Prisma model `ProspectProviderCache`.

This caches a provider response so the same search is not billed twice. It is a cache. Lead counts must use imported contact_profiles, not cached provider rows.

Primary key: id.

Categorical columns:

- `ResearchProvider`: apollo, zoominfo, lusha, builtwith.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `provider` | ResearchProvider | yes |  | `provider` stores the provider for this row, typed as ResearchProvider. Select or group by it when the question is about provider. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `query_hash` | String | yes |  | This column holds a credential, token, or hash. The SQL executor must never select it, filter on its contents, or return it in a result. A report may only say whether the parent row exists. |
| `payload` | Json | yes |  | `payload` stores the payload for this row, typed as Json. Select or group by it when the question is about payload. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `expires_at` | DateTime | yes |  | Timestamp for expires. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "provider": "apollo",
  "query_hash": "[not readable by reports]",
  "payload": {
    "source": "example"
  },
  "expires_at": "2026-09-15T10:30:00Z",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.proposal_corpus_batches

Prisma model `ProposalCorpusBatch`.

This groups a batch of past proposals used to learn writing patterns. It is training content for the proposal agent. Revenue reports do not use it.

Primary key: id.

Categorical columns:

- `ProposalCorpusBatchStatus`: uploading, processing, pending_review, failed, completed.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `created_by_user_id` | BigInt | yes | FK | Foreign key to accounts.setup_users.id. Join it when the question is who created the row, which can differ from the current owner. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `name` | String | no |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `status` | ProposalCorpusBatchStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `last_error` | String | no |  | `last_error` stores the last error for this row, typed as String. Select or group by it when the question is about last error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `result_summary` | Json | no |  | `result_summary` stores the result summary for this row, typed as Json. Select or group by it when the question is about result summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `completed_at` | DateTime | no |  | Timestamp for completed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "created_by_user_id": 42,
  "name": "Blue Harbor Logistics",
  "status": "uploading",
  "last_error": "Blue Harbor Logistics",
  "result_summary": {
    "source": "example"
  },
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z",
  "completed_at": "2026-09-15T10:30:00Z",
  "items": [
    "enterprise"
  ],
  "pairs": [
    "enterprise"
  ]
}
```

### crm.proposal_corpus_items

Prisma model `ProposalCorpusItem`.

This is one document inside a proposal corpus batch. It joins the batch. The knowledge-graph executor may cite it when explaining proposal language. The SQL executor only counts items.

Primary key: id.

Foreign keys and why the join exists:

- batchId -> ProposalCorpusBatch.id on delete Cascade. Purpose of the join: the related ProposalCorpusBatch row so the report can show that record's name and status instead of only this id.

Categorical columns:

- `ProposalCorpusItemKind`: requirement, proposal.
- `ProposalCorpusItemStatus`: pending, ingested, structured, failed.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `batch_id` | String | yes |  | `batch_id` stores the batch id for this row, typed as String. Select or group by it when the question is about batch id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `kind` | ProposalCorpusItemKind | yes |  | `kind` stores the kind for this row, typed as ProposalCorpusItemKind. Select or group by it when the question is about kind. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `pair_slot` | Int | yes |  | User-built pair index (repeatable slots). Both files in a slot share this value. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `storage_path` | String | yes |  | `storage_path` stores the storage path for this row, typed as String. Select or group by it when the question is about storage path. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `filename` | String | yes |  | `filename` stores the filename for this row, typed as String. Select or group by it when the question is about filename. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `mime` | String | no |  | `mime` stores the mime for this row, typed as String. Select or group by it when the question is about mime. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `page_count` | Int | no |  | `page_count` stores the page count for this row, typed as Int. Select or group by it when the question is about page count. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sha256` | String | no |  | `sha256` stores the sha256 for this row, typed as String. Select or group by it when the question is about sha256. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `extract_json` | Json | no |  | `extract_json` stores the extract json for this row, typed as Json. Select or group by it when the question is about extract json. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | ProposalCorpusItemStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `last_error` | String | no |  | `last_error` stores the last error for this row, typed as String. Select or group by it when the question is about last error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "batch_id": "batchId_1001",
  "organization_id": 42,
  "kind": "requirement",
  "pair_slot": 1,
  "storage_path": "Blue Harbor Logistics",
  "filename": "Blue Harbor Logistics",
  "mime": "Blue Harbor Logistics",
  "page_count": 1,
  "sha256": "Blue Harbor Logistics",
  "extract_json": {
    "source": "example"
  },
  "status": "pending"
}
```

### crm.proposal_corpus_pairs

Prisma model `ProposalCorpusPair`.

This stores a matched pair of corpus texts used to compare proposal language. It joins corpus items. It is an analysis artefact, not a customer quote.

Primary key: id.

Foreign keys and why the join exists:

- batchId -> ProposalCorpusBatch.id on delete Cascade. Purpose of the join: the related ProposalCorpusBatch row so the report can show that record's name and status instead of only this id.
- requirementItemId -> ProposalCorpusItem.id on delete Cascade. Purpose of the join: the related ProposalCorpusItem row so the report can show that record's name and status instead of only this id.
- proposalItemId -> ProposalCorpusItem.id on delete Cascade. Purpose of the join: the related ProposalCorpusItem row so the report can show that record's name and status instead of only this id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `batch_id` | String | yes |  | `batch_id` stores the batch id for this row, typed as String. Select or group by it when the question is about batch id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `requirement_item_id` | String | yes |  | `requirement_item_id` stores the requirement item id for this row, typed as String. Select or group by it when the question is about requirement item id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `proposal_item_id` | String | yes |  | `proposal_item_id` stores the proposal item id for this row, typed as String. Select or group by it when the question is about proposal item id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `confidence` | Float | no |  | `confidence` stores the confidence for this row, typed as Float. Select or group by it when the question is about confidence. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `gaps_json` | Json | no |  | `gaps_json` stores the gaps json for this row, typed as Json. Select or group by it when the question is about gaps json. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `pairing_source` | String | yes |  | user_explicit = repeatable-slot upload; legacy_auto = pre-ship auto-paired rows. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `is_visual_master` | Boolean | yes |  | True for the one pair in the batch whose proposal feeds theme/skeleton freeze. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "batch_id": "batchId_1001",
  "organization_id": 42,
  "requirement_item_id": "requirementItemId_1001",
  "proposal_item_id": "proposalItemId_1001",
  "confidence": 48000,
  "gaps_json": {
    "source": "example"
  },
  "pairing_source": "Blue Harbor Logistics",
  "is_visual_master": true,
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z",
  "caseStudies": [
    "enterprise"
  ]
}
```

### crm.proposal_corpus_case_studies

Prisma model `ProposalCorpusCaseStudy`.

This stores a case study extracted from the proposal corpus. Proposal content reports can list case studies. Won-revenue proof still comes from deals in closed_won, not from this text.

Primary key: id.

Foreign keys and why the join exists:

- batchId -> ProposalCorpusBatch.id on delete Cascade. Purpose of the join: the related ProposalCorpusBatch row so the report can show that record's name and status instead of only this id.
- pairId -> ProposalCorpusPair.id on delete Cascade. Purpose of the join: the related ProposalCorpusPair row so the report can show that record's name and status instead of only this id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `batch_id` | String | yes |  | `batch_id` stores the batch id for this row, typed as String. Select or group by it when the question is about batch id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `pair_id` | String | yes |  | `pair_id` stores the pair id for this row, typed as String. Select or group by it when the question is about pair id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `pairing_confidence` | Float | yes |  | `pairing_confidence` stores the pairing confidence for this row, typed as Float. Select or group by it when the question is about pairing confidence. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `section_analysis` | Json | yes |  | `section_analysis` stores the section analysis for this row, typed as Json. Select or group by it when the question is about section analysis. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `length_analysis` | Json | yes |  | `length_analysis` stores the length analysis for this row, typed as Json. Select or group by it when the question is about length analysis. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "batch_id": "batchId_1001",
  "pair_id": "pairId_1001",
  "pairing_confidence": 48000,
  "section_analysis": {
    "source": "example"
  },
  "length_analysis": {
    "source": "example"
  },
  "created_at": "2026-09-15T10:30:00Z"
}
```

### crm.proposal_content_playbooks

Prisma model `ProposalContentPlaybook`.

This stores reusable proposal content guidance learned from the corpus. It is read by the proposal agent. A report may list playbooks. It does not price a deal.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `version` | Int | yes |  | `version` stores the version for this row, typed as Int. Select or group by it when the question is about version. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `section_specs_json` | Json | yes |  | `section_specs_json` stores the section specs json for this row, typed as Json. Select or group by it when the question is about section specs json. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `length_model_json` | Json | yes |  | `length_model_json` stores the length model json for this row, typed as Json. Select or group by it when the question is about length model json. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `exemplar_bank_json` | Json | yes |  | `exemplar_bank_json` stores the exemplar bank json for this row, typed as Json. Select or group by it when the question is about exemplar bank json. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `case_study_count` | Int | yes |  | `case_study_count` stores the case study count for this row, typed as Int. Select or group by it when the question is about case study count. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `confidence_level` | String | yes |  | low (<8 case studies) Use this column for that fact only. Do not infer a second business meaning that is not written in the value. | high (>=8) This value is stored for ProposalContentPlaybook and should be selected when a question mentions confidence Level. |
| `variance_log_json` | Json | no |  | `variance_log_json` stores the variance log json for this row, typed as Json. Select or group by it when the question is about variance log json. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "version": 1,
  "section_specs_json": {
    "source": "example"
  },
  "length_model_json": {
    "source": "example"
  },
  "exemplar_bank_json": {
    "source": "example"
  },
  "case_study_count": 1,
  "confidence_level": "Blue Harbor Logistics",
  "variance_log_json": {
    "source": "example"
  },
  "created_at": "2026-09-15T10:30:00Z",
  "playbooks": [
    "enterprise"
  ]
}
```

### crm.proposal_corpus_jobs

Prisma model `ProposalCorpusJob`.

This is the job that builds or refreshes a proposal corpus. Operations reports count job status. Customer-facing proposal status remains on the proposals table.

Primary key: id.

Foreign keys and why the join exists:

- batchId -> ProposalCorpusBatch.id on delete Cascade. Purpose of the join: the related ProposalCorpusBatch row so the report can show that record's name and status instead of only this id.

Categorical columns:

- `ProposalCorpusJobStatus`: pending, ingesting, structuring, pairing, synthesizing, pending_review, failed, cancelled.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `batch_id` | String | yes |  | `batch_id` stores the batch id for this row, typed as String. Select or group by it when the question is about batch id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `status` | ProposalCorpusJobStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `stage` | String | yes |  | Current deal stage: qualification, discover, propose, negotiate, closed_won, or closed_lost. There is no stage-history table, so this value is the stage now, not the path the deal took. Open pipeline is the first four values. Won and lost are the last two. |
| `attempts` | Int | yes |  | `attempts` stores the attempts for this row, typed as Int. Select or group by it when the question is about attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `max_attempts` | Int | yes |  | `max_attempts` stores the max attempts for this row, typed as Int. Select or group by it when the question is about max attempts. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `last_error` | String | no |  | `last_error` stores the last error for this row, typed as String. Select or group by it when the question is about last error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `result_summary` | Json | no |  | `result_summary` stores the result summary for this row, typed as Json. Select or group by it when the question is about result summary. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |
| `completed_at` | DateTime | no |  | Timestamp for completed. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |

Example row:

```json
{
  "id": "row_1001",
  "batch_id": "batchId_1001",
  "organization_id": 42,
  "status": "pending",
  "stage": "propose",
  "attempts": 1,
  "max_attempts": 1,
  "last_error": "Blue Harbor Logistics",
  "result_summary": {
    "source": "example"
  },
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z",
  "completed_at": "2026-09-15T10:30:00Z"
}
```

### crm.proposal_playbooks

Prisma model `ProposalPlaybook`.

This is the active playbook the proposal agent follows for the tenant. It joins organization scope. Reports can show which playbook is active. Quote math stays on quotes.

Primary key: id.

Foreign keys and why the join exists:

- sourceBatchId -> ProposalCorpusBatch.id on delete SetNull. Purpose of the join: the related ProposalCorpusBatch row so the report can show that record's name and status instead of only this id.
- contentPlaybookId -> ProposalContentPlaybook.id on delete SetNull. Purpose of the join: the related ProposalContentPlaybook row so the report can show that record's name and status instead of only this id.

Categorical columns:

- `ProposalPlaybookStatus`: draft, pending_review, approved, rejected.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `source_batch_id` | String | no |  | `source_batch_id` stores the source batch id for this row, typed as String. Select or group by it when the question is about source batch id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `content_playbook_id` | String | no |  | Snapshot of the org content playbook at freeze time. Not a live pointer. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `name` | String | yes |  | This is the display name of this record. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `tags_json` | Json | no |  | `tags_json` stores the tags json for this row, typed as Json. Select or group by it when the question is about tags json. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `sections_json` | Json | yes |  | `sections_json` stores the sections json for this row, typed as Json. Select or group by it when the question is about sections json. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `blueprint` | Json | no |  | Exact page-clone visual master from the winning proposal PDF. Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `assets` | Json | no |  | Page assets for the visual master (pageHtml / rasters). Use this column for that fact only. Do not infer a second business meaning that is not written in the value. |
| `status` | ProposalPlaybookStatus | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `approved_at` | DateTime | no |  | Timestamp for approved. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `approved_by_user_id` | BigInt | no |  | `approved_by_user_id` is a CRM user id in accounts.setup_users. Join that table to show the person's name. Do not return password columns from the user row. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "source_batch_id": "sourceBatchId_1001",
  "content_playbook_id": "contentPlaybookId_1001",
  "name": "Blue Harbor Logistics",
  "tags_json": {
    "source": "example"
  },
  "sections_json": {
    "source": "example"
  },
  "blueprint": {
    "source": "example"
  },
  "assets": {
    "source": "example"
  },
  "status": "draft",
  "approved_at": "2026-09-15T10:30:00Z",
  "approved_by_user_id": 42
}
```

### crm.seo_projects

Prisma model `SeoProject`.

This is an SEO project record kept beside CRM for a tenant site or campaign. SEO reports count projects and join snapshots. It is not a sales deal and must not be added into pipeline.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `external_project_id` | String | yes |  | `external_project_id` stores the external project id for this row, typed as String. Select or group by it when the question is about external project id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `domain` | String | no |  | `domain` stores the domain for this row, typed as String. Select or group by it when the question is about domain. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `market` | String | no |  | `market` stores the market for this row, typed as String. Select or group by it when the question is about market. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `raw` | Json | no |  | `raw` stores the raw for this row, typed as Json. Select or group by it when the question is about raw. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `synced_at` | DateTime | yes |  | Timestamp for synced. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "external_project_id": "externalProjectId_1001",
  "domain": "Blue Harbor Logistics",
  "market": "Blue Harbor Logistics",
  "raw": {
    "source": "example"
  },
  "synced_at": "2026-09-15T10:30:00Z",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.seo_tool_snapshots

Prisma model `SeoToolSnapshot`.

This stores a point-in-time SEO tool result for a project. Trend reports order these by time and join seo_projects. Estimates are not Semrush results unless the Semrush source is actually configured.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `external_project_id` | String | yes |  | `external_project_id` stores the external project id for this row, typed as String. Select or group by it when the question is about external project id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `tool_name` | String | yes |  | `tool_name` stores the tool name for this row, typed as String. Select or group by it when the question is about tool name. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `payload` | Json | no |  | `payload` stores the payload for this row, typed as Json. Select or group by it when the question is about payload. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `error` | String | no |  | `error` stores the error for this row, typed as String. Select or group by it when the question is about error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `fetched_at` | DateTime | yes |  | Timestamp for fetched. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "external_project_id": "externalProjectId_1001",
  "tool_name": "Blue Harbor Logistics",
  "payload": {
    "source": "example"
  },
  "error": "Blue Harbor Logistics",
  "fetched_at": "2026-09-15T10:30:00Z",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.seo_generated_content

Prisma model `SeoGeneratedContent`.

This stores content the SEO flow generated for a project. Content-output reports count rows by project. It is not an email sent to a lead.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it to the CRM user this row belongs to. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `project_id` | String | no |  | `project_id` stores the project id for this row, typed as String. Select or group by it when the question is about project id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `content_type` | String | yes |  | `content_type` stores the content type for this row, typed as String. Select or group by it when the question is about content type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `title` | String | yes |  | This is the human name of this record shown in lists. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `slug` | String | no |  | `slug` stores the slug for this row, typed as String. Select or group by it when the question is about slug. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `seo_score` | Int | no |  | `seo_score` stores the seo score for this row, typed as Int. Select or group by it when the question is about seo score. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `body` | Json | yes |  | This is the longer text of the activity, email, or document. The SQL executor may filter or return it when the user asks for that text. The knowledge-graph executor may read it to explain why. Do not parse it with keyword rules to invent a number. |
| `status` | String | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `campaign_id` | String | no |  | `campaign_id` stores the campaign id for this row, typed as String. Select or group by it when the question is about campaign id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `primary_keyword` | String | no |  | `primary_keyword` stores the primary keyword for this row, typed as String. Select or group by it when the question is about primary keyword. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `keyword_query_id` | String | no |  | `keyword_query_id` stores the keyword query id for this row, typed as String. Select or group by it when the question is about keyword query id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "user_id": 42,
  "project_id": "projectId_1001",
  "content_type": "Blue Harbor Logistics",
  "title": "Blue Harbor \u2014 platform expansion",
  "slug": "Blue Harbor Logistics",
  "seo_score": 1,
  "body": "Priya asked for a revised rollout plan before the 15 October committee.",
  "status": "Blue Harbor Logistics",
  "campaign_id": "campaignId_1001",
  "primary_keyword": "Blue Harbor Logistics"
}
```

### crm.seo_keyword_queries

Prisma model `SeoKeywordQuery`.

This stores a keyword query run for an SEO project, including the phrase asked. Keyword reports group these queries. Search volume is only a provider number when the snapshot says so.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it to the CRM user this row belongs to. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `seed` | String | yes |  | `seed` stores the seed for this row, typed as String. Select or group by it when the question is about seed. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `location` | String | yes |  | `location` stores the location for this row, typed as String. Select or group by it when the question is about location. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `language` | String | yes |  | `language` stores the language for this row, typed as String. Select or group by it when the question is about language. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `filters` | Json | yes |  | `filters` stores the filters for this row, typed as Json. Select or group by it when the question is about filters. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `cache_key` | String | yes |  | `cache_key` stores the cache key for this row, typed as String. Select or group by it when the question is about cache key. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `semrush_called_at` | DateTime | no |  | Timestamp for semrush called. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `expires_at` | DateTime | yes |  | Timestamp for expires. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `payload` | Json | yes |  | `payload` stores the payload for this row, typed as Json. Select or group by it when the question is about payload. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `error` | String | no |  | `error` stores the error for this row, typed as String. Select or group by it when the question is about error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `budget_skipped` | Boolean | yes |  | `budget_skipped` stores the budget skipped for this row, typed as Boolean. Select or group by it when the question is about budget skipped. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "user_id": 42,
  "seed": "Blue Harbor Logistics",
  "location": "Blue Harbor Logistics",
  "language": "Blue Harbor Logistics",
  "filters": {
    "source": "example"
  },
  "cache_key": "Blue Harbor Logistics",
  "semrush_called_at": "2026-09-15T10:30:00Z",
  "expires_at": "2026-09-15T10:30:00Z",
  "payload": {
    "source": "example"
  },
  "error": "Blue Harbor Logistics"
}
```

### crm.seo_saved_keywords

Prisma model `SeoSavedKeyword`.

This is a keyword the user chose to keep for a project. Saved-keyword reports list these rows. They join seo_projects and are not CRM lead tags.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `query_id` | String | yes |  | `query_id` stores the query id for this row, typed as String. Select or group by it when the question is about query id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `term` | String | yes |  | `term` stores the term for this row, typed as String. Select or group by it when the question is about term. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `metrics` | Json | yes |  | `metrics` stores the metrics for this row, typed as Json. Select or group by it when the question is about metrics. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `content_id` | String | no |  | `content_id` stores the content id for this row, typed as String. Select or group by it when the question is about content id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "query_id": "queryId_1001",
  "term": "Blue Harbor Logistics",
  "metrics": {
    "source": "example"
  },
  "content_id": "contentId_1001",
  "created_at": "2026-09-15T10:30:00Z",
  "updated_at": "2026-09-15T10:30:00Z"
}
```

### crm.seo_social_posts

Prisma model `SeoSocialPost`.

This stores a social post draft or record created from the SEO flow. Social-output reports count posts by project and status. It does not mean the post was published on LinkedIn unless status says so.

Primary key: id.

Columns:

| Column | Type | Required | Key | Description |
| --- | --- | --- | --- | --- |
| `id` | String | yes | PK | Primary key of this row. Other tables store this value when they point at this record. Use it in joins. Do not treat it as a business number such as a quote number or an order number. |
| `organization_id` | BigInt | yes | FK | Tenant id, equal to accounts.organizations.id. Every report query must filter this to the signed-in organization before any other predicate. A missing filter would mix two customers' pipeline. |
| `user_id` | BigInt | no | FK | Foreign key to accounts.setup_users.id. Join it to the CRM user this row belongs to. Keep the filter on organization_id even after the join, because the related row is also tenant-scoped. |
| `content_id` | String | no |  | `content_id` stores the content id for this row, typed as String. Select or group by it when the question is about content id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `platform` | String | yes |  | `platform` stores the platform for this row, typed as String. Select or group by it when the question is about platform. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `post_type` | String | yes |  | `post_type` stores the post type for this row, typed as String. Select or group by it when the question is about post type. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `copy` | Json | yes |  | `copy` stores the copy for this row, typed as Json. Select or group by it when the question is about copy. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `status` | String | yes |  | `status` is the lifecycle status of this row. Allowed values are the enum or the varchar codes documented for this table. Filter current operational reports to the live status, and keep cancelled, void, archived, or inactive rows only when the question asks for them. |
| `scheduled_at` | DateTime | no |  | Timestamp for scheduled. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `published_at` | DateTime | no |  | Timestamp for published. Null means that moment has not happened yet. When a question says this month or this quarter, filter this column if it names the event, and use created_at only for when the row was first saved. |
| `external_post_id` | String | no |  | `external_post_id` stores the external post id for this row, typed as String. Select or group by it when the question is about external post id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `last_error` | String | no |  | `last_error` stores the last error for this row, typed as String. Select or group by it when the question is about last error. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `accounts_connection_id` | String | no |  | `accounts_connection_id` stores the accounts connection id for this row, typed as String. Select or group by it when the question is about accounts connection id. Leave it out of the query when the question does not need it, so the result stays small and free of unrelated fields. |
| `created_at` | DateTime | yes |  | When this row was first inserted. A question about what was created this week, month, or quarter filters this column. It does not move when the row is edited later. |
| `updated_at` | DateTime | yes |  | When this row was last changed. A stage edit and an amount edit both move this timestamp, and the previous value is not kept. Use it for freshness. Use a dedicated event column, such as closed_at, when the question is about that event. |

Example row:

```json
{
  "id": "row_1001",
  "organization_id": 42,
  "user_id": 42,
  "content_id": "contentId_1001",
  "platform": "Blue Harbor Logistics",
  "post_type": "Blue Harbor Logistics",
  "copy": {
    "source": "example"
  },
  "status": "Blue Harbor Logistics",
  "scheduled_at": "2026-09-15T10:30:00Z",
  "published_at": "2026-09-15T10:30:00Z",
  "external_post_id": "externalPostId_1001",
  "last_error": "Blue Harbor Logistics"
}
```
