from pathlib import Path

from reports_analytics_agent_CRM_B2B.core.prompt_load import listed_skill_ids, load_agent_prompt, skill_body

PACK = Path(__file__).resolve().parents[2]


def test_listed_skill_ids_and_compose():
    domain = PACK / "domain" / "agent.md"
    ids = listed_skill_ids(domain.read_text())
    assert ids == ["crm-kpi-catalog", "crm-object-lock", "crm-money", "crm-plan-kg"]
    prompt = load_agent_prompt(domain)
    assert "Lock the **object**" in prompt
    assert "`lead_count`" in prompt
    assert "won_revenue" in prompt
    sql = load_agent_prompt(PACK / "sql_executor" / "agent.md")
    assert "rpt.deals" in sql
    kg = load_agent_prompt(PACK / "kg_executor" / "agent.md")
    assert "organization_id" in kg
    assert "DIRECT EXECUTIVE ANSWER" not in kg
    brief = skill_body("crm-kg-briefing")
    assert "NEVER MIX" in brief.upper() or "Never mix" in brief
