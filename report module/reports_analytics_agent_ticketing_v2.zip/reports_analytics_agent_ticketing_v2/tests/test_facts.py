"""Unit tests for core/facts.py."""

from __future__ import annotations

from reports_analytics_agent_ticketing_v2.core.facts import assemble_facts


def test_facts_single_kpi():
    res = {"status": "ok", "rows": [{"ticket_count": 42}]}
    text = assemble_facts(res, kpi_id="ticket_count")
    assert text == "RESULT: ticket_count = 42"


def test_facts_empty():
    res = {"status": "ok", "rows": []}
    text = assemble_facts(res, task_goal="Find tickets")
    assert text == "RESULT: no rows\ntask_goal: Find tickets"


def test_facts_error():
    res = {"status": "error", "error_type": "REPLAN", "error": "Table syntax error"}
    text = assemble_facts(res, task_goal="Count tickets")
    assert "EXECUTION_ERROR" in text
    assert "error_type: REPLAN" in text
    assert "Table syntax error" in text


def test_facts_breakdown():
    res = {
        "status": "ok",
        "rows": [
            {"queue_name": "Billing", "ticket_count": 15},
            {"queue_name": "Tech Support", "ticket_count": 10},
        ],
    }
    text = assemble_facts(res, group_by=["queue"], answer_type="breakdown")
    assert "RESULT: 2 group(s)" in text
    assert "total_ticket_count: 25" in text
    assert "Billing: 15" in text
    assert "Tech Support: 10" in text
