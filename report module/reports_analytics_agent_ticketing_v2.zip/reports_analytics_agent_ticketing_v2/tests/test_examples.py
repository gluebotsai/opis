"""Unit tests for core/examples.py few-shot picker."""

from __future__ import annotations

import pytest

from reports_analytics_agent_ticketing_v2.core.examples import (
    Example,
    format_examples_for_prompt,
    load_examples,
    pick_examples,
    pick_examples_llm,
)
from reports_analytics_agent_ticketing_v2.core.loader import PRODUCT_DIR


def test_load_sql_examples():
    sql_path = PRODUCT_DIR / "examples" / "sql.yml"
    assert sql_path.exists()
    examples = load_examples(sql_path)
    assert len(examples) >= 8
    assert any(ex.id == "kpi_ticket_count_all" for ex in examples)
    assert all(ex.sql is not None for ex in examples)


def test_load_cypher_examples():
    cypher_path = PRODUCT_DIR / "kg" / "examples" / "cypher.yml"
    assert cypher_path.exists()
    examples = load_examples(cypher_path)
    assert len(examples) >= 3
    assert any(ex.id == "why_breakdown_by_queue" for ex in examples)
    assert all(ex.cypher is not None for ex in examples)


def test_format_examples_for_prompt():
    exs = [
        Example(id="e1", goal="Count all tickets", sql="SELECT COUNT(*) FROM rpt.tickets", tags=[], answer_type="kpi"),
        Example(id="e2", goal="List open tickets", sql="SELECT * FROM rpt.tickets WHERE status = 'Open'", tags=[], answer_type="list"),
    ]
    formatted = format_examples_for_prompt(exs, kind="sql")
    assert "# Goal: Count all tickets" in formatted
    assert "SELECT COUNT(*) FROM rpt.tickets" in formatted
    assert "# Goal: List open tickets" in formatted


def test_pick_examples_fallback():
    exs = [
        Example(id=f"e{i}", goal=f"Goal {i}", sql=f"SELECT {i}", tags=[])
        for i in range(10)
    ]
    # Without call_llm, should pick top_k first items
    picked = pick_examples("Any goal", exs, top_k=4)
    assert len(picked) == 4
    assert [e.id for e in picked] == ["e0", "e1", "e2", "e3"]


def test_pick_examples_llm():
    exs = [
        Example(id="kpi_count", goal="Count total tickets", sql="SELECT COUNT(*) FROM rpt.tickets", tags=[]),
        Example(id="sla_breach", goal="Calculate SLA breach rate", sql="SELECT breach_rate FROM rpt.ticket_facts", tags=[]),
        Example(id="list_open", goal="List all open tickets", sql="SELECT * FROM rpt.tickets WHERE status='Open'", tags=[]),
    ]

    def mock_llm(messages):
        # LLM chooses SLA breach as most relevant
        return '["sla_breach", "kpi_count"]'

    picked = pick_examples_llm("What is our breach rate?", exs, mock_llm, top_k=2)
    assert len(picked) == 2
    assert picked[0].id == "sla_breach"
    assert picked[1].id == "kpi_count"
