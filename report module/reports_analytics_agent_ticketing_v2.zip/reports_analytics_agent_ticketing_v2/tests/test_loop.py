"""Unit tests for core/loop.py (2-attempt controller, Option A)."""

from __future__ import annotations

from reports_analytics_agent_ticketing_v2.core.loop import LoopState, MAX_DOMAIN_ATTEMPTS


def test_loop_initial_state():
    loop = LoopState()
    assert loop.attempts == 0
    assert not loop.exhausted
    assert loop.max_attempts == 2


def test_loop_deny_not_replan():
    loop = LoopState()
    loop.record_attempt()
    deny_res = {"status": "error", "error_type": "DENY", "error": "Access denied"}
    loop.record_error(deny_res)
    assert not loop.should_replan(deny_res)
    final = loop.final_error()
    assert final["status"] == "error"
    assert final["error_type"] == "DENY"


def test_loop_replan_max_2_attempts():
    loop = LoopState()

    # Attempt 1: fails with REPLAN
    loop.record_attempt()
    res1 = {"status": "error", "error_type": "REPLAN", "error": "Slot error"}
    loop.record_error(res1)
    assert loop.should_replan(res1)
    payload = loop.replan_payload()
    assert payload["kind"] == "replan_request"
    assert payload["attempt"] == 1
    assert payload["max_attempts"] == 2
    assert "error_type" in payload

    # Attempt 2: also fails with REPLAN
    loop.record_attempt()
    res2 = {"status": "error", "error_type": "REPLAN", "error": "Execution error"}
    loop.record_error(res2)
    # After attempt 2, should NOT replan again (exhausted)
    assert not loop.should_replan(res2)
    assert loop.exhausted

    # Final error payload
    final = loop.final_error()
    assert final["status"] == "error"
    assert final["attempts_made"] == 2
    assert "Execution error" in final["message"]
