"""Unit tests for core/time.py."""

from __future__ import annotations

from datetime import datetime, timezone
from reports_analytics_agent_ticketing_v2.core.time import resolve_expression


def test_resolve_all_time_expressions():
    for word in ["all time", "all-time", "overall", "total", "lifetime", "ever", "any", "unbounded", ""]:
        tb = resolve_expression(word)
        assert tb.start is None
        assert tb.end is None
        assert "overall" in tb.echo.lower()


def test_resolve_calendar_periods():
    # this month
    tb_month = resolve_expression("this month")
    assert tb_month.start is not None
    assert tb_month.end is not None
    assert tb_month.start.day == 1

    # this week
    tb_week = resolve_expression("this week")
    assert tb_week.start is not None
    assert tb_week.end is not None

    # this year
    tb_year = resolve_expression("this year")
    assert tb_year.start is not None
    assert tb_year.end is not None
    assert tb_year.start.month == 1
    assert tb_year.start.day == 1


def test_resolve_trailing_windows():
    tb_7d = resolve_expression("last 7 days")
    assert tb_7d.start is not None
    assert tb_7d.end is not None
    assert (tb_7d.end - tb_7d.start).days >= 7

    tb_24h = resolve_expression("past 24 hours")
    assert tb_24h.start is not None
    assert tb_24h.end is not None


def test_resolve_month_year():
    tb = resolve_expression("August 2026")
    assert tb.start == datetime(2026, 8, 1, tzinfo=timezone.utc)
    assert tb.end == datetime(2026, 9, 1, tzinfo=timezone.utc)


def test_resolve_fallback_graceful():
    tb = resolve_expression("completely unknown time string")
    assert tb.start is None
    assert tb.end is None
    assert "overall" in tb.echo.lower()
