"""Security tests verifying resolver data isolation.

Resolver must only ever see their own tickets (resolver_id = user_id).
They cannot see other tickets, other resolvers' tickets, or queue tickets.
"""

from __future__ import annotations

import pytest
from reports_analytics_agent_ticketing_v2.core.run_sql import run_sql
from reports_analytics_agent_ticketing_v2.core.sql_guard import GuardError, guard_sql

ORG = 900001
RESOLVER = 91003
QA = 92001


def test_resolver_queue_ticket_counts_scoped_to_self():
    """Resolver querying queue_ticket_counts must have scope resolver_id = {user_id}."""
    guarded = guard_sql(
        "SELECT * FROM rpt.queue_ticket_counts",
        role="resolver",
        organization_id=ORG,
        user_id=RESOLVER,
        queue_ids=[QA],
    )
    # Verify the generated SQL scopes resolver_id to the user's bound param
    assert "resolver_id = %(_user_id)s" in guarded.sql
    assert guarded.params["_user_id"] == RESOLVER


def test_resolver_denied_other_views():
    """Resolver must not access agents, queues, queue_members, customers."""
    for view in ["agents", "queues", "queue_members", "customers", "accounts", "kb_articles", "recommendations", "approvals"]:
        res = run_sql(
            f"SELECT * FROM rpt.{view}",
            role="resolver",
            organization_id=ORG,
            user_id=RESOLVER,
            queue_ids=[QA],
        )
        assert res["status"] == "error"
        assert res["error_type"] == "DENY"
