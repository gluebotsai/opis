"""Unit tests for core/run_kpi.py."""

from __future__ import annotations

import pytest
from reports_analytics_agent_ticketing_v2.core.run_kpi import run_kpi

ORG = 900001
ADMIN = 91001
AGENT = 91002
RESOLVER = 91003
QA = 92001


def test_run_kpi_happy_path():
    res = run_kpi(
        "ticket_count",
        organization_id=ORG,
        user_id=ADMIN,
        role="admin",
        queue_ids=[QA],
        scope_level="org",
        time_start="2026-09-01T00:00:00+00:00",
        time_end="2026-10-01T00:00:00+00:00",
    )
    assert res["status"] == "compiled"
    assert "ticket_count" in res["sql"]
    assert "organization_id = 900001" in res["sql"]


def test_run_kpi_not_found_replan():
    res = run_kpi(
        "non_existent_kpi",
        organization_id=ORG,
        user_id=ADMIN,
        role="admin",
        queue_ids=[QA],
    )
    assert res["status"] == "error"
    assert res["error_type"] == "REPLAN"
    assert "kpi_not_found" in res["error"]


def test_run_kpi_scope_denied():
    # Resolver cannot run org-level KPIs
    res = run_kpi(
        "ticket_count",
        organization_id=ORG,
        user_id=RESOLVER,
        role="resolver",
        queue_ids=[QA],
        scope_level="org",
    )
    assert res["status"] == "error"
    assert res["error_type"] == "DENY"
    assert "scope_denied" in res["error"]


def test_run_kpi_own_scope_resolver():
    # Resolver running own scope should succeed
    res = run_kpi(
        "ticket_count",
        organization_id=ORG,
        user_id=RESOLVER,
        role="resolver",
        queue_ids=[QA],
        scope_level="own",
    )
    assert res["status"] == "compiled"
    assert "resolver_id = 91003" in res["sql"]
