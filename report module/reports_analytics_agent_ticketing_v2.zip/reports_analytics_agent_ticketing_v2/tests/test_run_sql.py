"""Unit tests for core/run_sql.py."""

from __future__ import annotations

import pytest
from reports_analytics_agent_ticketing_v2.core.run_sql import run_sql

ORG = 900001
ADMIN = 91001
AGENT = 91002
RESOLVER = 91003
QA = 92001


def test_run_sql_happy_path():
    res = run_sql(
        "SELECT ticket_number, status FROM rpt.tickets WHERE status = 'Open' LIMIT 10",
        organization_id=ORG,
        user_id=ADMIN,
        role="admin",
        queue_ids=[QA],
    )
    assert res["status"] == "compiled"
    assert "rpt_tickets AS (" in res["sql"]
    assert "LIMIT 10" in res["sql"]
    assert res["views"] == ["tickets"]


def test_run_sql_deny_on_unauthorized_view():
    res = run_sql(
        "SELECT * FROM rpt.agents",
        organization_id=ORG,
        user_id=RESOLVER,
        role="resolver",
        queue_ids=[QA],
    )
    assert res["status"] == "error"
    assert res["error_type"] == "DENY"
    assert "not available for this user" in res["error"]


def test_run_sql_repair_on_invalid_column():
    res = run_sql(
        "SELECT t.imaginary_column FROM rpt.tickets t",
        organization_id=ORG,
        user_id=ADMIN,
        role="admin",
        queue_ids=[QA],
    )
    assert res["status"] == "error"
    assert res["error_type"] == "REPAIR"
    assert "not in rpt.tickets" in res["error"]


def test_run_sql_repair_on_missing_param():
    res = run_sql(
        "SELECT * FROM rpt.tickets WHERE created_at >= :start",
        organization_id=ORG,
        user_id=ADMIN,
        role="admin",
        queue_ids=[QA],
        params={},
    )
    assert res["status"] == "error"
    assert res["error_type"] == "REPAIR"
    assert "was not provided" in res["error"]
