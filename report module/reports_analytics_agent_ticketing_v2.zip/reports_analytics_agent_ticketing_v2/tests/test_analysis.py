"""Unit tests for core/analysis.py deterministic arithmetic helpers."""

from __future__ import annotations

import pytest

from reports_analytics_agent_ticketing_v2.core.analysis import (
    format_deep_analysis,
    period_delta,
    rate_vs_volume,
    segment_share_of_change,
)


def test_period_delta_increase():
    res = period_delta(120, 100, unit="tickets")
    assert res["current"] == 120.0
    assert res["previous"] == 100.0
    assert res["delta"] == 20.0
    assert res["pct_change"] == 20.0
    assert res["direction"] == "up"
    assert res["unit"] == "tickets"


def test_period_delta_decrease():
    res = period_delta(80, 100)
    assert res["delta"] == -20.0
    assert res["pct_change"] == -20.0
    assert res["direction"] == "down"


def test_period_delta_flat_and_zero():
    res = period_delta(100, 100)
    assert res["delta"] == 0.0
    assert res["pct_change"] == 0.0
    assert res["direction"] == "flat"

    res_zero = period_delta(50, 0)
    assert res_zero["pct_change"] is None
    assert res_zero["direction"] == "up"


def test_segment_share_of_change():
    segments = [
        {"name": "Billing", "current": 50, "previous": 30},   # +20
        {"name": "Technical", "current": 30, "previous": 20}, # +10
        {"name": "General", "current": 20, "previous": 30},   # -10
    ]
    # Total change = 20 + 10 - 10 = 20
    res = segment_share_of_change(segments)
    assert len(res) == 3
    # Billing is largest contributor (+20 / 20 = 100%)
    assert res[0]["name"] == "Billing"
    assert res[0]["segment_delta"] == 20.0
    assert res[0]["share_of_change"] == 100.0
    assert res[0]["direction"] == "up"

    # Technical (+10 / 20 = 50%) or General (-10 / 20 = -50%)
    shares = {r["name"]: r["share_of_change"] for r in res}
    assert shares["Technical"] == 50.0
    assert shares["General"] == -50.0


def test_rate_vs_volume_rate_dominant():
    # Previous: 10 breached out of 100 tickets (10%)
    # Current: 30 breached out of 100 tickets (30%) - volume unchanged, rate jumped
    res = rate_vs_volume(
        current_count=30,
        current_total=100,
        previous_count=10,
        previous_total=100,
    )
    assert res["current_rate"] == 0.3
    assert res["previous_rate"] == 0.1
    assert res["dominant"] == "rate"
    assert res["volume_effect"] == 0.0
    assert res["rate_effect"] == 20.0


def test_rate_vs_volume_volume_dominant():
    # Previous: 10 breached out of 100 tickets (10%)
    # Current: 20 breached out of 200 tickets (10%) - rate unchanged, volume doubled
    res = rate_vs_volume(
        current_count=20,
        current_total=200,
        previous_count=10,
        previous_total=100,
    )
    assert res["current_rate"] == 0.1
    assert res["previous_rate"] == 0.1
    assert res["dominant"] == "volume"
    assert res["rate_effect"] == 0.0
    assert res["volume_effect"] == 10.0


def test_format_deep_analysis():
    p = period_delta(150, 100, unit="tickets")
    segs = segment_share_of_change([
        {"name": "Billing", "current": 80, "previous": 40},
        {"name": "Technical", "current": 70, "previous": 60},
    ])
    rv = rate_vs_volume(15, 150, 10, 100)

    text = format_deep_analysis(primary=p, segments=segs, rate_decomp=rv)
    assert "DEEP_ANALYSIS" in text
    assert "period_change: 100.0 tickets -> 150.0 tickets (up (+50.0%))" in text
    assert "Billing" in text
    assert "rate_vs_volume" in text
