"""Streamlit NLP & Analytics Interface for Reports & Analytics V2.

Allows testing natural language questions end-to-end:
NLP Question -> Domain Agent (Planning) -> Executor (SQL/KPI/Cypher) -> Guard & DB Execution -> Facts -> CEO Answer Synthesis.
Default Context: org_id=1012, user_id=1028, role=admin.
No conversation memory across runs (stateless per turn).
"""

from __future__ import annotations

import json
import os
import re
import sys
import urllib.parse
from pathlib import Path
from typing import Any

import httpx
import streamlit as st
import yaml
from dotenv import load_dotenv

# Ensure repository root is on sys.path
REPO_ROOT = Path(__file__).resolve().parent.parent
PARENT_DIR = REPO_ROOT.parent
for p in [str(REPO_ROOT), str(PARENT_DIR)]:
    if p not in sys.path:
        sys.path.insert(0, p)

# Load environment configuration if available
for env_path in [
    REPO_ROOT / ".env",
    Path("/home/vectone/shiva/reportagent/.env"),
]:
    if env_path.exists():
        load_dotenv(env_path)

from reports_analytics_agent_ticketing_v2.core.analysis import (
    format_deep_analysis,
    period_delta,
    rate_vs_volume,
    segment_share_of_change,
)
from reports_analytics_agent_ticketing_v2.core.examples import (
    format_examples_for_prompt,
    load_examples,
    pick_examples,
)
from reports_analytics_agent_ticketing_v2.core.facts import assemble_facts
from reports_analytics_agent_ticketing_v2.core.grounding import apply_grounding, ground_check
from reports_analytics_agent_ticketing_v2.core.loop import LoopState
from reports_analytics_agent_ticketing_v2.core.run_cypher import run_cypher
from reports_analytics_agent_ticketing_v2.core.run_kpi import run_kpi
from reports_analytics_agent_ticketing_v2.core.run_sql import run_sql
from reports_analytics_agent_ticketing_v2.core.time import TimeBounds, resolve_expression

st.set_page_config(
    page_title="Ticketing Analytics V2 — NLP Console",
    page_icon="🤖",
    layout="wide",
)

st.title("🤖 Ticketing Analytics V2 — NLP Assistant")
st.caption("Ask natural language questions to generate certified KPIs, scoped SQL, and CEO briefings.")

# Sidebar Configuration
with st.sidebar:
    st.header("⚙️ Execution Context")
    org_id = st.number_input("Organization ID", value=1012, step=1)
    st.caption("💡 Live DB: Org 1000 has 113 tickets & 5 agents. Org 1012 has 0 tickets.")
    user_id = st.number_input("User ID", value=1028, step=1)
    role = st.selectbox("Role", ["admin", "agent", "resolver"], index=0)
    queue_ids_str = st.text_input("Queue IDs (comma-separated)", value="92001, 92002")
    queue_ids = [int(q.strip()) for q in queue_ids_str.split(",") if q.strip().isdigit()]

    st.divider()
    st.subheader("LLM Configuration")
    llm_base_url = st.text_input(
        "LLM Base URL",
        value=os.getenv("LLM_BASE_URL", "http://173.234.75.166:8011/v1"),
    )
    llm_model = st.text_input(
        "Model Name",
        value=os.getenv("LLM_MODEL_NAME", "worktual-gemma"),
    )

    st.divider()
    st.subheader("Database")
    pg_host = os.getenv("PG_HOST", "localhost")
    pg_port = os.getenv("PG_PORT", "5432")
    pg_db = os.getenv("PG_DATABASE", "worktual_bigint")
    pg_user = os.getenv("PG_USER", "nlp")
    pg_pass = os.getenv("PG_PASSWORD", "nLpTeam@561")
    
    use_live_db = st.checkbox("Execute against Database", value=True)
    quoted_pass = urllib.parse.quote_plus(pg_pass) if pg_pass else ""
    default_dsn = (
        f"postgresql://{pg_user}:{quoted_pass}@{pg_host}:{pg_port}/{pg_db}"
        if quoted_pass
        else f"postgresql://{pg_user}@{pg_host}:{pg_port}/{pg_db}"
    )
    custom_dsn = st.text_input(
        "DSN",
        value=default_dsn,
    )
    active_dsn = custom_dsn if use_live_db else None


def call_llm(messages: list[dict[str, str]], temperature: float = 0.1, max_tokens: int = 600) -> str:
    """Helper to send a chat completion request to vLLM / OpenAI endpoint."""
    client = httpx.Client(base_url=llm_base_url.rstrip("/"), timeout=35.0)
    resp = client.post(
        "/chat/completions",
        json={
            "model": llm_model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        },
    )
    resp.raise_for_status()
    data = resp.json()
    return data["choices"][0]["message"]["content"]


def extract_json(text: str) -> dict[str, Any]:
    """Parse JSON from markdown code fence or raw string."""
    clean = text.strip()
    match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", clean, re.DOTALL)
    if match:
        clean = match.group(1)
    elif "{" in clean and "}" in clean:
        clean = clean[clean.find("{") : clean.rfind("}") + 1]
    return json.loads(clean)


# Load prompts and context
domain_prompt_template = (REPO_ROOT / "domain" / "agent.md").read_text()
sql_prompt_template = (REPO_ROOT / "sql_executor" / "agent.md").read_text()
kg_prompt_template = (REPO_ROOT / "kg_executor" / "agent.md").read_text()

schema_path = REPO_ROOT / "product" / "schema.yml"
if schema_path.exists():
    with open(schema_path) as f:
        schema_data = yaml.safe_load(f)
    v_lines = ["## Available rpt.* Virtual Views and Columns:"]
    for v_name, v_conf in schema_data.get("views", {}).items():
        cols = ", ".join(v_conf.get("columns", {}).keys())
        desc = v_conf.get("description", "").split("\n")[0].strip()
        v_lines.append(f"- rpt.{v_name} ({desc}): {cols}")
    views_summary = "\n".join(v_lines)
else:
    views_summary = ""

sql_examples_path = REPO_ROOT / "product" / "examples" / "sql.yml"
sql_examples = sql_examples_path.read_text() if sql_examples_path.exists() else ""
full_sql_prompt = f"{sql_prompt_template}\n\n{views_summary}\n\n## Few-Shot SQL Examples\n{sql_examples}"

kg_examples_path = REPO_ROOT / "product" / "kg" / "examples" / "cypher.yml"
kg_examples = kg_examples_path.read_text() if kg_examples_path.exists() else ""
full_kg_prompt = f"{kg_prompt_template}\n\n## Few-Shot Cypher Examples\n{kg_examples}"

# Preset Example Questions
SAMPLE_QUESTIONS = [
    "Select or type your question...",
    "How many tickets were created this month?",
    "What is our average resolution time?",
    "Show me ticket count broken down by queue",
    "What is our resolution SLA breach rate?",
    "Which agent has the highest ticket volume this week?",
    "List open tickets assigned to me",
    "How many unread notifications do I have?",
    "Who is staffing the Billing queue?",
]

selected_sample = st.selectbox("💡 Sample CEO Questions", SAMPLE_QUESTIONS)
user_query = st.text_input(
    "💬 Enter Your Natural Language Question",
    value="" if selected_sample.startswith("Select") else selected_sample,
    placeholder="e.g. How many open tickets do we have this month?",
)

tab_nlp, tab_direct = st.tabs(["🚀 Natural Language Query", "🛠️ Direct Query Inspector"])

with tab_nlp:
    if st.button("🔍 Get Answer", type="primary", use_container_width=True) and user_query.strip():
        loop = LoopState(max_attempts=2)
        step_logs = []
        
        with st.status("Processing Natural Language Query...", expanded=True) as status_box:
            # ---------------------------------------------------------
            # Step 1: Domain Agent Planning
            # ---------------------------------------------------------
            st.write("🧠 **Domain Agent**: Analyzing question and formulating plan...")
            domain_user_msg = (
                f"Identity: role={role}, org_id={org_id}, user_id={user_id}, queues={queue_ids}\n"
                f"Question: {user_query.strip()}"
            )
            domain_messages = [
                {"role": "system", "content": domain_prompt_template},
                {"role": "user", "content": domain_user_msg},
            ]
            
            plan_data: dict[str, Any] = {}
            try:
                domain_raw = call_llm(domain_messages, temperature=0.1)
                plan_data = extract_json(domain_raw)
                st.write(f"✓ Plan generated ({plan_data.get('depth', 'standard')} depth, {len(plan_data.get('tasks', []))} tasks)")
            except Exception as e:
                st.error(f"Domain Planning Error: {e}")
                plan_data = {"tasks": []}

            tasks = plan_data.get("tasks", [])
            all_facts = []
            executed_results = []

            # ---------------------------------------------------------
            # Step 2: Task Execution Loop (Max 2 Attempts)
            # ---------------------------------------------------------
            for task in tasks:
                task_id = task.get("id", "t1")
                executor = task.get("executor", "sql")
                kpi_id = task.get("kpi")
                time_expr = task.get("time", "this month")
                scope_expr = task.get("scope", "org" if role == "admin" else "own")
                goal = task.get("goal", user_query)
                answer_type = task.get("answer_type", "kpi")

                st.write(f"⚙️ **Executing Task {task_id}** via `{executor}` (Goal: {goal})...")

                # Resolve time expression to UTC
                try:
                    tb = resolve_expression(time_expr)
                except Exception:
                    tb = TimeBounds(None, None, "overall (no date filter, UTC)")
                start_iso = tb.start.isoformat() if tb.start else None
                end_iso = tb.end.isoformat() if tb.end else None

                task_result: dict[str, Any] = {}
                loop.record_attempt()

                if kpi_id:
                    # Certified KPI execution path
                    st.write(f"→ Calling certified KPI template: `{kpi_id}` ({tb.echo})")
                    task_result = run_kpi(
                        kpi_id,
                        organization_id=int(org_id),
                        user_id=int(user_id),
                        role=role,
                        queue_ids=queue_ids,
                        scope_level=scope_expr,
                        time_start=start_iso,
                        time_end=end_iso,
                        dsn=active_dsn,
                    )
                elif executor == "sql":
                    # SQL Executor LLM writes SQL
                    st.write("→ SQL Executor LLM generating scoped query against `rpt.*` views...")
                    if start_iso and end_iso:
                        time_ctx = f"time_params: start={start_iso}, end={end_iso}\nparams_available: :start, :end"
                        query_params = {"start": start_iso, "end": end_iso}
                    else:
                        time_ctx = "time_params: overall / all-time (unbounded, no date filter)\nparams_available: none (do not filter created_at)"
                        query_params = {}

                    sql_ex_list = load_examples(sql_examples_path) if sql_examples_path.exists() else []
                    chosen_sql_ex = pick_examples(goal, sql_ex_list, top_k=6, kind="sql")
                    sql_few_shot = format_examples_for_prompt(chosen_sql_ex, kind="sql") if chosen_sql_ex else sql_examples
                    task_sql_prompt = f"{sql_prompt_template}\n\n{views_summary}\n\n## Few-Shot SQL Examples\n{sql_few_shot}"

                    sql_user_msg = (
                        f"Task Goal: {goal}\n"
                        f"{time_ctx}\n"
                        f"scope: {scope_expr}\n"
                        f"answer_type: {answer_type}"
                    )
                    sql_raw = call_llm(
                        [
                            {"role": "system", "content": task_sql_prompt},
                            {"role": "user", "content": sql_user_msg},
                        ],
                        temperature=0.1,
                    )
                    sql_tool = extract_json(sql_raw)
                    sql_query = sql_tool.get("sql", "")
                    st.write(f"→ Executing guarded query: `{sql_query[:75]}...`")
                    task_result = run_sql(
                        sql_query,
                        organization_id=int(org_id),
                        user_id=int(user_id),
                        role=role,
                        queue_ids=queue_ids,
                        params=query_params,
                        dsn=active_dsn,
                    )

                    # 1-turn repair loop if query had fixable typo or unknown view
                    if task_result.get("status") == "error" and task_result.get("error_type") == "REPAIR":
                        st.write(f"→ Query rejected ({task_result.get('error')[:65]}...). Repairing once...")
                        repair_msg = (
                            f"The query was rejected: {task_result.get('error')}\n"
                            "Repair the SQL query using only available rpt.* views from the schema and return JSON tool call."
                        )
                        repair_raw = call_llm(
                            [
                                {"role": "system", "content": task_sql_prompt},
                                {"role": "user", "content": sql_user_msg},
                                {"role": "assistant", "content": sql_raw},
                                {"role": "user", "content": repair_msg},
                            ],
                            temperature=0.1,
                        )
                        repair_tool = extract_json(repair_raw)
                        sql_query = repair_tool.get("sql", "")
                        st.write(f"→ Retrying repaired query: `{sql_query[:75]}...`")
                        task_result = run_sql(
                            sql_query,
                            organization_id=int(org_id),
                            user_id=int(user_id),
                            role=role,
                            queue_ids=queue_ids,
                            params=query_params,
                            dsn=active_dsn,
                        )
                else:
                    # Cypher Executor LLM
                    st.write("→ KG Executor LLM generating Cypher query...")
                    kg_ex_list = load_examples(kg_examples_path) if kg_examples_path.exists() else []
                    chosen_kg_ex = pick_examples(goal, kg_ex_list, top_k=4, kind="cypher")
                    kg_few_shot = format_examples_for_prompt(chosen_kg_ex, kind="cypher") if chosen_kg_ex else kg_examples
                    task_kg_prompt = f"{kg_prompt_template}\n\n## Few-Shot Cypher Examples\n{kg_few_shot}"

                    kg_user_msg = f"Task Goal: {goal}\ntime: {start_iso} to {end_iso}\nscope: {scope_expr}"
                    kg_raw = call_llm(
                        [
                            {"role": "system", "content": task_kg_prompt},
                            {"role": "user", "content": kg_user_msg},
                        ],
                        temperature=0.1,
                    )
                    kg_tool = extract_json(kg_raw)
                    cypher_query = kg_tool.get("cypher", "")
                    st.write(f"→ Executing Cypher query: `{cypher_query[:75]}...`")
                    task_result = run_cypher(
                        cypher_query,
                        organization_id=int(org_id),
                        user_id=int(user_id),
                        role=role,
                        queue_ids=queue_ids,
                        execute=bool(active_dsn),
                    )

                # Re-plan check if error occurred
                if task_result.get("status") == "error" and loop.should_replan(task_result):
                    st.warning(f"⚠️ Task {task_id} failed ({task_result.get('error_type')}). Re-planning (Attempt 2)...")
                    loop.record_error(task_result)
                    replan_msg = (
                        f"REPLAN_REQUEST (attempt 2 of 2)\n"
                        f"Failed task: {task_id}\n"
                        f"Error: {task_result.get('error')}\n"
                        f"Goal: {goal}\n"
                        "Re-plan using run_sql with an explicit SELECT query against the appropriate rpt.* view."
                    )
                    retry_raw = call_llm(
                        domain_messages + [{"role": "assistant", "content": domain_raw}, {"role": "user", "content": replan_msg}],
                        temperature=0.1,
                    )
                    retry_plan = extract_json(retry_raw)
                    retry_task = retry_plan.get("tasks", [{}])[0]
                    # Retry execution via SQL
                    retry_sql_msg = (
                        f"Task Goal: {retry_task.get('goal', goal)}\n"
                        f"{time_ctx}\n"
                        f"scope: {scope_expr}\n"
                        f"answer_type: {retry_task.get('answer_type', answer_type)}"
                    )
                    retry_sql_raw = call_llm(
                        [{"role": "system", "content": full_sql_prompt}, {"role": "user", "content": retry_sql_msg}],
                        temperature=0.1,
                    )
                    retry_sql_tool = extract_json(retry_sql_raw)
                    retry_query = retry_sql_tool.get("sql", "SELECT COUNT(*) FROM rpt.tickets")
                    st.write(f"→ Retrying with alternative query: `{retry_query[:75]}...`")
                    task_result = run_sql(
                        retry_query,
                        organization_id=int(org_id),
                        user_id=int(user_id),
                        role=role,
                        queue_ids=queue_ids,
                        params=query_params,
                        dsn=active_dsn,
                    )

                executed_results.append({"task": task, "result": task_result})

                # Assemble fact block
                fact = assemble_facts(
                    task_result,
                    task_goal=goal,
                    kpi_id=kpi_id,
                    answer_type=answer_type,
                )
                all_facts.append(fact)

            # ---------------------------------------------------------
            # Step 3: Domain Synthesis (CEO Briefing) & Grounding Check
            # ---------------------------------------------------------
            st.write("📝 **Domain Agent**: Synthesizing final CEO briefing from facts...")
            facts_combined = "\n\n".join(all_facts)
            synthesis_prompt = (
                f"You are the Lead Analyst briefing the CEO.\n"
                f"Original Question: {user_query}\n"
                f"Facts gathered:\n{facts_combined}\n\n"
                "Instructions:\n"
                "- Write a clear, executive-level answer directly addressing the CEO's question.\n"
                "- Lead with the exact primary number or finding in the very first sentence.\n"
                "- Use bold markdown for key metrics and figures.\n"
                "- Explain business context concisely. If there are top groups/drivers, summarize them.\n"
                "- If the primary number is 0 or no records exist, clearly state that there are 0 records for this organization/scope.\n"
                "- Do NOT mention internal errors, REPLAN, system architecture, or pipeline tools. State business facts clearly.\n"
                "- Do NOT use headings like 'Analysis' or 'Narrative'. Just natural, clean prose."
            )
            raw_briefing = call_llm(
                [{"role": "system", "content": "You are a senior analyst giving an executive briefing to the CEO."}, {"role": "user", "content": synthesis_prompt}],
                temperature=0.2,
                max_tokens=600,
            )

            # Grounding verification: ensures numbers in the briefing strictly exist in facts
            def _regen_briefing(orig_answer: str, ungrounded: list[str]) -> str:
                regen_prompt = (
                    f"{synthesis_prompt}\n\n"
                    f"CRITICAL: The following figures in your previous answer were not found in the source facts: {', '.join(ungrounded)}.\n"
                    "Regenerate the answer using ONLY numbers that appear in the facts block above."
                )
                return call_llm(
                    [{"role": "system", "content": "You are a senior analyst giving an executive briefing to the CEO."}, {"role": "user", "content": regen_prompt}],
                    temperature=0.1,
                    max_tokens=600,
                )

            final_briefing, was_grounded = apply_grounding(raw_briefing, facts_combined, _regen_briefing)
            status_box.update(label="Analysis Complete!", state="complete", expanded=False)

        # ---------------------------------------------------------
        # Display Results
        # ---------------------------------------------------------
        st.markdown("### 📋 Executive Briefing")
        st.markdown(final_briefing)

        # Data presentation
        for item in executed_results:
            t = item["task"]
            r = item["result"]
            rows = r.get("rows") or []
            if rows:
                with st.expander(f"📊 Data Table: {t.get('goal', 'Result Rows')} ({len(rows)} records)", expanded=True):
                    st.dataframe(rows, use_container_width=True)

        with st.expander("🔍 Workflow Trace & Verification Details", expanded=False):
            st.subheader("Domain Plan")
            st.json(plan_data)
            st.subheader("Combined Facts Block")
            st.code(facts_combined, language="text")
            st.subheader("Underlying Queries")
            for idx, item in enumerate(executed_results, 1):
                r = item["result"]
                st.write(f"**Task {idx} ({item['task'].get('goal')})**")
                if "sql" in r and r["sql"]:
                    st.code(r["sql"], language="sql")
                if "cypher" in r and r["cypher"]:
                    st.code(r["cypher"], language="cypher")
                if "guard_notes" in r and r["guard_notes"]:
                    st.caption("Guard Notes: " + ", ".join(r["guard_notes"]))


with tab_direct:
    st.subheader("Direct Query Inspection")
    direct_query_type = st.radio("Component Test", ["Certified KPI", "SQL (rpt.* Views)", "Cypher (Graph)"], horizontal=True)

    if direct_query_type == "Certified KPI":
        c1, c2 = st.columns(2)
        with c1:
            direct_kpi = st.text_input("KPI ID", value="ticket_count")
        with c2:
            direct_time = st.text_input("Time Expression", value="this month")
        if st.button("Run Certified KPI", type="secondary"):
            try:
                tb = resolve_expression(direct_time)
            except Exception:
                tb = TimeBounds(None, None, "overall (no date filter, UTC)")
            res = run_kpi(
                direct_kpi.strip(),
                organization_id=int(org_id),
                user_id=int(user_id),
                role=role,
                queue_ids=queue_ids,
                time_start=tb.start.isoformat() if tb.start else None,
                time_end=tb.end.isoformat() if tb.end else None,
                dsn=active_dsn,
            )
            st.code(assemble_facts(res, kpi_id=direct_kpi), language="text")
            if res.get("rows"):
                st.dataframe(res["rows"])
            with st.expander("Compiled SQL"):
                st.code(res.get("sql", ""), language="sql")
    elif direct_query_type == "SQL (rpt.* Views)":
        direct_sql = st.text_area("SQL Statement", value="SELECT queue_name, COUNT(*) AS count FROM rpt.tickets GROUP BY 1 ORDER BY 2 DESC LIMIT 10;")
        if st.button("Run SQL Query", type="secondary"):
            res = run_sql(direct_sql.strip(), organization_id=int(org_id), user_id=int(user_id), role=role, queue_ids=queue_ids, dsn=active_dsn)
            st.code(assemble_facts(res), language="text")
            if res.get("rows"):
                st.dataframe(res["rows"])
            with st.expander("Guarded SQL"):
                st.code(res.get("sql", ""), language="sql")
    else:
        direct_cypher = st.text_area("Cypher Statement", value="MATCH (t:Ticket) OPTIONAL MATCH (t)-[:in_queue]->(q:Queue) RETURN t.ticket_number, q.queue_name LIMIT 10")
        if st.button("Run Cypher Query", type="secondary"):
            res = run_cypher(direct_cypher.strip(), organization_id=int(org_id), user_id=int(user_id), role=role, queue_ids=queue_ids, execute=bool(active_dsn))
            st.code(assemble_facts(res), language="text")
            if res.get("rows"):
                st.dataframe(res["rows"])
            with st.expander("Guarded Cypher"):
                st.code(res.get("cypher", ""), language="cypher")
