"""Unit tests for core/cypher_guard.py."""

from __future__ import annotations

import pytest
from reports_analytics_agent_ticketing_v2.core.cypher_guard import CypherGuardError, guard_cypher

ADMIN = 91001
QA = 92001


def test_guard_cypher_valid():
    query = (
        "MATCH (t:Ticket)-[:in_queue]->(q:Queue) "
        "RETURN t.ticket_number, q.queue_name LIMIT 25"
    )
    guarded = guard_cypher(query, role="admin", user_id=ADMIN, queue_ids=[QA])
    assert "LIMIT 25" in guarded.cypher
    assert guarded.params["user_id"] == ADMIN
    assert guarded.params["queue_ids"] == [QA]


def test_guard_cypher_caps_limit():
    query = "MATCH (t:Ticket) RETURN t.id LIMIT 1000"
    guarded = guard_cypher(query, role="admin", user_id=ADMIN, max_rows=500)
    assert "LIMIT 500" in guarded.cypher


def test_guard_cypher_rejects_mutation():
    with pytest.raises(CypherGuardError, match="Write/mutation operations"):
        guard_cypher("CREATE (t:Ticket {ticket_number: 'bad'})", role="admin", user_id=ADMIN)


def test_guard_cypher_rejects_var_len_hop():
    with pytest.raises(CypherGuardError, match="variable-length or shortestPath"):
        guard_cypher("MATCH (t:Ticket)-[:in_queue*1..3]->(q:Queue) RETURN t", role="admin", user_id=ADMIN)


def test_guard_cypher_rejects_contact_start():
    with pytest.raises(CypherGuardError, match="query cannot start on Contact"):
        guard_cypher("MATCH (c:Contact) RETURN c", role="admin", user_id=ADMIN)


def test_guard_cypher_rejects_contact_outgoing_hop():
    with pytest.raises(CypherGuardError, match="Contact is a shared leaf; no outgoing hop is allowed"):
        guard_cypher(
            "MATCH (t:Ticket)-[:raised_by]->(c:Contact) MATCH (c)-[:assigned_to]->(a:Agent) RETURN t",
            role="admin",
            user_id=ADMIN,
        )


