"""Unit tests for core/grounding.py number grounding check."""

from __future__ import annotations

import pytest

from reports_analytics_agent_ticketing_v2.core.grounding import (
    _normalize,
    apply_grounding,
    extract_numbers,
    ground_check,
)


def test_extract_numbers():
    text = "We received 1,250 tickets this month. 18.5% were resolved within 4 hours, compared to 200 last month."
    nums = extract_numbers(text)
    assert "1,250" in nums
    assert "18.5%" in nums
    assert "4" in nums
    assert "200" in nums


def test_normalize():
    forms_pct = _normalize("18%")
    assert "18" in forms_pct
    assert "0.18" in forms_pct

    forms_comma = _normalize("1,250")
    assert "1250" in forms_comma

    forms_dec = _normalize("0.25")
    assert "25" in forms_dec
    assert "25%" in forms_dec or "0.25" in forms_dec


def test_ground_check_success():
    facts = "RESULT: ticket_count = 113\ntotal_tickets: 113\nqueue_counts:\n  Billing: 45\n  Technical: 68"
    answer = "In total, there were **113** tickets created. The Billing queue handled **45** tickets and Technical had **68**."
    res = ground_check(answer, facts)
    assert res.grounded is True
    assert len(res.ungrounded) == 0


def test_ground_check_hallucination_detected():
    facts = "RESULT: ticket_count = 113"
    answer = "There were 113 tickets, representing a 42% growth compared to 80 tickets in the prior period."
    res = ground_check(answer, facts)
    assert res.grounded is False
    assert "42%" in res.ungrounded or "42" in res.ungrounded
    assert "80" in res.ungrounded


def test_apply_grounding_regeneration():
    facts = "RESULT: ticket_count = 100"
    hallucinated_answer = "There were 100 tickets, with 50 in Billing."

    def mock_regen(answer, ungrounded):
        # Successfully removes the hallucinated number
        return "There were 100 tickets in total."

    final, grounded = apply_grounding(hallucinated_answer, facts, mock_regen)
    assert grounded is True
    assert final == "There were 100 tickets in total."


def test_apply_grounding_fallback():
    facts = "RESULT: ticket_count = 100\ntask_goal: count tickets"
    hallucinated_answer = "There were 100 tickets, and 99% satisfaction."

    def bad_regen(answer, ungrounded):
        # Keeps hallucinating
        return "There were 100 tickets, still 99% satisfaction."

    final, grounded = apply_grounding(hallucinated_answer, facts, bad_regen, max_retries=1)
    assert grounded is False
    assert "Based on the available data:" in final
    assert "RESULT: ticket_count = 100" in final
    assert "Note: 1 figure(s) in the generated answer could not be verified" in final
