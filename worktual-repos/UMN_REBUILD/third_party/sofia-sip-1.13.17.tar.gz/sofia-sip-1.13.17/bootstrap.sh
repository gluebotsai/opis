#!/bin/sh
./autogen.sh
