WITH base_ticket AS (
{{base_ticket}}
)
SELECT
    {{dimension_select}}
    (COUNT(*) FILTER (
        WHERE EXISTS (
            SELECT 1
            FROM ticketing.audit_events ae
            WHERE ae.organization_id = base_ticket.organization_id
              AND ae.ticket_id::text = base_ticket.ticket_id::text
              AND ae.action = 'ticket.status_changed'
              AND ae.meta->>'prev_status' IN ('Resolved', 'Closed')
        )
    )::float / NULLIF(COUNT(*) FILTER (WHERE resolved_at IS NOT NULL)::float, 0)) AS reopen_rate
FROM base_ticket
WHERE {{scope_sql}}
  AND {{time_sql}}
  AND resolved_at IS NOT NULL
  AND {{filters_sql}}
{{group_by_sql}}
