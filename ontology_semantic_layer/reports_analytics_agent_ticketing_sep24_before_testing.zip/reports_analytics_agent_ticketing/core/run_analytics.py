"""Compile a Domain frame to read-only SQL."""

from __future__ import annotations

from typing import Any

from .access import AccessDenied, apply_scope
from .checks import assert_read_only
from .dims import DIM_COLUMNS, in_list, segment_sql
from .loader import merge_effective
from .query_frame import Identity, QueryFrame
from .templates import fill_slots
from .time import resolve_expression, window_days

TIME_COLUMNS = {
    "note_count": "n.created_at",
    "escalation_count": "ae.created_at",
    "reassignment_count": "ae.created_at",
    "unread_notifications": "created_at",
    "kb_article_count": "created_at",
    "kb_views": "created_at",
    "recommendation_count": "created_at",
    "recommendation_acceptance_rate": "created_at",
    "approval_count": "created_at",
    "approval_rate": "created_at",
}
TICKET_SCOPED_EVENTS = {"note_count", "escalation_count", "reassignment_count"}



class UnmatchedName(Exception):
    def __init__(self, kind: str, mention: str) -> None:
        super().__init__(f"No {kind} named '{mention}' was found")
        self.kind = kind
        self.mention = mention


class AmbiguousName(Exception):
    def __init__(self, kind: str, mention: str, candidates: list[dict[str, Any]]) -> None:
        super().__init__(f"Several {kind} matches for '{mention}'")
        self.kind = kind
        self.mention = mention
        self.candidates = candidates


def _group_sql(frame: QueryFrame, card: dict[str, Any]) -> tuple[str, str]:
    if not frame.group_by:
        return "", ""
    allowed = set(card.get("allowed_dimensions") or [])
    cols = []
    for name in frame.group_by:
        if allowed and name not in allowed:
            raise ValueError(f"dimension {name} is not allowed on {frame.measure}")
        if name not in DIM_COLUMNS:
            raise ValueError(f"unknown dimension {name}")
        cols.append(DIM_COLUMNS[name])
    select = ", ".join(cols) + ","
    group = "GROUP BY " + ", ".join(cols)
    return select, group


def compile_frame(
    frame: QueryFrame,
    identity: Identity,
    *,
    resolved_targets: list[int] | None = None,
) -> tuple[str, str]:
    if frame.path == "catalog":
        from .compiler import compile_catalog

        return compile_catalog(frame, identity, resolved_targets=resolved_targets)
    return compile_certified(frame, identity, resolved_targets=resolved_targets)


def compile_certified(
    frame: QueryFrame,
    identity: Identity,
    *,
    resolved_targets: list[int] | None = None,
) -> tuple[str, str]:
    catalog = merge_effective(identity.organization_id)
    kpis = catalog["kpis"]
    if frame.measure not in kpis:
        raise ValueError(f"unknown measure {frame.measure}")
    card = kpis[frame.measure]
    allowed_levels = card.get("allowed_scope_levels") or []
    if allowed_levels and frame.scope.level not in allowed_levels:
        raise AccessDenied(f"{frame.measure} does not allow scope {frame.scope.level}.")
    scope = apply_scope(
        frame,
        identity,
        catalog["access"],
        kpi_id=frame.measure,
        target_ids=resolved_targets,
    )
    bounds = resolve_expression(frame.time.expression)
    date_col = frame.time.date_column or card.get("default_time_column") or "created_at"
    org_id = str(int(identity.organization_id))
    tenant_sql = f"organization_id = {org_id}"

    scope_sql = "TRUE"
    if frame.measure == "unread_notifications":
        if frame.scope.level == "own":
            scope_sql = f"user_id = {int(identity.user_id)}"
        elif frame.scope.level == "org":
            scope_sql = "TRUE"
        else:
            raise AccessDenied("Unread notifications only support org or own.")
    elif scope.get("column") and scope.get("ids"):
        col = scope["column"]
        if frame.measure in TICKET_SCOPED_EVENTS:
            col = f"t.{col}"
        scope_sql = in_list(col, scope["ids"])
    if scope.get("queue_ids") and frame.measure != "unread_notifications":
        qcol = "t.queue_id" if frame.measure in TICKET_SCOPED_EVENTS else "queue_id"
        extra = in_list(qcol, scope["queue_ids"])
        scope_sql = f"({scope_sql}) AND {extra}" if scope_sql != "TRUE" else extra

    time_sql = "TRUE"
    echo_time = bounds.echo
    date_sql = TIME_COLUMNS.get(frame.measure, date_col)
    if bounds.start is not None and bounds.end is not None:
        time_sql = (
            f"{date_sql} >= TIMESTAMPTZ '{bounds.start.isoformat()}' "
            f"AND {date_sql} < TIMESTAMPTZ '{bounds.end.isoformat()}'"
        )

    seg = segment_sql(card, catalog["catalog"], frame)
    if frame.measure == "csat_distribution_rate" and seg == "TRUE":
        raise ValueError("csat_distribution_rate needs a promoter, neutral, or detractor segment")

    dim_select, group_sql = _group_sql(frame, card)
    if bounds.start is None:
        window_days_sql = "GREATEST(1.0, EXTRACT(EPOCH FROM (NOW() - MIN(created_at))) / 86400.0)"
    else:
        window_days_sql = str(window_days(bounds))

    sql_path = catalog["sql_files"][frame.measure]
    raw = sql_path.read_text()
    base_filled = fill_slots(
        catalog["base_ticket_sql"],
        {"org_id": org_id, "tenant_sql": f"t.organization_id = {org_id}"},
    )
    compiled = fill_slots(
        raw,
        {
            "org_id": org_id,
            "tenant_sql": tenant_sql,
            "scope_sql": scope_sql,
            "time_sql": time_sql,
            "segment_sql": seg,
            "filters_sql": "TRUE",
            "dimension_select": dim_select,
            "group_by_sql": group_sql,
            "window_days": window_days_sql,
            "window_days_sql": window_days_sql,
            "segment_predicate": seg,
        },
        base_ticket=base_filled if "{{base_ticket}}" in raw else None,
    )
    assert_read_only(compiled)
    echo = f"{frame.measure}; scope {frame.scope.level}; {echo_time}"
    return compiled, echo
