"""Catalog list / find / count / breakdown / ranking. Allowlisted tables only."""

from __future__ import annotations

from .access import apply_scope
from .checks import assert_read_only
from .dims import DIM_COLUMNS, in_list, segment_sql
from .loader import merge_effective
from .query_frame import Identity, QueryFrame
from .time import resolve_expression

LIST_COLUMNS = [
    "id",
    "ticket_number",
    "subject",
    "status",
    "priority",
    "queue_id",
    "assignee_id",
    "resolver_id",
    "customer_id",
    "created_at",
]
DATE_COLUMNS = {"created_at", "resolved_at", "updated_at", "due_at"}


def compile_catalog(
    frame: QueryFrame,
    identity: Identity,
    *,
    resolved_targets: list[int] | None = None,
) -> tuple[str, str]:
    catalog = merge_effective(identity.organization_id)
    bounds = resolve_expression(frame.time.expression)
    org_id = int(identity.organization_id)
    scope = apply_scope(
        frame,
        identity,
        catalog["access"],
        kpi_id="ticket_count" if frame.shape in {"count", "breakdown", "ranking"} else None,
        target_ids=resolved_targets,
    )
    where = [f"t.organization_id = {org_id}"]
    if scope.get("column") and scope.get("ids"):
        where.append(in_list(f"t.{scope['column']}", scope["ids"]))
    if scope.get("queue_ids"):
        where.append(in_list("t.queue_id", scope["queue_ids"]))
    date_col = frame.time.date_column or "created_at"
    if date_col not in DATE_COLUMNS:
        raise ValueError(f"date column {date_col} is not allowed")
    if bounds.start is not None and bounds.end is not None:
        where.append(
            f"t.{date_col} >= TIMESTAMPTZ '{bounds.start.isoformat()}' "
            f"AND t.{date_col} < TIMESTAMPTZ '{bounds.end.isoformat()}'"
        )
    dummy_card = catalog["kpis"].get("ticket_count") or {}
    seg = segment_sql(dummy_card, catalog["catalog"], frame)
    if seg != "TRUE":
        where.append(
            seg.replace("status", "t.status")
            .replace("priority", "t.priority")
            .replace("assignee_id", "t.assignee_id")
        )

    limit = int(frame.limit or 50)
    if limit < 1 or limit > 500:
        raise ValueError("limit must be 1–500")

    if frame.shape in {"list", "find"}:
        cols = ", ".join(f"t.{c}" for c in LIST_COLUMNS)
        sql = (
            f"SELECT {cols} FROM ticketing.tickets t "
            f"WHERE {' AND '.join(where)} "
            f"ORDER BY t.created_at DESC LIMIT {limit}"
        )
    elif frame.shape == "count":
        sql = (
            f"SELECT COUNT(*)::bigint AS ticket_count FROM ticketing.tickets t "
            f"WHERE {' AND '.join(where)}"
        )
    elif frame.shape in {"breakdown", "ranking"}:
        if not frame.group_by:
            raise ValueError("breakdown needs group_by")
        dim = frame.group_by[0]
        if dim not in DIM_COLUMNS:
            raise ValueError(f"unknown dimension {dim}")
        col = DIM_COLUMNS[dim]
        order = "COUNT(*) DESC" if frame.shape == "ranking" else f"t.{col}"
        sql = (
            f"SELECT t.{col} AS {dim}, COUNT(*)::bigint AS ticket_count "
            f"FROM ticketing.tickets t WHERE {' AND '.join(where)} "
            f"GROUP BY t.{col} ORDER BY {order} LIMIT {limit}"
        )
    else:
        raise ValueError(f"catalog path does not support shape {frame.shape}")
    assert_read_only(sql)
    echo = f"catalog tickets; scope {frame.scope.level}; {bounds.echo}"
    return sql, echo
