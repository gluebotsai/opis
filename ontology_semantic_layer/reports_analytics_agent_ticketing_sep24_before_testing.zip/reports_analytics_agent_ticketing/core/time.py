"""UTC calendar windows. Never read org_settings."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import NamedTuple


class TimeBounds(NamedTuple):
    start: datetime | None
    end: datetime | None
    echo: str


def utc_now(now: datetime | None = None) -> datetime:
    if now is None:
        return datetime.now(timezone.utc)
    if now.tzinfo is None:
        return now.replace(tzinfo=timezone.utc)
    return now.astimezone(timezone.utc)


def resolve_expression(expression: str | None, *, now: datetime | None = None) -> TimeBounds:
    """Map user time words to half-open [start, end) UTC. None expression = overall."""
    moment = utc_now(now)
    if not expression:
        return TimeBounds(None, None, "overall (no date filter, UTC)")

    key = expression.strip().lower()
    today = moment.date()
    today_start = datetime(today.year, today.month, today.day, tzinfo=timezone.utc)

    if key in {"today"}:
        return TimeBounds(today_start, today_start + timedelta(days=1), "today (UTC)")
    if key in {"yesterday"}:
        start = today_start - timedelta(days=1)
        return TimeBounds(start, today_start, "yesterday (UTC)")
    if key in {"this week"}:
        monday = today_start - timedelta(days=today.weekday())
        return TimeBounds(monday, monday + timedelta(days=7), "this week Monday–Sunday (UTC)")
    if key in {"last week"}:
        monday = today_start - timedelta(days=today.weekday())
        start = monday - timedelta(days=7)
        return TimeBounds(start, monday, "last week Monday–Sunday (UTC)")
    if key in {"this month"}:
        start = datetime(today.year, today.month, 1, tzinfo=timezone.utc)
        if today.month == 12:
            end = datetime(today.year + 1, 1, 1, tzinfo=timezone.utc)
        else:
            end = datetime(today.year, today.month + 1, 1, tzinfo=timezone.utc)
        return TimeBounds(start, end, "this month (UTC)")
    if key in {"last month"}:
        first_this = datetime(today.year, today.month, 1, tzinfo=timezone.utc)
        if today.month == 1:
            start = datetime(today.year - 1, 12, 1, tzinfo=timezone.utc)
        else:
            start = datetime(today.year, today.month - 1, 1, tzinfo=timezone.utc)
        return TimeBounds(start, first_this, "last month (UTC)")

    raise ValueError(f"unsupported time expression: {expression}")


def window_days(bounds: TimeBounds, *, now: datetime | None = None) -> float:
    moment = utc_now(now)
    if bounds.start is None or bounds.end is None:
        return 1.0
    seconds = (min(bounds.end, moment) - bounds.start).total_seconds()
    return max(seconds / 86400.0, 1.0 / 24.0)
