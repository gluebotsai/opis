from __future__ import annotations

from .loader import merge_effective

__all__ = ["merge_effective"]
