from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

Shape = Literal["list", "find", "count", "breakdown", "ranking", "trend", "kpi"]
PathHint = Literal["certified", "catalog"]
ScopeLevel = Literal["org", "own", "created_by_me", "queue", "agent", "resolver"]
StatusReading = Literal["generic_pending", "literal", "open", "reopened", "overdue", "resolved"]


@dataclass
class FilterMention:
    field: str
    mention: str
    reading: StatusReading | None = None


@dataclass
class TimeSpec:
    expression: str | None = None
    date_column: str | None = None


@dataclass
class ScopeSpec:
    level: ScopeLevel
    target_mention: str | None = None


@dataclass
class QueryFrame:
    shape: Shape
    measure: str
    path: PathHint
    scope: ScopeSpec
    filters: list[FilterMention] = field(default_factory=list)
    time: TimeSpec = field(default_factory=TimeSpec)
    group_by: list[str] = field(default_factory=list)
    sort: str | None = None
    limit: int | None = None
    compare_time: TimeSpec | None = None
    check_thresholds: bool = False
    output: str = "answer"


@dataclass
class PlanStep:
    executor: Literal["sql"]
    frame: QueryFrame
    brief: str = ""


@dataclass
class DomainPlan:
    steps: list[PlanStep]


@dataclass
class Identity:
    organization_id: int
    user_id: int
    role: Literal["admin", "agent", "resolver"]
    my_queue_ids: list[int] = field(default_factory=list)
