"""Name to id. Exact first, then ILIKE %mention%. Never filter SQL by raw name."""

from __future__ import annotations

from typing import Any


def escape_like(text: str) -> str:
    return text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


class ResolveResult:
    def __init__(self, *, ids: list[int] | None, unmatched: str | None, ambiguous: list[dict[str, Any]] | None) -> None:
        self.ids = ids
        self.unmatched = unmatched
        self.ambiguous = ambiguous or []

    @property
    def ok(self) -> bool:
        return self.unmatched is None and not self.ambiguous and self.ids is not None


def decide_rows(mention: str, exact_rows: list[dict[str, Any]], like_rows: list[dict[str, Any]]) -> ResolveResult:
    if len(exact_rows) == 1:
        return ResolveResult(ids=[int(exact_rows[0]["id"])], unmatched=None, ambiguous=None)
    if len(exact_rows) > 1:
        return ResolveResult(ids=None, unmatched=None, ambiguous=exact_rows)
    if len(like_rows) == 1:
        return ResolveResult(ids=[int(like_rows[0]["id"])], unmatched=None, ambiguous=None)
    if len(like_rows) > 1:
        return ResolveResult(ids=None, unmatched=None, ambiguous=like_rows)
    return ResolveResult(ids=None, unmatched=mention, ambiguous=None)
