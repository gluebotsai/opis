"""python -m reports_analytics_agent_ticketing.core.validate"""

from __future__ import annotations

import sys

from .access import AccessDenied
from .loader import merge_effective, PACK_ROOT
from .query_frame import FilterMention, Identity, QueryFrame, ScopeSpec, TimeSpec
from .run_analytics import compile_certified, compile_frame


def _admin() -> Identity:
    return Identity(organization_id=900001, user_id=91001, role="admin", my_queue_ids=[92001, 92002])


def main() -> int:
    catalog = merge_effective(None)
    kpis = catalog["kpis"]
    errors: list[str] = []
    if "matrix" not in catalog["access"]:
        errors.append("access.yml missing matrix")
    expected = PACK_ROOT / "tests" / "golden" / "expected.yml"
    if not expected.exists():
        errors.append("missing tests/golden/expected.yml")

    ident = _admin()
    t1012 = merge_effective(1012)
    if t1012["kpis"].keys() != catalog["kpis"].keys():
        errors.append("org 1012 must not add or drop KPIs")
    overlay = (PACK_ROOT / "tenants" / "org_1012" / "tenant.yml")
    if overlay.exists():
        import yaml

        tenant_doc = yaml.safe_load(overlay.read_text()) or {}
        if tenant_doc.get("kpis", {}).get("add") or tenant_doc.get("kpis", {}).get("override"):
            errors.append("org 1012 must not add or override KPIs")
        for kpi_id, spec in (tenant_doc.get("thresholds") or {}).items():
            if kpi_id not in catalog["kpis"]:
                errors.append(f"org 1012 threshold for unknown KPI {kpi_id}")
            if not isinstance(spec, dict):
                errors.append(f"org 1012 threshold {kpi_id} must be a mapping")
        if t1012.get("thresholds") != (tenant_doc.get("thresholds") or {}):
            errors.append("org 1012 thresholds did not load onto the effective catalog")

    for kpi_id in sorted(kpis):
        scope = "org" if "org" in (kpis[kpi_id].get("allowed_scope_levels") or ["org"]) else (
            kpis[kpi_id]["allowed_scope_levels"][0]
        )
        extras = {}
        if kpi_id == "csat_distribution_rate":
            extras["filters"] = [FilterMention(field="bucket", mention="promoter")]
        frame = QueryFrame(
            shape="kpi",
            measure=kpi_id,
            path="certified",
            scope=ScopeSpec(level=scope),
            time=TimeSpec(),
            **extras,
        )
        try:
            sql, _echo = compile_certified(frame, ident)
        except Exception as exc:
            errors.append(f"compile {kpi_id}: {exc}")
            continue
        if "organization_id" not in sql and "{{" in sql:
            errors.append(f"{kpi_id} still has slots")
        if kpi_id != "total_customers" and str(ident.organization_id) not in sql:
            errors.append(f"{kpi_id} missing org id")

    open_frame = QueryFrame(
        shape="kpi",
        measure="ticket_count",
        path="certified",
        scope=ScopeSpec(level="org"),
        filters=[FilterMention(field="status", mention="open", reading="open")],
    )
    sql, _ = compile_certified(open_frame, ident)
    if "status = 'Open'" not in sql:
        errors.append("ticket_count open segment missing")
    pending = QueryFrame(
        shape="kpi",
        measure="ticket_count",
        path="certified",
        scope=ScopeSpec(level="org"),
        filters=[FilterMention(field="status", mention="pending", reading="generic_pending")],
    )
    sql, _ = compile_certified(pending, ident)
    if "NOT IN ('Closed', 'Resolved')" not in sql:
        errors.append("generic pending SQL missing")

    grouped = QueryFrame(
        shape="breakdown",
        measure="ticket_count",
        path="certified",
        scope=ScopeSpec(level="org"),
        group_by=["queue"],
    )
    sql, _ = compile_certified(grouped, ident)
    if "GROUP BY queue_id" not in sql:
        errors.append("group by queue missing")

    agent = Identity(organization_id=900001, user_id=91002, role="agent", my_queue_ids=[92001])
    try:
        compile_certified(
            QueryFrame(shape="kpi", measure="ticket_count", path="certified", scope=ScopeSpec(level="org")),
            agent,
        )
        errors.append("agent org ticket_count should be denied")
    except AccessDenied:
        pass


    resolver = Identity(organization_id=900001, user_id=91003, role="resolver", my_queue_ids=[92001])
    sla = QueryFrame(
        shape="kpi",
        measure="sla_breach_rate",
        path="certified",
        scope=ScopeSpec(level="queue"),
    )
    try:
        compile_certified(sla, resolver)
        errors.append("resolver queue sla_breach_rate should be denied")
    except AccessDenied:
        pass

    own = QueryFrame(
        shape="kpi",
        measure="ticket_count",
        path="certified",
        scope=ScopeSpec(level="own"),
    )
    sql, _ = compile_certified(own, resolver)
    if "resolver_id" not in sql:
        errors.append("resolver own tickets must filter resolver_id")

    listing = QueryFrame(
        shape="list",
        measure="tickets",
        path="catalog",
        scope=ScopeSpec(level="org"),
        limit=20,
    )
    sql, _ = compile_frame(listing, ident)
    if "ticketing.tickets" not in sql:
        errors.append("catalog list missing tickets")

    if errors:
        print("\n".join(errors))
        return 1
    print(f"ok: {len(kpis)} KPIs compile, access checks, catalog list")
    return 0


if __name__ == "__main__":
    sys.exit(main())
