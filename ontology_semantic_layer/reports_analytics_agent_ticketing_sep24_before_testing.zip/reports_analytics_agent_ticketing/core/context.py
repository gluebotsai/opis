"""Build small Domain indexes from the merged catalog."""

from __future__ import annotations

from typing import Any


def kpi_index_lines(kpis: dict[str, Any], *, allowed: set[str] | None = None) -> str:
    lines = []
    for kpi_id, card in kpis.items():
        if allowed is not None and kpi_id not in allowed:
            continue
        segs = ",".join((card.get("segments") or {}).keys()) or "-"
        dims = ",".join(card.get("allowed_dimensions") or []) or "-"
        dates = ",".join(card.get("allowed_date_columns") or []) or "-"
        scopes = ",".join(card.get("allowed_scope_levels") or []) or "-"
        lines.append(
            f"{kpi_id} | {card.get('aggregation')} | segments: {segs} | group: {dims} | dates: {dates} | scopes: {scopes}"
        )
    return "\n".join(lines)


def entity_index_lines(catalog: dict[str, Any]) -> str:
    groups = catalog.get("entity_groups") or {}
    dims = catalog.get("dimensions") or {}
    dim_names = ",".join(dims.keys())
    lines = []
    for name, members in groups.items():
        lines.append(f"{name} | {','.join(members)} | group: {dim_names}")
    return "\n".join(lines)
