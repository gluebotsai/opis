from __future__ import annotations

from typing import Any

from .query_frame import QueryFrame

DIM_COLUMNS = {
    "queue": "queue_id",
    "agent": "assignee_id",
    "resolver": "resolver_id",
    "status": "status",
    "priority": "priority",
    "channel": "channel",
    "category": "category",
    "customer": "customer_id",
}

READING_TO_SEGMENT = {
    "generic_pending": "pending_generic",
    "literal": "pending_literal",
    "open": "open",
    "reopened": "reopened",
    "overdue": "overdue",
    "resolved": "resolved",
}


def in_list(column: str, ids: list[int]) -> str:
    inner = ", ".join(str(int(i)) for i in ids)
    return f"{column} IN ({inner})"


def segment_sql(card: dict[str, Any], catalog: dict[str, Any], frame: QueryFrame) -> str:
    readings = catalog.get("status_readings") or {}
    parts: list[str] = []
    segments = card.get("segments") or {}
    for flt in frame.filters:
        if flt.field == "status" and flt.reading:
            key = READING_TO_SEGMENT.get(flt.reading, flt.reading)
            raw = segments.get(key) or (readings.get(flt.reading) or {}).get("sql")
            if raw and not str(raw).lower().startswith("no extra"):
                parts.append(str(raw))
            elif flt.reading in readings:
                parts.append(readings[flt.reading]["sql"])
        elif flt.field == "priority" and flt.mention.lower() == "high":
            raw = segments.get("high_priority") or "priority = 'high'"
            parts.append(str(raw))
        elif flt.mention in segments:
            raw = segments[flt.mention]
            if raw and not str(raw).lower().startswith("no extra"):
                parts.append(str(raw))
    return " AND ".join(parts) if parts else "TRUE"
